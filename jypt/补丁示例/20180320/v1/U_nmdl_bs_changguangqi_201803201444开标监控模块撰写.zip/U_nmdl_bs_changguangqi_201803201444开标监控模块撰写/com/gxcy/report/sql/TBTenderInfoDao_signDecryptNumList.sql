SELECT
sum(if(ii.technicalsignStatus='01',1,0)) as technicalSignNum,
sum(if(ii.technicaldecryptionStatus='01',1,0)) as technicalDecryptSuccessNum,
sum(if(ii.technicaldecryptionStatus='02',1,0)) as technicalDecryptFailNum,
sum(if(ii.signStatus='01',1,0)) as economySignNum,
sum(if(ii.decryption_status='01',1,0)) as economyDecryptSuccessNum,
sum(if(ii.decryption_status='02',1,0)) as economyDecryptFailNum
from t_b_open_bid_supplier ii
WHERE
	stageid IN (
		SELECT
			g.id
		FROM
			t_b_stage g
		WHERE
		 <#if tenderId ?exists && tenderId ?length gt 0>
			g.tenderid = :tenderId
		 </#if>
	);