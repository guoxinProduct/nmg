SELECT
	count(g.id) as tenderNum,
	sum(fileSize * 1) as fileSize
FROM
	t_b_bid g
WHERE
	g.tenderid IN (
		SELECT
			id
		FROM
			t_b_tender_project i
		WHERE
		    <#if tenderId ? exists && tenderId ?length gt 0>
			  i.tender_no = :tenderId
			</#if>
	)
AND bid_status = '01'