SELECT  pack_no as packNo ,
 CASE WHEN m.istechnicalStartBidOpeningStatus = '01' THEN '技术已开启' 
            ELSE '技术未开启' END as techniqueOpen,
CASE WHEN  m.istechnicalstartbidopeningstatus = '01' THEN '技术解密已启动'
            ELSE '技术解密未开启' END as techniqueDecrypt,
CASE WHEN  m.technicalopeningStatus = '01' THEN '技术已完成'
WHEN    m.technicalopeningStatus = '02' THEN '技术进行中'
            ELSE '技术未开始' END as techniqueTenderOpen,
CASE WHEN m.isStartBidOpeningStatus = '01' THEN '经济已开启' 
            ELSE '经济未开启' END  economyOpen,
CASE WHEN    m.isstartDecryptBidFile = '01' THEN '经济解密已启动'
            ELSE '经济解密未开启' END economyOpenDecrypt,
CASE WHEN    m.opening_status = '01' THEN '经济已完成'
WHEN    m.opening_status = '02' THEN '经济进行中'
            ELSE '经济未开始' END economyTenderOpen
from t_b_project_package x LEFT JOIN T_B_OPENING_RESULT m 
on m.stageid=x.stageid 
where
<#if tenderId ?exists && tenderId ?length gt 0>
  x.tenderid = :tenderId
</#if>