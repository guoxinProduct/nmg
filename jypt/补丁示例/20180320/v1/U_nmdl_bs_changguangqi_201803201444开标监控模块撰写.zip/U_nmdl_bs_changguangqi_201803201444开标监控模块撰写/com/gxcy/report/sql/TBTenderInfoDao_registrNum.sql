SELECT
	count(x.id) as registrNum
FROM
	t_b_tender_signup x,
	t_b_pack_signup m
WHERE
	x.id = m.signupid
    AND audit_status = '01'
<#if tenderId ?exists && tenderId ?length gt 0>
    AND tenderid = :tenderId
</#if>	