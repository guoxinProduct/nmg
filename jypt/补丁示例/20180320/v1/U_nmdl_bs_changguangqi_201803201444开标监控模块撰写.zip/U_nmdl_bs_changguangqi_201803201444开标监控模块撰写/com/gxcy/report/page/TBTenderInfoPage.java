package com.gxcx.report.page;

import java.util.Date;

public class TBTenderInfoPage implements java.io.Serializable{

	private static final long serialVersionUID = 7907571057471380355L;
	private String id;
	/**项目id */
	private String tenderId;
	/** 是否两步开标 */
	private java.lang.String isTwoBidOpening;
	/** 项目(包)名称*/
	private String tenderName;
	/** 项目(包)编号*/
	private String tenderNo;
	/** 是否远程开标*/
	private java.lang.String isRemoteOpening;
	/**开标时间 */
	private Date openBidStartDate;
	/**阶段id */
	private String stageId;
	
	/**报名家数 */
	private Integer registrNum;
	/**缴费家数*/
	private Integer payNum;
	/**投标数量*/
	private Integer tenderNum;
	/**标书大小 */
	private String fileSize;
	/**投标人 */
	private String supplierName;
	/**联系人 */
	private String linker;
	/**联系电话 */
	private String linkerTel;
	
	/**技术开启 */
	private String techniqueOpen;
	/**技术解密*/
	private String techniqueDecrypt;
	/**经济开启*/
	private String economyOpen;
	/**紧急解密*/
	private String economyDecrypt;
	
	/**包名称*/
	private String packNo;
	/**技术开标情况 */
	private String techniqueTenderOpen;
	/**技术启动解密情况*/
	private String techniqueOpenDecrypt;
	/**经济启动解密情况*/
	private String economyOpenDecrypt;
	/**经济开标*/
	private String economyTenderOpen;
	
	/**技术签名数*/
	private Integer technicalSignNum;
	/**技术解密成功家数 */
	private Integer technicalDecryptSuccessNum;
	/**技术解密失败家数*/
	private Integer technicalDecryptFailNum;
	/**经济签名家数 */
	private Integer economySignNum;
	/**经济解密成功家数*/
	private Integer economyDecryptSuccessNum;
	/**经济解密失败家数*/
	private Integer economyDecryptFailNum;
	/**投标人*/
	private String tenderer;
	/**技术投标人电话号码*/
	private String technicalTelephoneNumber;
	/**经济签到手机号 */
	private String economicSignedTelephoneNumber;
	/**技术签到手机号*/
	private String technicalSignedTelephoneNumber;
	public java.lang.String getIsTwoBidOpening() {
		return isTwoBidOpening;
	}
	public void setIsTwoBidOpening(java.lang.String isTwoBidOpening) {
		this.isTwoBidOpening = isTwoBidOpening;
	}
	public String getTenderName() {
		return tenderName;
	}
	public void setTenderName(String tenderName) {
		this.tenderName = tenderName;
	}
	public String getTenderNo() {
		return tenderNo;
	}
	public void setTenderNo(String tenderNo) {
		this.tenderNo = tenderNo;
	}
	public Date getOpenBidStartDate() {
		return openBidStartDate;
	}
	public void setOpenBidStartDate(Date openBidStartDate) {
		this.openBidStartDate = openBidStartDate;
	}
	public String getStageId() {
		return stageId;
	}
	public void setStageId(String stageId) {
		this.stageId = stageId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}	
	public String getTenderId() {
		return tenderId;
	}
	public void setTenderId(String tenderId) {
		this.tenderId = tenderId;
	}
	public java.lang.String getIsRemoteOpening() {
		return isRemoteOpening;
	}
	public void setIsRemoteOpening(java.lang.String isRemoteOpening) {
		this.isRemoteOpening = isRemoteOpening;
	}
	public Integer getRegistrNum() {
		return registrNum;
	}
	public void setRegistrNum(Integer registrNum) {
		this.registrNum = registrNum;
	}
	public Integer getPayNum() {
		return payNum;
	}
	public void setPayNum(Integer payNum) {
		this.payNum = payNum;
	}
	public Integer getTenderNum() {
		return tenderNum;
	}
	public void setTenderNum(Integer tenderNum) {
		this.tenderNum = tenderNum;
	}
	public String getFileSize() {
		return fileSize;
	}
	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getLinker() {
		return linker;
	}
	public void setLinker(String linker) {
		this.linker = linker;
	}
	public String getLinkerTel() {
		return linkerTel;
	}
	public void setLinkerTel(String linkerTel) {
		this.linkerTel = linkerTel;
	}	
	public String getTechniqueOpen() {
		return techniqueOpen;
	}
	public void setTechniqueOpen(String techniqueOpen) {
		this.techniqueOpen = techniqueOpen;
	}
	public String getTechniqueDecrypt() {
		return techniqueDecrypt;
	}
	public void setTechniqueDecrypt(String techniqueDecrypt) {
		this.techniqueDecrypt = techniqueDecrypt;
	}
	public String getEconomyOpen() {
		return economyOpen;
	}
	public void setEconomyOpen(String economyOpen) {
		this.economyOpen = economyOpen;
	}
	public String getEconomyDecrypt() {
		return economyDecrypt;
	}
	public void setEconomyDecrypt(String economyDecrypt) {
		this.economyDecrypt = economyDecrypt;
	}
	public String getPackNo() {
		return packNo;
	}
	public void setPackNo(String packNo) {
		this.packNo = packNo;
	}
	public String getTechniqueTenderOpen() {
		return techniqueTenderOpen;
	}
	public void setTechniqueTenderOpen(String techniqueTenderOpen) {
		this.techniqueTenderOpen = techniqueTenderOpen;
	}
	public String getTechniqueOpenDecrypt() {
		return techniqueOpenDecrypt;
	}
	public void setTechniqueOpenDecrypt(String techniqueOpenDecrypt) {
		this.techniqueOpenDecrypt = techniqueOpenDecrypt;
	}
	public String getEconomyOpenDecrypt() {
		return economyOpenDecrypt;
	}
	public void setEconomyOpenDecrypt(String economyOpenDecrypt) {
		this.economyOpenDecrypt = economyOpenDecrypt;
	}
	public String getEconomyTenderOpen() {
		return economyTenderOpen;
	}
	public void setEconomyTenderOpen(String economyTenderOpen) {
		this.economyTenderOpen = economyTenderOpen;
	}
	public Integer getTechnicalSignNum() {
		return technicalSignNum;
	}
	public void setTechnicalSignNum(Integer technicalSignNum) {
		this.technicalSignNum = technicalSignNum;
	}
	public Integer getTechnicalDecryptSuccessNum() {
		return technicalDecryptSuccessNum;
	}
	public void setTechnicalDecryptSuccessNum(Integer technicalDecryptSuccessNum) {
		this.technicalDecryptSuccessNum = technicalDecryptSuccessNum;
	}
	public Integer getTechnicalDecryptFailNum() {
		return technicalDecryptFailNum;
	}
	public void setTechnicalDecryptFailNum(Integer technicalDecryptFailNum) {
		this.technicalDecryptFailNum = technicalDecryptFailNum;
	}
	public Integer getEconomySignNum() {
		return economySignNum;
	}
	public void setEconomySignNum(Integer economySignNum) {
		this.economySignNum = economySignNum;
	}
	public Integer getEconomyDecryptSuccessNum() {
		return economyDecryptSuccessNum;
	}
	public void setEconomyDecryptSuccessNum(Integer economyDecryptSuccessNum) {
		this.economyDecryptSuccessNum = economyDecryptSuccessNum;
	}
	public Integer getEconomyDecryptFailNum() {
		return economyDecryptFailNum;
	}
	public void setEconomyDecryptFailNum(Integer economyDecryptFailNum) {
		this.economyDecryptFailNum = economyDecryptFailNum;
	}
	public String getTenderer() {
		return tenderer;
	}
	public void setTenderer(String tenderer) {
		this.tenderer = tenderer;
	}
	public String getTechnicalTelephoneNumber() {
		return technicalTelephoneNumber;
	}
	public void setTechnicalTelephoneNumber(String technicalTelephoneNumber) {
		this.technicalTelephoneNumber = technicalTelephoneNumber;
	}
	public String getEconomicSignedTelephoneNumber() {
		return economicSignedTelephoneNumber;
	}
	public void setEconomicSignedTelephoneNumber(
			String economicSignedTelephoneNumber) {
		this.economicSignedTelephoneNumber = economicSignedTelephoneNumber;
	}
	public String getTechnicalSignedTelephoneNumber() {
		return technicalSignedTelephoneNumber;
	}
	public void setTechnicalSignedTelephoneNumber(
			String technicalSignedTelephoneNumber) {
		this.technicalSignedTelephoneNumber = technicalSignedTelephoneNumber;
	}
		
}
