SELECT DISTINCT
	x.supplier_name as supplierName,
	x.linker as linker,
	x.linker_tel as linkerTel
FROM
	t_b_tender_signup x
WHERE
	audit_status = '01'
<#if tenderId ?exists && tenderId ?length gt 0>
   AND x.tenderid = :tenderId
</#if>
