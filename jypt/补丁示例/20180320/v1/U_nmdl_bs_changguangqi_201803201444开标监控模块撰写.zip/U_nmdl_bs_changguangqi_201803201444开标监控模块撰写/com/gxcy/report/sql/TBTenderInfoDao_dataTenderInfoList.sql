SELECT DISTINCT
	y.open_bid_start_date as openBidStartDate,
	x.isTwoBidOpening as isTwoBidOpening,
	m.tender_no as tenderNo,
	m.tender_name as tenderName,
	m.id as id
FROM
	t_b_project_biz_rule x,
	t_b_project_time_rule y,
	t_b_tender_project m
WHERE
	x.stageid = y.stageid
AND x.tenderid = m.id
AND x.isRemoteOpening = '1'
AND y.open_bid_start_date > NOW()
ORDER BY
	y.open_bid_start_date