SELECT DISTINCT
	supplierName as tenderer,
	telephoneNumber as economicSignedTelephoneNumber ,
	technicaltelephoneNumber as technicalTelephoneNumber
FROM
	t_b_open_bid_supplier
WHERE
	stageid IN (
		SELECT
			g.id
		FROM
			t_b_stage g
		WHERE
		<#if tenderId ?exists && tenderId ?length gt 0>
			g.tenderid = :tenderId
		</#if>	
	) AND (
	   technicaldecryptionStatus = '02'
	   OR decryption_Status = '02'
	)
