SELECT DISTINCT
	m.supplier_name as tenderer
FROM
	t_b_bid m
LEFT JOIN T_B_OPENING_RESULT g ON g.stageid = m.stageid
LEFT JOIN t_b_open_bid_supplier j ON m.stageid = j.stageid
AND m.supplierid = j.supplierid
WHERE
	isStartBidOpeningStatus IN ('01', '02')
	 and
		m.stageid IN (
		SELECT
			g.id
		FROM
			t_b_stage g
		WHERE
		<#if tenderId ?exists && tenderId ?length gt 0>
			g.tenderid = :tenderId
		</#if>
	 ) and technicalsignStatus is null