SELECT
	sum(if(ii.istechnicalStartBidOpeningStatus='01',1,0)) as techniqueOpen,
	sum(if(ii.istechnicalstartbidopeningstatus='01',1,0)) as techniqueDecrypt,
	sum(if(ii.isStartBidOpeningStatus='01',1,0)) as economyOpen,
	sum(if(ii.isstartDecryptBidFile='01',1,0)) as economyDecrypt
FROM
	T_B_OPENING_RESULT ii
WHERE
	stageid IN (
		SELECT
			g.id
		FROM
			t_b_stage g
		WHERE
		  <#if tenderId ?exists && tenderId ?length gt 0>
			 g.tenderid = :tenderId
		</#if> 
);
