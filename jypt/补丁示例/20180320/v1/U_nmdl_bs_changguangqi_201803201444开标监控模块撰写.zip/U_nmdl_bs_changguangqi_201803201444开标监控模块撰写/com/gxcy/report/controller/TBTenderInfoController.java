package com.gxcx.report.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.util.StringUtil;
import org.jeecgframework.minidao.pojo.MiniDaoPage;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;




import com.gxcx.report.page.TBTenderInfoPage;
import com.gxcx.report.service.TBTenderInfoServiceI;
/**
 * 招标信息
 */
@Scope("prototype") 
@Controller
@RequestMapping("/tBTenderInfoController")
public class TBTenderInfoController extends BaseController{
	
	@Autowired
	private TBTenderInfoServiceI tBTenderInfoService;
	@RequestMapping(params = "list")
	public ModelAndView list(HttpServletRequest request) {
		return new ModelAndView("com/gxcx/report/tBTenderInfoList");
	}	
	@RequestMapping(params = "tenderInfoList")
	public void tenderInfoList(TBTenderInfoPage t,HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
		MiniDaoPage<TBTenderInfoPage> miniDaoPage= tBTenderInfoService.dataTenderInfoList(t, dataGrid.getPage(), dataGrid.getRows());
		dataGrid.setTotal(miniDaoPage.getTotal());
		dataGrid.setResults(miniDaoPage.getResults());
		TagUtil.datagrid(response, dataGrid);
	}
	/**
	 * 查看开标前详情
	 * @param request
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月15日 下午6:55:28
	 */
	@RequestMapping(params = "preTenderDetail")
	public ModelAndView preTenderDetail(TBTenderInfoPage tbTenderInfoPage,HttpServletRequest request) {
		if (StringUtil.isNotEmpty(tbTenderInfoPage.getId())) {
			TBTenderInfoPage tbTenderInfo =  tBTenderInfoService.getPreTenderInfoByTenderId(tbTenderInfoPage.getId());
			List<TBTenderInfoPage> tbTenderContactList = tBTenderInfoService.getTenderContactList(tbTenderInfoPage.getId());		
			request.setAttribute("tbTenderInfoPage", tbTenderInfo);		
			request.setAttribute("tbTenderContactList",tbTenderContactList);
		}
		return new ModelAndView("com/gxcx/report/preTenderDetail");
	}
	/**
	 * 查看开标中情况
	 * @param request
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 下午2:22:05
	 */
	@RequestMapping(params = "inTenderDetail")
	public ModelAndView inTenderDetail(TBTenderInfoPage tbTenderInfoPage,HttpServletRequest request) {
		if(StringUtils.isNotEmpty(tbTenderInfoPage.getId())){
			request.setAttribute("tenderId", tbTenderInfoPage.getId());
		}
		return new ModelAndView("com/gxcx/report/inTenderDetail");
	}
	/**
	 * 跳转项目启动数量情况列表
	 * @param request
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 下午3:10:54
	 */
	@RequestMapping(params = "projectStartNumList")
	public ModelAndView projectStartNumList(TBTenderInfoPage tbTenderInfoPage,HttpServletRequest request) {
		if(StringUtils.isNotEmpty(tbTenderInfoPage.getId())){
			List<TBTenderInfoPage> projectStartNumList = tBTenderInfoService.getProjectStartNumList(tbTenderInfoPage.getId());
			request.setAttribute("projectStartNumList", projectStartNumList);
		}		
		return new ModelAndView("com/gxcx/report/projectStartNumList");
	}
	/**
	 * 包开启及启动解密及完成情况列表
	 * @param request
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 下午5:19:38
	 */
	@RequestMapping(params = "packOpenAndDecryptAndFinishList")
	public ModelAndView packOpenAndDecryptAndFinishList(TBTenderInfoPage tbTenderInfoPage,HttpServletRequest request) {
		if(StringUtils.isNotEmpty(tbTenderInfoPage.getId())){
			List<TBTenderInfoPage> packOpenAndDecryptAndFinishList = tBTenderInfoService.getPackOpenAndDecryptAndFinishList(tbTenderInfoPage.getId());
			request.setAttribute("packOpenAndDecryptAndFinishList", packOpenAndDecryptAndFinishList);
		}
		return new ModelAndView("com/gxcx/report/packOpenAndDecryptAndFinishList");
	}
	/**
	 * 签到解密家数情况列表
	 * @param request
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 下午7:02:55
	 */
	@RequestMapping(params = "signDecryptNumList")
	public ModelAndView signDecryptNumList(TBTenderInfoPage tbTenderInfoPage,HttpServletRequest request) {
		if(StringUtils.isNotEmpty(tbTenderInfoPage.getId())){
			List<TBTenderInfoPage> signDecryptNumList = tBTenderInfoService.getSignDecryptNumList(tbTenderInfoPage.getId());
			request.setAttribute("signDecryptNumList", signDecryptNumList);
		}
		return new ModelAndView("com/gxcx/report/signDecryptNumList");
	}
	/**
	 * 两阶段项目已经投标，且相应标段已经开启，但未技术签到列表
	 * @param request
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 下午8:28:19
	 */
	@RequestMapping(params = "tenderOpenedAndNoTechnicalSignList")
	public ModelAndView tenderOpenedAndNoTechnicalSignList(TBTenderInfoPage tbTenderInfoPage,HttpServletRequest request) {
		if(StringUtils.isNotEmpty(tbTenderInfoPage.getId())){
			List<TBTenderInfoPage> tenderOpenedAndNoTechnicalSignList = tBTenderInfoService.tenderOpenedAndNoTechnicalSignList(tbTenderInfoPage.getId());
			request.setAttribute("tenderOpenedAndNoTechnicalSignList", tenderOpenedAndNoTechnicalSignList);
		}		
		return new ModelAndView("com/gxcx/report/tenderOpenedAndNoTechnicalSignList");
	}
	/**
	 * 一阶段项目已经投标，且相应标段已经开启，但经济未签到列表
	 * @param request
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 下午8:58:27
	 */
	@RequestMapping(params = "tenderOpenedAndNoEconomicSignList")
	public ModelAndView tenderOpenedAndNoEconomicSignList(TBTenderInfoPage tbTenderInfoPage,HttpServletRequest request) {
		if(StringUtils.isNotEmpty(tbTenderInfoPage.getId())){
		List<TBTenderInfoPage> tenderOpenedAndNoEconomicSignList = tBTenderInfoService.tenderOpenedAndNoEconomicSignList(tbTenderInfoPage.getId());
		request.setAttribute("tenderOpenedAndNoEconomicSignList", tenderOpenedAndNoEconomicSignList);
		}
		return new ModelAndView("com/gxcx/report/tenderOpenedAndNoEconomicSignList");
	}
	/**
	 * 两阶段项目技术签到未解密的名单列表
	 * @param request
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月19日 上午9:30:14
	 */
	@RequestMapping(params = "technicalSignedAndUnDecryptedList")
	public ModelAndView technicalSignedAndUnDecryptedList(TBTenderInfoPage tbTenderInfoPage,HttpServletRequest request) {
		if(StringUtils.isNotEmpty(tbTenderInfoPage.getId())){
		   List<TBTenderInfoPage> technicalSignedAndUnDecryptedList = tBTenderInfoService.technicalSignedAndUnDecryptedList(tbTenderInfoPage.getId());
		   request.setAttribute("technicalSignedAndUnDecryptedList", technicalSignedAndUnDecryptedList);
		}
		return new ModelAndView("com/gxcx/report/technicalSignedAndUnDecryptedList");
	}
	/**
	 * 一阶段两阶段项目经济签到未解密的名单列表
	 * @param tbTenderInfoPage
	 * @param request
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月19日 下午7:20:17
	 */
	@RequestMapping(params = "economicSignedAndUnDecryptedList")
	public ModelAndView economicSignedAndUnDecryptedList(TBTenderInfoPage tbTenderInfoPage,HttpServletRequest request) {
		if(StringUtils.isNotEmpty(tbTenderInfoPage.getId())){
		 List<TBTenderInfoPage> economicSignedAndUnDecryptedList = tBTenderInfoService.economicSignedAndUnDecryptedList(tbTenderInfoPage.getId());
		 request.setAttribute("economicSignedAndUnDecryptedList", economicSignedAndUnDecryptedList);
	}
		return new ModelAndView("com/gxcx/report/economicSignedAndUnDecryptedList");
	}
	/**
	 * 两阶段技术解密经济未签到的名单列表
	 * @param request
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月19日 下午7:21:20
	 */
	@RequestMapping(params = "technicalDecryptedAndUnSignedByTwoStageList")
	public ModelAndView technicalDecryptedAndUnSignedByTwoStageList(TBTenderInfoPage tbTenderInfoPage,HttpServletRequest request) {
		if(StringUtils.isNotEmpty(tbTenderInfoPage.getId())){
		   List<TBTenderInfoPage> technicalDecryptedAndUnSignedByTwoStageList = tBTenderInfoService.technicalDecryptedAndUnSignedByTwoStageList(tbTenderInfoPage.getId());
		   request.setAttribute("technicalDecryptedAndUnSignedByTwoStageList", technicalDecryptedAndUnSignedByTwoStageList);
		}
		return new ModelAndView("com/gxcx/report/technicalDecryptedAndUnSignedByTwoStageList");
	}
	/**
	 * 解密失败投标人情况列表 
	 * @param tbTenderInfoPage
	 * @param request
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月19日 下午7:34:55
	 */
	@RequestMapping(params = "tendererDecryptFailList")
	public ModelAndView tendererDecryptFailList(TBTenderInfoPage tbTenderInfoPage,HttpServletRequest request) {
		List<TBTenderInfoPage> tendererDecryptFailList = tBTenderInfoService.tendererDecryptFailList(tbTenderInfoPage.getId());
		request.setAttribute("tendererDecryptFailList", tendererDecryptFailList);
		return new ModelAndView("com/gxcx/report/tendererDecryptFailList");
	}
}
