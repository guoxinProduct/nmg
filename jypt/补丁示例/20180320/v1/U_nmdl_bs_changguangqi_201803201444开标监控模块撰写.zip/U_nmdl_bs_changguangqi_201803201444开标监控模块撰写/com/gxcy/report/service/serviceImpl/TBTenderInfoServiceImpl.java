package com.gxcx.report.service.serviceImpl;


import java.util.List;

import org.jeecgframework.core.common.service.impl.CommonServiceImpl;
import org.jeecgframework.minidao.pojo.MiniDaoPage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gxcx.report.dao.TBTenderInfoDao;
import com.gxcx.report.page.TBTenderInfoPage;
import com.gxcx.report.service.TBTenderInfoServiceI;


@Service("tBTenderInfoService")
@Transactional
public class TBTenderInfoServiceImpl extends CommonServiceImpl implements TBTenderInfoServiceI{
	@Autowired
	private TBTenderInfoDao tBTenderInfoDao;
	public MiniDaoPage<TBTenderInfoPage> dataTenderInfoList(
			TBTenderInfoPage t, int page, int rows) {
		return tBTenderInfoDao.dataTenderInfoList(t, page, rows);
	}
	@Override
	public TBTenderInfoPage getPreTenderInfoByTenderId(String tenderId) {
		/**报名家数*/
		Integer registrNum = tBTenderInfoDao.registrNum(tenderId);
		TBTenderInfoPage tenderInfoPage = new TBTenderInfoPage();
		tenderInfoPage.setRegistrNum(registrNum);
		/**缴费家数*/
		Integer payNum = tBTenderInfoDao.payNum(tenderId);
		tenderInfoPage.setPayNum(payNum);
		/**投标情况 分别存有 数量、标书大小 */
		TBTenderInfoPage tenderSituation = tBTenderInfoDao.tenderSituation(tenderId);
		tenderInfoPage.setTenderNum(tenderSituation.getTenderNum());
		tenderInfoPage.setFileSize(tenderSituation.getFileSize());
		return tenderInfoPage;
	}
	
	@Override
	public List<TBTenderInfoPage> getTenderContactList(String tenderId) {
		return tBTenderInfoDao.tenderContactList(tenderId);
	}
	
	@Override
	public List<TBTenderInfoPage> getProjectStartNumList(String tenderId) {
		return tBTenderInfoDao.projectStartNumList(tenderId);
	}
	
	@Override
	public List<TBTenderInfoPage> getPackOpenAndDecryptAndFinishList(String tenderId) {
		return tBTenderInfoDao.packOpenAndDecryptAndFinishList(tenderId);
	}
	@Override
	public List<TBTenderInfoPage> getSignDecryptNumList(String tenderId) {
		return tBTenderInfoDao.signDecryptNumList(tenderId);
	}
	@Override
	public List<TBTenderInfoPage> tenderOpenedAndNoTechnicalSignList(String tenderId) {
		return tBTenderInfoDao.tenderOpenedAndNoTechnicalSignList(tenderId);
	}
	@Override
	public List<TBTenderInfoPage> tenderOpenedAndNoEconomicSignList(String tenderId) {
		return tBTenderInfoDao.tenderOpenedAndNoEconomicSignList(tenderId);
	}
	@Override
	public List<TBTenderInfoPage> technicalSignedAndUnDecryptedList(String tenderId) {
		return tBTenderInfoDao.technicalSignedAndUnDecryptedList(tenderId);
	}
	@Override
	public List<TBTenderInfoPage> economicSignedAndUnDecryptedList(String tenderId) {
		return tBTenderInfoDao.economicSignedAndUnDecryptedList(tenderId);
	}
	@Override
	public List<TBTenderInfoPage> technicalDecryptedAndUnSignedByTwoStageList(String tenderId) {
		return tBTenderInfoDao.technicalDecryptedAndUnSignedByTwoStageList(tenderId);
	}
	@Override
	public List<TBTenderInfoPage> tendererDecryptFailList(String tenderId) {
		return tBTenderInfoDao.tendererDecryptFailList(tenderId);
	}

}
