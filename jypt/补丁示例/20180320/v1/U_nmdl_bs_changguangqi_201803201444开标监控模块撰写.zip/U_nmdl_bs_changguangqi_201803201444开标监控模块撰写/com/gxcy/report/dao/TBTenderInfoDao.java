package com.gxcx.report.dao;

import java.util.List;
import java.util.Map;

import org.jeecgframework.minidao.annotation.Arguments;
import org.jeecgframework.minidao.annotation.MiniDao;
import org.jeecgframework.minidao.annotation.ResultType;
import org.jeecgframework.minidao.pojo.MiniDaoPage;

import com.gxcx.report.page.TBTenderInfoPage;
import com.gxcx.tender.entity.TBProjectPackageEntity;
import com.gxcx.tender.page.TBTenderProjectPage;
/**
 * @author changguangqi
 */
@MiniDao
public interface TBTenderInfoDao {
	/**
	 * 开标情况列表
	 * @param t
	 * @param page
	 * @param rows
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月15日 下午4:32:19
	 */
	@Arguments({"param", "page", "rows"})
	@ResultType(TBTenderInfoPage.class)
	public MiniDaoPage<TBTenderInfoPage> dataTenderInfoList(TBTenderInfoPage t, int page, int rows);
	/**
	 * 报名家数
	 * @return
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月15日 下午4:31:27
	 */
	@Arguments({"tenderId"})
	@ResultType(Integer.class)
	public Integer registrNum(String tenderId);
	/**
	 * 缴费家数
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月15日 下午4:40:56
	 */
	@Arguments({"tenderId"})
	@ResultType(Integer.class)
	public Integer payNum(String tenderId);
	/**
	 * 投标情况
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月15日 下午4:46:20
	 */
	@Arguments({"tenderId"})
	@ResultType(TBTenderInfoPage.class)
	public TBTenderInfoPage tenderSituation(String tenderId);
	/**
	 * 投标人联系方式
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月15日 下午4:55:04
	 */
	@Arguments({"tenderId"})
	@ResultType(TBTenderInfoPage.class)
	public List<TBTenderInfoPage> tenderContactList(String tenderId);
	/**
	 * 项目启动数量列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 下午3:22:35
	 */
	@Arguments({"tenderId"})
	@ResultType(TBTenderInfoPage.class)
	public List<TBTenderInfoPage> projectStartNumList(String tenderId);
	/**
	 * 包开启和加密及完成的情况
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 下午4:47:36
	 */
	@Arguments({"tenderId"})
	@ResultType(TBTenderInfoPage.class)
	public List<TBTenderInfoPage> packOpenAndDecryptAndFinishList(String tenderId);
	/**
	 * 签到解密家数
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 下午6:45:46
	 */
	@Arguments({"tenderId"})
	@ResultType(TBTenderInfoPage.class)
	public List<TBTenderInfoPage> signDecryptNumList(String tenderId);
	/**
	 * 两阶段项目已经投标，且相应标段已经开启，但未技术签到列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 下午8:17:39
	 */
	@Arguments({"tenderId"})
	@ResultType(TBTenderInfoPage.class)
	public List<TBTenderInfoPage> tenderOpenedAndNoTechnicalSignList(String tenderId);
	/**
	 * 一阶段项目已经投标，且相应标段已经开启，但经济未签到列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 下午8:50:18
	 */
	@Arguments({"tenderId"})
	@ResultType(TBTenderInfoPage.class)
	public List<TBTenderInfoPage> tenderOpenedAndNoEconomicSignList(String tenderId);
	/**
	 * 两阶段项目技术签到未解密的名单列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月19日 上午9:22:39
	 */
	@Arguments({"tenderId"})
	@ResultType(TBTenderInfoPage.class)
	public List<TBTenderInfoPage> technicalSignedAndUnDecryptedList(String tenderId);
	/**
	 * 一阶段两阶段项目经济签到未解密的名单列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月19日 上午9:46:50
	 */
	@Arguments({"tenderId"})
	@ResultType(TBTenderInfoPage.class)
	public List<TBTenderInfoPage> economicSignedAndUnDecryptedList(String tenderId);
	/**
	 * 两阶段技术解密经济未签到的名单列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月19日 上午10:27:14
	 */
	@Arguments({"tenderId"})
	@ResultType(TBTenderInfoPage.class)
	public List<TBTenderInfoPage> technicalDecryptedAndUnSignedByTwoStageList(String tenderId);
	/**
	 * 解密失败投标人情况列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月19日 上午11:02:52
	 */
	@Arguments({"tenderId"})
	@ResultType(TBTenderInfoPage.class)
	public List<TBTenderInfoPage> tendererDecryptFailList(String tenderId);

	
}
