SELECT DISTINCT
	supplierName as tenderer,
	technicaltelephoneNumber as technicalTelephoneNumber
FROM
	t_b_open_bid_supplier
WHERE
	stageid IN (
		SELECT
			g.id
		FROM
			t_b_stage g
		WHERE
		<#if tenderId ?exists && tenderId ?length gt 0>
			g.tenderid = :tenderId 
		</#if>	
)
AND technicalsignStatus = '01'
AND (
	technicaldecryptionStatus IS NULL
	OR technicaldecryptionStatus = '02'
)