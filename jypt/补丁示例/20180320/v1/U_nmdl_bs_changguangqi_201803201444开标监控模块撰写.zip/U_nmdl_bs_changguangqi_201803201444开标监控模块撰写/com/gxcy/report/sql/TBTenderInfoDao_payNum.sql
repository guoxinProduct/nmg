SELECT
	count(pk.id) as payNum
FROM
	t_b_docpay_pack pk,
	t_b_doc_pay s
WHERE
	pk.DOCPAYID = s.id
    AND auditstatus = '01'
<#if tenderId ?exists && tenderId ?length gt 0>
	AND tenderid = :tenderId
</#if>
