package com.gxcx.report.service;

import java.util.List;

import org.jeecgframework.core.common.service.CommonService;
import org.jeecgframework.minidao.pojo.MiniDaoPage;

import com.gxcx.report.page.TBTenderInfoPage;


public interface TBTenderInfoServiceI extends CommonService{
	/**
	 * 开标信息
	 * @param t
	 * @param page
	 * @param rows
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月15日 下午3:27:08
	 */
	public MiniDaoPage<TBTenderInfoPage> dataTenderInfoList(TBTenderInfoPage t, int page, int rows);
	/**
	 * 获取投标信息(查询标前情况)
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 上午10:47:32
	 */
	public TBTenderInfoPage getPreTenderInfoByTenderId(String tenderId);
	/**
	 * 获取投标人联系方式列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 上午11:50:17
	 */
	public List<TBTenderInfoPage> getTenderContactList(String tenderId);
	/**
	 * 获取项目启动数量列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 下午3:38:43
	 */
	public List<TBTenderInfoPage> getProjectStartNumList(String tenderId);
	/**
	 * 包开启及启动解密及完成情况列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 下午5:13:19
	 */
	public List<TBTenderInfoPage> getPackOpenAndDecryptAndFinishList(String tenderId);
	/**
	 * 签到解密家数情况列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 下午6:59:38
	 */
	public List<TBTenderInfoPage> getSignDecryptNumList(String tenderId);
	/**
	 * 两阶段项目已经投标，且相应标段已经开启，但未技术签到列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 下午8:25:21
	 */
	public List<TBTenderInfoPage> tenderOpenedAndNoTechnicalSignList(String tenderId);
	/**
	 * 一阶段项目已经投标，且相应标段已经开启，但经济未签到列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月16日 下午8:55:34
	 */
	public List<TBTenderInfoPage> tenderOpenedAndNoEconomicSignList(String tenderId);
	/**
	 * 两阶段项目技术签到未解密的名单列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月19日 上午9:27:00
	 */
	public List<TBTenderInfoPage> technicalSignedAndUnDecryptedList(String tenderId);
	/**
	 * 一阶段两阶段项目经济签到未解密的名单列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月19日 上午10:05:42
	 */
	public List<TBTenderInfoPage> economicSignedAndUnDecryptedList(String tenderId);
	/**
	 * 两阶段技术解密经济未签到的名单列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月19日 上午10:33:59
	 */
	public List<TBTenderInfoPage> technicalDecryptedAndUnSignedByTwoStageList(String tenderId);
	/**
	 * 解密失败投标人情况列表
	 * @return
	 *
	 * @version:v1.0
	 * @author:changguangqi
	 * @date:2018年3月19日 上午11:13:28
	 */
	public List<TBTenderInfoPage> tendererDecryptFailList(String tenderId);
}
