SELECT DISTINCT
	supplierName as tenderer,
	telephoneNumber as technicalTelephoneNumber
FROM
	t_b_open_bid_supplier
WHERE
	stageid IN (
		SELECT
			g.id
		FROM
			t_b_stage g
		WHERE
		   signStatus = '01'
		  <#if tenderId ?exists && tenderId ?length gt 0>
			AND g.tenderid = :tenderId
		  </#if>			
	)
AND (
	decryption_Status IS NULL
	OR decryption_Status = '02'
)