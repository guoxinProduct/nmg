$(document).ready(function(){
 	//给时间控件加上样式
	$("#tBBulletinListtb").find("input[name='createtime_begin']").attr("class","Wdate").click(function(){WdatePicker({dateFmt:'yyyy-MM-dd'});});
	$("#tBBulletinListtb").find("input[name='createtime_end']").attr("class","Wdate").click(function(){WdatePicker({dateFmt:'yyyy-MM-dd'});});
	$("#tBBulletinList").find("input[name='createtime_begin']").attr("class","Wdate").click(function(){WdatePicker({dateFmt:'yyyy-MM-dd'});});
	$("#tBBulletinList").find("input[name='createtime_end']").attr("class","Wdate").click(function(){WdatePicker({dateFmt:'yyyy-MM-dd'});});
});

//录入公告
function add(title,url,id) {
	window.location.href = url;
}

//更新公告
function update(id) {
	window.location.href = 'tBBulletinController.do?goUpdateYW&id='+id;
}

//更新时间规则
function updateRule(id) {
	window.location.href = 'tBBulletinController.do?goUpdateRelTenderRule&id='+id;
}

//查看公告
function detail(title,url) {
	window.location.href = url;
}

//增加延迟公告
function relDelayBulletin(id) {
	window.location.href = 'tBBulletinController.do?goAddDelayBulletin&id='+id;
}

//同步到公共服务平台
function toSynBulletin(id) {
	$.ajax({
		url : 'SynToController.do?toSynBulletin&bulletinId='+id,
		type : 'post',
		data: {},
		cache : false,
		success : function(jsonData){
			 var data = $.parseJSON(jsonData);
			 alert(data.msg);
		}
	});
}
