
//编辑
function update(id) {
	createwindow('编辑','tBProjectPackageController.do?goUpdate&id='+id);
}
 
//查看
function detail(title, url) {
	createdetailwindow('查看', url);
}

//返回列表页面
function getTenderProjectList() {
	var loadPageUrl = parent.document.getElementById("loadPageUrl");
	var loadPageUrlStr  = (loadPageUrl!=null&&loadPageUrl!="")?$(loadPageUrl).val():'';
    window.location.href= (loadPageUrlStr!=null&&loadPageUrlStr!="")?loadPageUrlStr:"tBTenderProjectController.do?list";
}

//批量删除
function deleteALLSelectOpt(title,url,gname) {
	gridname=gname;
    var ids = [];
    var rows = $("#"+gname).datagrid('getSelections');
    if (rows.length > 0) {
    	$.dialog.setting.zIndex = getzIndex(true);
    	$.dialog.confirm('你确定永久删除该数据吗?', function(r) {
		   if (r) {
				for ( var i = 0; i < rows.length; i++) {
					if (rows[i].selected == "01") {
						break;
					}
					ids.push(rows[i].id);
				}
				if (rows.length == ids.length) {
					$.ajax({
						url : url,
						type : 'post',
						data : {
							ids : ids.join(',')
						},
						cache : false,
						success : function(data) {
							var d = $.parseJSON(data);
							if (d.success) {
								var msg = d.msg;
								tip(msg);
								reloadTable();
								$("#"+gname).datagrid('unselectAll');
								ids='';
							}
						}
					});
				} else {
					tip('您选中的数据中存在不能删除的标段！');
					ids='';
				}
			}
		});
	} else {
		tip("请选择需要删除的数据");
	}
}

//批量增加
function addBatch(title,url){
	$.dialog({
	  width:400,
	  height:300,
      id: 'addBatch',
      title: "批量增加标段",
      max: false,
      min: false,
      resize: false,
      content: 'url:'+url,
      lock:true,
      close: function() {
  		
      },
      button: [
          {name: "确定", callback: callbackDoAddBatch, focus: true},
          {name: "取消", callback: function (){}}
      ]
  });
	
}
function callbackDoAddBatch(){
	var iframe = this.iframe.contentWindow;
	var tenderid=iframe.document.getElementById("tenderid").value;
	var packNumber=iframe.document.getElementById("packNumber").value;
	var ex = /^[1-9]\d*$/;  
    if (!ex.test(packNumber)) {  
     	 alert("标段数量请输入大于等于1的正整数!");
     	 return;
    }  
	$.ajax({
		url: "tBProjectPackageController.do?doAddBatch",
		data: {tenderid:tenderid,
			   packNumber:packNumber
			  },
		type: "post",
		dataType:'json',
		success:function(d){
			alert(d.msg);
			reloadTable();
		}
	});
}
     var rowIndex=0;
	  /******   选择品目     ******/
	  function openPurcategorySelect(index) {
	  	rowIndex=index;
	  	$.dialog.setting.zIndex = 9999; 
	  	$.dialog({content: 'url:basePurcatalogCategoryController.do?purcatacategorySelect&enable=true&searchId='+$('#purcategoryIds').val(), zIndex: 2100, title: '品目列表', lock: true, width: '400px', height: '350px', opacity: 0.4, button: [
	      {name: '确定', callback: callbackPurcategorySelect, focus: true},
	      {name: '取消', callback: function (){}}
	      ]}).zindex();
	  }	
	  function callbackPurcategorySelect() {
	  	var iframe = this.iframe.contentWindow;
	  	var treeObj = iframe.$.fn.zTree.getZTreeObj("departSelect");
	  	//多选(enable=true)
	  	var nodes = treeObj.getCheckedNodes(true);
	  	//单选(enable=false)
	  	//var nodes = treeObj.getSelectedNodes();
	  	if(nodes.length>0){
	  		var ids='',names='';
	  		for(i=0;i<nodes.length;i++){
	  			var node = nodes[i];
	  			ids += node.id+',';
	  			names += node.name+',';
	  			//ids += node.id;
	  			//names += node.name;
	  		}
	  		if (ids!='') {
	  			 ids = ids.substr(0, ids.length-1);
	  		 } 
	  		 if (names!='') {
	  			 names = names.substr(0, names.length-1);
	  		 } 
	  		$('#purcategoryNames'+rowIndex).val(names);	
	  		$('#purcategoryIds'+rowIndex).val(ids);		
	  	}
	  }
      //保存
	  function savePack(packid,index){
		  var packName=$("#packName"+index).val();
		  var packNo=$("#packNo"+index).val();
		  var purcategoryNames=$("#purcategoryNames"+index).val();
		  var purcategoryIds=$("#purcategoryIds"+index).val();
		  var contractBudget=$("#contractBudget"+index).val();
		  var maxLimitPrice=$("#maxLimitPrice"+index).val();
		  var packageid = $("#id"+index).val();
		  var ex = /^[^\u4e00-\u9fa5]{0,}$/;  
		  var reg =/[\"\'\#\%\&\<>\{}\=\\]+/;
		  if(packNo==''){
			  alert("标段编号不能为空！");
			  return;
		  }else{
			  if (reg.test(packNo)){
				  alert("标段编号不能含有非法字符!");
				  return;
			  }
		  }
		  /**
		  else{
			  if (!ex.test(packNo)) {  
		     	 	alert("包组编号请输不能含有汉字!");
		     	 	return;
		      } 
		  }*/
	      if(packName==''){
	    	  alert("标段名称不能为空！");
	    	  return;
	      }else{
	    	  if (reg.test(packName)){
				  alert("标段名称不能含有非法字符!");
				  return;
			  }
	      }
	      $.ajax({
				url: "tBProjectPackageController.do?checkPackNo",
				data: {
						packNo : packNo,
						tenderid : $("#tenderid").val(),
						id: packageid
					  },
				type: "post",
				dataType:'json',
				success:function(d){
					if (d.msg == '00') {
						alert("标段编号重复！");
						return;
					} else {
						saveOnePack(packid,index);//校验通过了，则保存标段信息
					}
				}
			}) 
	  };
	  
	  
  //批量保存
  function saveAllPack(title,url,gname) {
    var ids = [];
    var rows = $("#"+gname).datagrid('getSelections');
	if(rows.length<1){
		alert("请勾选要保存的包组")
		return;
	}
    var checkPackNo=true;
	var checkPackname=true;
	var checkPackNoTeshu=true;
	var checkPacknameTeshu=true;
    var checkContractBudget=true;
    var ex = /^[^\u4e00-\u9fa5]{0,}$/; 
    var reg =/[\"\'\#\%\&\<>\{}\=\\]+/;
    var sumbudget = 0;
    
    
    for ( var i = 0; i < rows.length; i++) {
        var index=$("#"+gname).datagrid('getRowIndex',rows[i]);
        if($("#packNo"+index).val()==''){
        	checkPackNo=false;
		}else{
			if (reg.test($("#packNo"+index).val())) {  
				checkPackNoTeshu=false;
		    } 
		}
        /**
		 if (!ex.test($("#packNo"+index).val())) {  
			 checkPackNo=false;
	      } 
	      */
        
		if($("#packName"+index).val()==''){
			checkPackname=false;
		}else{
			if (reg.test($("#packName"+index).val())) {  
				checkPacknameTeshu=false;
			} 
		}
        if($("#contractBudget"+index).val()==''){
			checkContractBudget=false;
		}
	}
	if(!checkPackNo){
		//alert("选中的包组编号不能含有汉字！");
		alert("标段编号不能为空！");
		return;
	}
	if(!checkPackNoTeshu){
		alert("标段编号不能含有非法字符!！");
		return;
	}
	if(!checkPackname){
	}
	if(!checkPacknameTeshu){
		alert("标段名称不能含有非法字符!！");
		return;
	}
   // if(!checkContractBudget){
   // 	alert("本包预算不能为空！");
    //	return;
  //  }

	// 取出包组编号
	var packNo = [];
	for (var i = 0; i < rows.length; i++) {
		var index = $("#" + gname).datagrid('getRowIndex', rows[i]);
		packNo[i] = $("#packNo" + index).val();
	}
	//判断包组编号是否重复
	for (var i = packNo.length - 1; i >= 0; i--) {
		var targetNode = packNo[i];
		for (var j = 0; j < i; j++) {
			if (targetNode == packNo[j]) {
				alert("包组编号应不能重复!")
				return ;
			}
		}
	}
	
	var objArr = [];
	var objArrValidate = [];
	//获取选中的复选框值
	for ( var i = 0; i < rows.length; i++) {
        var index=$("#"+gname).datagrid('getRowIndex',rows[i]);
        if($("#contractBudget"+index).val()==''){
        	$("#contractBudget"+index).val('0');
        }
        if($("#maxLimitPrice"+index).val()==''){
        	$("#maxLimitPrice"+index).val('0');
        }
        if(typeof($("#purcategoryNames"+index).val())=='undefined'||$("#purcategoryNames"+index).val()==''){
        	$("#purcategoryNames"+index).val('');
        }
        if(typeof($("#purcategoryIds"+index).val())=='undefined'||$("#purcategoryIds"+index).val()==''){
        	$("#purcategoryIds"+index).val('');
        }
        objArrValidate.push(rows[i].id+"IwM"+$("#contractBudget"+index).val());
		objArr.push(rows[i].id+"IwM"+$("#packName"+index).val()+"IwM"+$("#packNo"+index).val()+"IwM"+$("#purcategoryNames"+index).val()+"IwM"+$("#purcategoryIds"+index).val()+"IwM"+$("#contractBudget"+index).val()+"IwM"+$("#maxLimitPrice"+index).val());
	}
	var objstr = objArr.join("JyR");
	 
	$.ajax({
			url: "tBProjectPackageController.do?checkbatchSaveTenderBudget",
			data: {tenderId:$("#tenderid").val(),
					totalBudget:$("#budgetTotalMoney").val(),
					jsonData:objArrValidate.toString()
				},
			type: "post",
			dataType:'json',
			success:function(d){
				if (d.msg == 'yes') {
					alert("超过项目总预算！");
					return;
				} else {
					 $.ajax({
							url : url,
							type : 'post',
							data:{ 
								jsonData:objstr
							},
							cache : false,
							success : function(jsonData) {
							alert("保存成功");
							reloadTable();
							}
						});
				}
			}
		});
	 
  }
      
      
  function reloadTable(){
   $('#tBProjectPackageList').datagrid('reload');
  }
  function setMaxLimitPrice(index){
	  var contractBudget=$("#contractBudget"+index).val();
	 // if(contractBudget==''){
    //	  alert("本包预算不能为空！");
    //	  return;
     // }else{
	  var val=/^\d+(\.\d+)?$/;
	  if(contractBudget!=''){
		  if (!val.test(contractBudget)) {  
				alert("请输入正确的数额！");
				return;
		   }else{
		    $("#maxLimitPrice"+index).val(contractBudget);
		   }
      }else{
			$("#contractBudget"+index).val('0');
	   }
}
  
function saveOnePack(packid,index){
	 var packName=$("#packName"+index).val();
	  var packNo=$("#packNo"+index).val();
	  var purcategoryNames=$("#purcategoryNames"+index).val();
	  var purcategoryIds=$("#purcategoryIds"+index).val();
	  var contractBudget=$("#contractBudget"+index).val();
	  var maxLimitPrice=$("#maxLimitPrice"+index).val();
	  var packageid = $("#id"+index).val();
	  $.ajax({
			url: "tBProjectPackageController.do?checkTenderBudget",
			data: {tenderId:$("#tenderid").val(),
					totalBudget:$("#budgetTotalMoney").val(),
					thisMoney:$("#contractBudget"+index).val(),
					packageid:packageid
					},
			type: "post",
			dataType:'json',
			success:function(d){
				if (d.msg == 'yes') {
					alert("超过项目总预算！");
					return;
				} else {
					 $.ajax({
							url : 'tBProjectPackageController.do?doUpdate',
							type : 'post',
							data:{ 
								id:packid,
								packName:packName,
								packNo:packNo,
								purcategoryNames:purcategoryNames,
					            purcategoryIds:purcategoryIds,
					            contractBudget:contractBudget,
					            maxLimitPrice:maxLimitPrice
							},
							cache : false,
							success : function(data) {
								alert("保存成功");
							}
						});
				}
			}
		});
}