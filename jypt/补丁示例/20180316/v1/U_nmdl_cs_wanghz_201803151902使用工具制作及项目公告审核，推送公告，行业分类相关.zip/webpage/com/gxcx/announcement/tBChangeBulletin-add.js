$(function(){
	//初始化加载
	showChangeSelect();
	showReDoBiddingFileSelect();
//	var isChangetime = $("input:radio[name=isChangetime]:checked").val();
//	 if(isChangetime=='1'){//需要变更时间时候，根据业务规则控制时间
//	timeshowSaleDocSelect();
//	timeshowSaleDocDate();
//	 }
});

var biddocjavascript={};
var isFinish1=0;//工具未完成
var selectIds='';//选择的阶段id
//切换是否切换变更时间
function showChangeSelect(){
	var isChangetime = $("input:radio[name=isChangetime]:checked").val();
    if(isChangetime=='0'){
	    $("#isSaleDocFeeId_1").hide();
	    $("#isSaleDocFeeId_2").hide();
	    $("#isSaleDocFeeId_3").hide();
	    $("#isSaleDocFeeId_4").hide();
	    $("#isSaleDocFeeId_5").hide();
	    $("#isSaleDocFeeId_6").hide();
    }else{
	    $("#isSaleDocFeeId_1").show();
	    $("#isSaleDocFeeId_2").show();
	    $("#isSaleDocFeeId_3").show();
	    $("#isSaleDocFeeId_4").show();
	    var isSaleDocFee = $("#isSaleDocFee").val();//是否收取标书费
		var isSaleOnline = $("#isSaleOnline").val();//是否在线售卖标书
		if(isSaleDocFee=='1'&&isSaleOnline=='1'){
			$("#isSaleDocFeeId_5").show();
		}
	    $("#isSaleDocFeeId_6").show();
//	    timeshowSaleDocSelect();
//		timeshowSaleDocDate();
		if($("#isRemoteOpening").val()=='0'){
			 $("#isSaleDocFeeId_6").hide();
		}else{
			if($("#isTwoBidOpening").val()=='0'){//不是两步招标
				$("#isSaleDocFeeId_6").hide();
				$("#oldopenBidStartDateId").text('原开标时间:');
				$("#openBidStartDateId").text('开标时间:');
			}else{//是两步招标
				 $("#isSaleDocFeeId_6").show();
				$("#oldopenBidStartDateId").text('原经济标开标时间:');
				$("#openBidStartDateId").text('经济标开标时间:');
			}
		}
		
	}
   
}
  
//切换是否重新上传招标文件
function showReDoBiddingFileSelect(){
	var isReDoBiddingFile = $("input:radio[name=isReDoBiddingFile]:checked").val();
    if(isReDoBiddingFile=='0'){
	    $("#isReDoBiddingFile1").hide();
	    $("#isReDoBiddingFile2").hide();
    }else{//重新上传招标文件
	    $("#isReDoBiddingFile1").show();
	    $("#isReDoBiddingFile2").show();
	    var procfileId='';
    	$("input[name='packname']").each(function(i,n){
    		if($(n).attr("checked")== 'checked'){
    			procfileId=$(n).attr("procfileId");
    		}
    	})
    	var flagFile=1;
    	$("input[name='packname']").each(function(i,n){
    		if($(n).attr("checked")== 'checked'){
    			 if($(n).attr("procfileId")!=procfileId)
    			{
    				 flagFile=0; 
    			}
    			 if($(n).attr("procfileId")=='')
     			{
     				 flagFile=2; 
     			}
    		}
    	})
    	if(flagFile==0){
    		alert('请在同一招标文件下的重新制作招标文件');
    		$("input[name='packname']").each(function(i,n){
        		if($(n).attr("checked")== 'checked'){
        			var stageid=$(n).attr("stageid");
        			$("#"+stageid).attr("checked",false);
        		}
        	})
    		return;
    	}
    	if(flagFile==2){
    		alert('该项目标段还未制作过招标文件');
    		$("input[name='packname']").each(function(i,n){
        		if($(n).attr("checked")== 'checked'){
        			var stageid=$(n).attr("stageid");
        			$("#"+stageid).attr("checked",false);
        		}
        	})
    		return;
    	}
	}
}
//保存并生成公告
function neibuClick() {
	if($("#projInput").val()=="" || $("#projInput").val()==null){
		alert("项目信息不能为空！");
		return;
	}
	if($("#title").val()=="" || $("#title").val()==null){
		alert("公告标题不能为空！");
		return;
	}
	var isChangetime = $("input:radio[name=isChangetime]:checked").val();
	if(isChangetime=='1')//时间变更时
		{
		//增加了时间的校验
		/*if(checkDate()==false){//时间校验
			return;
		}*/
		}
	
    var tenderIds = [];//选择的标段id
    $('input[type=checkbox][name=packname]:checked').each(function(){
  		tenderIds.push(this.value);
    })
    if(tenderIds.length==0){
    	alert("请选择标段");
		return;
	}else{
		$("#packids").val(tenderIds.toString());
	}
    $("#saveid").attr("disabled",true);
    var isChangetime = $("input:radio[name=isChangetime]:checked").val();
    var isReDoBiddingFile = $("input:radio[name=isReDoBiddingFile]:checked").val();//是否重新上传招标文件
    
    if(isReDoBiddingFile=='1'){
    	var sgsize=$("#purfileidDivSuccess").find(".uploadify-queue-item").length;
    	var gjsize=$("#purfileidDivSuccess").find("table tr td").length;
    	if((sgsize+gjsize)>1){
    	  alert('只能上传一个招标文件!');
    	  $("#saveid").attr("disabled",false);
    	  return;
    	}
    	if((sgsize+gjsize)<1){
      	  alert('必需上传招标文件才可以提交!');
      	  $("#saveid").attr("disabled",false);
      	  return;
      	}
    }
    
    var stageids='';
		$("input[name='packname']").each(function(i,n){
			if($(n).attr("checked")== 'checked'){
				if(stageids!=''){
					stageids+=",";
				}
				stageids = stageids+$(n).attr("stageid");
			}
		})
	if(stageids.indexOf('undefined')!=-1)
		{
			stageids=$("#stageids").val();
		}
		$("#stageids").val(stageids);
		var stageType = $("#phaseType").val();
		var tBProjectRuleEntityId = $("#tBProjectRuleEntityId").val();
		
    $.ajax({
		url : 'changeBulletinController.do?doAddChangeBulletin',
		type : 'post',
		data:{
			tenderIds:tenderIds.toString(),
			title:$("#title").val(),
			id:$("#id").val(),
			effectStartDate:$("#effectStartDate").val(),
			effectEndDate:$("#effectEndDate").val(),
			submitStartDate:$("#submitStartDate").val(),
			submitEndDate:$("#submitEndDate").val(),
			docSaleStartTime:$("#docSaleStartTime").val(),
			docSaleEndTime:$("#docSaleEndTime").val(),
			openBidStartDate:$("#openBidStartDate").val(),
			technicalOpenBidStartDate:$("#technicalOpenBidStartDate").val(),
			docDownloadStartTime:$("#docDownloadStartTime").val(),
			docDownloadEndTime:$("#docDownloadEndTime").val(),
			projectId:$("#projid").val(),
			isReDoBiddingFile:isReDoBiddingFile,
			procfileId:$("#procfileId").val(),
			stageids:stageids,
			stageType:stageType,
			isChangetime:isChangetime,
			isSaleOnline:$("#isSaleOnline").val(),
			isSaleDocFee:$("#isSaleDocFee").val(),
			tBProjectRuleEntityId:$("#tBProjectRuleEntityId").val()
		},
		cache : false,
		success : function(data) {
			var d = $.parseJSON(data);
			var tBBulletin = d.obj;//公告
			var id = tBBulletin.id//公告id
			var procfileId=tBBulletin.procfileId;//招标文件id
			$("#procfileId").val(procfileId);
			$("#bulletinId").val(id);
			if(isReDoBiddingFile=='1')
				{dealFile(procfileId);}else{
					window.location.href = 'changeBulletinController.do?goChangeBulletinContentAdd&id='+id;//跳转到编辑公告页面
				}
		}
	});
}
//返回
function back() {
	if($("#updateMakeType").val()=="00"){
		if($("[name='makeType']:checked").val()=='01'){
			clearBulletinFile();
		}
	}
	
	window.location.href = 'changeBulletinController.do?list';
}
///////////---------------------------校验时间开始---------------------------
//校验时间
function checkDate(){
	//报名开始时间不能小于当前时间
	var effectStartDate = $("#effectStartDate").val();
	if(effectStartDate!=''){
		var selectDate = new Date(effectStartDate.replace(/-/g, "/"));  
		var nowDate = new Date()-1000*60;
		if(selectDate<nowDate){
			alert('报名开始时间不得小于当前时间！');
			return false;
		}
	}
	
  	if($("#effectStartDate").val()!=""&&$("#effectEndDate").val()!='')
  		{
  		  if($("#effectStartDate").val()>$("#effectEndDate").val()){alert('【报名截止时间】应大于【报名开始时间】！');return false;}
  		}
  	if($("#submitStartDate").val()!=""&&$("#submitEndDate").val()!='')
		{
	      if($("#submitStartDate").val()>$("#submitEndDate").val()){alert('【投标结束时间】应大于【投标开始时间】！');return false;}
		}
  	if($("#docSaleStartTime").val()!=""&&$("#docSaleEndTime").val()!='')
	{
	  if($("#docSaleStartTime").val()>$("#docSaleEndTime").val()){alert('【招标文件售卖结束时间】应大于【招标文件售卖开始时间】！');return false;}
	}
  	/**
	if($("#submitEndDate").val()!=""&&$("#openBidStartDate").val()!='')
	{
	  if($("#submitEndDate").val()>$("#openBidStartDate").val()){alert('【开标时间】应大于等于【投标结束时间】！');return false;}
	}*/
	if($("#docDownloadStartTime").val()!=""&&$("#docDownloadEndTime").val()!='')
	{
	  if($("#docDownloadStartTime").val()>$("#docDownloadEndTime").val()){alert('【文件下载截止时间】应大于等于【文件下载开始时间】！');return false;}
	}
	/**
	if($("#submitEndDate").val()!=""&&$("#submitStartDate").val()!='')
		{
			if((newDate($('#submitEndDate').val()).getTime()-newDate($('#submitStartDate').val()).getTime())/(1000*60*60*24)<5){
				alert('【投标结束时间】距离【投标开始时间】应不小于5天');
				return false;
			}
		}
	if($("#docSaleEndTime").val()!=""&&$("#docSaleStartTime").val()!='')
	{
		if((newDate($('#docSaleEndTime').val()).getTime()-newDate($('#docSaleStartTime').val()).getTime())/(1000*60*60*24)<5){
			alert('【招标文件售卖结束时间】距离【招标文件售卖开始时间】应不小于5天');
			return false;
		}
	}
	if($("#docDownloadEndTime").val()!=""&&$("#docDownloadStartTime").val()!='')
	{
		if((newDate($('#docDownloadEndTime').val()).getTime()-newDate($('#docDownloadStartTime').val()).getTime())/(1000*60*60*24)<5){
			alert('【文件下载截止时间】距离【文件下载开始时间】应不小于5天');
			return false;
		}
	}*/
	var isTwoBidOpening=$("#isTwoBidOpening").val();//是否两步开标
	if(isTwoBidOpening=='1'){
		if($("#technicalOpenBidStartDate").val()!=""&&$("#openBidStartDate").val()!=''){
			//if($("#technicalOpenBidStartDate").val()>$("#openBidStartDate").val()){alert('【商务技术标开标时间】不能大于【经济标开标时间】！');return false;}
			var aaa=timeFn($('#technicalOpenBidStartDate').val(),$('#openBidStartDate').val());
			if(aaa<=0){
				alert('【经济标开标时间】应该大于【商务技术标开标时间】！');
				return false;
			}
			
			if($("#docSaleStartTime").val()!=''){
				var techDiff=timeFn($('#docSaleStartTime').val(),$('#technicalOpenBidStartDate').val());
				if(techDiff<20){
					alert('【商务技术标开标时间】距离【招标文件售卖开始时间】应不小于20天');
					return false;
				}
			}
		}
	}else{
		if($("#docSaleStartTime").val()!=''&&$('#openBidStartDate').val()!=''){
			var diff=timeFn($('#docSaleStartTime').val(),$('#openBidStartDate').val());
			if(diff<20){
				alert('【开标时间】距离【招标文件售卖开始时间】应不小于20天');
				return false;
			}
		}
	}
		
}
  
function newDate(str){
	strall=str.split(' ');
	var datestr = strall[0].split('-');
	var timestr = new Array();
	if(strall.length>=2){
		timestr = strall[1].split(':');
	}
	var date = new Date();
	//**月份记得减一
	date.setUTCFullYear(datestr[0], datestr[1]-1, datestr[2]);
	if(timestr.length!=0){
		date.setUTCHours(timestr[0], timestr[1], timestr[2], 0);
	}
	return date;
}
///////////---------------------------校验时间结束---------------------------

///////////----------------------------选择项目标段控制开始---------------------------
//选择项目
function openTenderSelect(confirmDesc, cancelDesc) {
	var id=$("#id").val();
	var tenderid='';
	if(id!=''){tenderid=$("#projid").val();}
	$.dialog({
		width:600,
		height:500,
        id: 'LHG1976Daaa',
        title: "选择项目",
        max: false,
        min: false,
        resize: false,
        content: 'url:tBTenderProjectController.do?selectProject&tenderId='+tenderid+'&type=bulletin',
        lock:true,
        button: [
                {name: confirmDesc, callback: callbackTenderSelect, focus: true},
               	{name: cancelDesc, callback: function (){}}
             ]
        
    });
}
//点击标段
function getPack(e, bulletinId,stageid,procfileId,packstageType,isSaleOnline,isSaleDocFee){
	$("#isSaleOnline").val(isSaleOnline);
	$("#isSaleDocFee").val(isSaleDocFee);
	var flag=1;
	$("#phaseType").val(packstageType);
	$("input[name='packname']").each(function(i,n){
		if($(n).attr("checked")== 'checked'){
			 if($(n).attr("bulletinId")!=bulletinId)
			{
				 flag=0; 
			}
			 if($(n).attr("bulletinId")=='')
  			{
				 flag=2; 
  			}
		}
	})
	if(flag==0){
		alert('请选择同一招标公告的标段发布变更公告');
		$("#"+stageid).attr("checked",false);
		return;
	}
	if(flag==2){
		alert('此项目还未发布招标公告，不应变更时间!');
		$("#"+stageid).attr("checked",false);
		return;
	}
	
	var isReDoBiddingFile = $("input:radio[name=isReDoBiddingFile]:checked").val();
    if(isReDoBiddingFile=='1'){//选择招标文件变更
    	var flagFile=1;
    	$("input[name='packname']").each(function(i,n){
    		if($(n).attr("checked")== 'checked'){
    			 if($(n).attr("procfileId")!=procfileId)
    			{
    				 flagFile=0; 
    			}
    			 if($(n).attr("procfileId")=='')
     			{
     				 flagFile=2; 
     			}
    		}
    	})
    	if(flagFile==0){
    		alert('请在同一招标文件下的重新制作招标文件');
    		$("#"+stageid).attr("checked",false);
    		return;
    	}
    	if(flagFile==2){
    		alert('此项目还未制作过招标文件，不应变更文件!');
    		$("#"+stageid).attr("checked",false);
    		return;
    	}
    }
	//补充原始时间规则
    var isChangetime = $("input:radio[name=isChangetime]:checked").val();
    if(isChangetime=='1'){
    	if(isSaleDocFee=='1'&&isSaleOnline=='1'){
			$("#isSaleDocFeeId_5").show();
		}
    }
	if(isChangetime=='1'||true)//时间变更时
	{
		getTimeRule(stageid);//获取时间
//	timeshowSaleDocSelect();
//	timeshowSaleDocDate();
    }
 
}

function getTimeRule(stageid){
	var isChangetime = $("input:radio[name=isChangetime]:checked").val();
	$.ajax({
		url : 'tBProjectRuleController.do?getProjectRuleStageId&stageid='+stageid,
		type : 'post',
		data:{
		},
		cache : false,
		success : function(data) {
			var d = $.parseJSON(data);
			$("#phaseType").val(d.attributes.stagetype);//阶段类型
			var isPack=d.attributes.effectStartDate;
			var packObject = d.obj;
			var myobj=eval(packObject);
			for(var i=0;i<myobj.length;i++){
				 $("#oldeffectStartDate").text(d.attributes.effectStartDate);
				 $("#oldeffectEndDate").text(d.attributes.effectEndDate);
				 $("#oldsubmitStartDate").text(d.attributes.submitStartDate);
				 $("#oldsubmitEndDate").text(d.attributes.submitEndDate);
				 $("#olddocSaleStartTime").text(d.attributes.docSaleStartTime);
				 $("#olddocSaleEndTime").text(d.attributes.docSaleEndTime);
				
				 $("#olddocDownloadStartTime").text(d.attributes.docDownloadStartTime);
				 $("#olddocDownloadEndTime").text(d.attributes.docDownloadEndTime);
				 $("#oldtechnicalOpenBidStartDate").text(d.attributes.technicalOpenBidStartDate);
				 $("#tBProjectRuleEntityId").val(d.attributes.tBProjectRuleEntityId);
				 $("#isRemoteOpening").val(d.attributes.isRemoteOpening);//是否远程招标
				 $("#isTwoBidOpening").val(d.attributes.isTwoBidOpening);//是否两步招标
			    $("#isSaleOnline").val(d.attributes.isSaleOnline);
				$("#isSaleDocFee").val(d.attributes.isSaleDocFee);
				if(isChangetime=='1'){
					if($("#isSaleDocFee").val()=='1'&&$("#isSaleOnline").val()=='1'){
						$("#isSaleDocFeeId_5").show();
					}
				}
				 if($("#isRemoteOpening").val()=='1'){//是远程招标
					 if($("#isTwoBidOpening").val()=='1'){//是两步招标
						if(isChangetime=='1'){
							$("#isSaleDocFeeId_6").show();//显示商务标、技术标开标时间
						}
						$("#oldopenBidStartDateId").text('原经济标开标时间:');
						$("#openBidStartDateId").text('经济标开标时间:');
						$("#oldopenBidStartDate").text(d.attributes.economicOpenStartTime);
					}else{//不是两步招标
						$("#isSaleDocFeeId_6").hide();//隐藏商务标、技术标开标时间
						$("#oldopenBidStartDateId").text('原开标时间:');
						$("#openBidStartDateId").text('开标时间:');
						$("#oldopenBidStartDate").text(d.attributes.openBidStartDate);
					}
				}else{//不是远程招标
					 $("#isSaleDocFeeId_6").hide();//隐藏商务标、技术标开标时间
					 $("#oldopenBidStartDateId").text('原开标时间:');
					 $("#openBidStartDateId").text('开标时间:');
					 $("#oldopenBidStartDate").text(d.attributes.openBidStartDate);//原开标时间
				}
			} 
		}
		  
	});
}
//切换是否收取标书费
function timeshowSaleDocSelect(){
	var isSaleDocFee = $("#isSaleDocFee").val();
    if(isSaleDocFee=='0'){
	    $("#isSaleDocFeeId_5").hide();
    }else{
    	var isChangetime = $("input:radio[name=isChangetime]:checked").val();
        if(isChangetime=='1'){
	    $("#isSaleDocFeeId_5").show();
        }
	}
}
  
//切换是否在线收取标书费
function timeshowSaleDocDate(){
	var isSaleOnline = $("#isSaleOnline").val();
    if(isSaleOnline=='0'){
    	 $("#isSaleDocFeeId_5").hide();
    }else{
    	var isChangetime = $("input:radio[name=isChangetime]:checked").val();
        if(isChangetime=='1'){
    	 $("#isSaleDocFeeId_5").show();
        }
	}
}



//回调函数存储选中的值
function callbackTenderSelect() {
	var iframe = this.iframe.contentWindow;
	var names=iframe.gettendersListSelections('packidnames').toString();
	var id=iframe.gettendersListSelections('id');
	var tendername=iframe.gettendersListSelections('tendername');
	var tenderNo=iframe.gettendersListSelections('tenderno');
	var tenderNoNumber=iframe.gettendersListSelections('tenderNoNumber');
	var tenderType=iframe.gettendersListSelections('tendertype');
	$("#tenderNo").val(tenderNo);
	$("#tenderNoNumber").val(tenderNoNumber);
	$("#tenderType").val(tenderType);
	tenderNoNumber
	var projInput = "";
	var packDiv = "";
	var packids = "";
	//接收弹框的回填值
		$("#packDiv").empty();
		$.ajax({
			url : 'tBTenderProjectController.do?getPackbyTenderid&tenderId='+id+'&type=changebulletin',
			type : 'post',
			data:{
			},
			cache : false,
			success : function(data) {
				var d = $.parseJSON(data);
				var isPack=d.attributes.tBTenderProject.isPack;
				$("#isPack").val(isPack);
				var tenderType = d.msg;//资格审查方式(00:资审,01:后审)
				$("#bulletinTypeId").empty();
				if(tenderType=='00'){
					$("#bullTypeSpan2").hide();
					$("#bullTypeSpan").show();
					$("#bulletinTypeTemp").val('21');
					$("input:radio[name=bulletinType][value=01]").attr("checked",'');
					$("input:radio[name=bulletinType][value=21]").attr("checked",'checked');
				}else{
//					$("input:radio[name=bulletinType][value=21]").hide();
//					$("input:radio[name=bulletinType][value=01]").attr("checked",'checked');
					$("#bullTypeSpan").hide();
					$("#bullTypeSpan2").show();
					$("#bulletinTypeTemp").val('01');
				}
				var packObject = d.obj;//公告
				var myobj=eval(packObject);
				for(var i=0;i<myobj.length;i++){
					var packid=myobj[i].id;
					var packname=myobj[i].packName;
					var packStatus=myobj[i].packNo;
					var packstageType=myobj[i].packstageType;
					 var bulletinId=myobj[i].bulletinId;
					 var procfileId=myobj[i].procfileId;
					 var stageid=myobj[i].stageid;
					 var packNo=myobj[i].tenderNo;//包组
					 var isSaleOnline=myobj[i].isSaleOnline;
					 var isSaleDocFee=myobj[i].isSaleDocFee;
					if(tenderType=='00'){
						if(packstageType=='00'){
							if(packStatus=='00'){
								$("#packDiv").append("<input type='checkbox' title='"+packNo+"' class='"+stageid+"'  disabled='disabled' name='packname' value='"+packid+"'/><label>"+"["+packNo+"]"+packname+"</label>");
							}else{
								$("#packDiv").append("<input type='checkbox' title='"+packNo+"' class='"+stageid+"'    name='packname' onchange=\"getPack(this,'"+bulletinId+"\','"+stageid+"\','"+procfileId+"\','"+packstageType+"\','"+isSaleOnline+"\','"+isSaleDocFee+"\');\" stageid='"+stageid+"' id='"+stageid+"' bulletinId='"+bulletinId+"' procfileId='"+procfileId+"'  packNo='"+packNo+"' value='"+packid+"'/><label>"+"["+packNo+"]"+packname+"</label>");
						    }
						}
					}else if(tenderType=='01'){
						if(packstageType=='01'){
							if(packStatus=='00'){
								$("#packDiv").append("<input type='checkbox' title='"+packNo+"' class='"+stageid+"' disabled='disabled' name='packname' value='"+packid+"'/><label>"+"["+packNo+"]"+packname+"</label>");
							}else{
								$("#packDiv").append("<input type='checkbox' title='"+packNo+"' class='"+stageid+"'    name='packname' onchange=\"getPack(this,'"+bulletinId+"\','"+stageid+"\','"+procfileId+"\','"+packstageType+"\','"+isSaleOnline+"\','"+isSaleDocFee+"\');\" stageid='"+stageid+"' id='"+stageid+"'  bulletinId='"+bulletinId+"' procfileId='"+procfileId+"' packNo='"+packNo+"' value='"+packid+"'/><label>"+"["+packNo+"]"+packname+"</label>");
						    }
						}
					}
				} 
				$("#packDiv").append("<span id='spanid' style='display: block;clear: both;line-height: 30px;' ><a href='#' id='selectid' onclick='selectPackage()' style='border: 1px #f90 solid;border-radius: 3px;padding: 2px 5px;color: #f90;'>全选</a></span>");
				$("#projInput").val(tendername);
				$("#title").val("【"+tendername+"】"+"变更公告");
				$("#projid").val(id);
			}
		});
}
function selectPackage(){
	$("input[name='packname']:not(:disabled)").attr("checked",true);
	$("#spanid").html("<a href='#' id='selectid' onclick='selectPackageNo()' style='border: 1px #f90 solid;border-radius: 3px;padding: 2px 5px;color: #f90;'>反选</a>");
	var isChangetime = $("input:radio[name=isChangetime]:checked").val();//是否变更时间
	var isReDoBiddingFile = $("input:radio[name=isReDoBiddingFile]:checked").val();//是否重新制作招标文件
	var flag=1;
	$('input[type=checkbox][name=packname]:checked').each(function(){
		if($(this).attr("bulletinId")==''){
			flag=2; 
			$(this).attr("checked",false);
		}
	})
	if(flag==2){
		alert('此项目还未发布招标公告，不应变更时间!');
		return;
	}
    if(isReDoBiddingFile=='1'){//选择招标文件变更
    	var flagFile=1;
    	$('input[type=checkbox][name=packname]:checked').each(function(){
			if($(this).attr("procfileId")==''){
 				 flagFile=2; 
 				$(this).attr("checked",false);
 			}
    	})
    	if(flagFile==2){
    		alert('此项目还未制作过招标文件，不应变更文件!');
    		return;
    	}
    }
	var stageids="";
	$('input[type=checkbox][name=packname]:checked').each(function(){
		if(stageids!=''){
			stageids+=",";
		}
		stageids = stageids+$(this).attr("stageid");
	 })
	 if(stageids.indexOf('undefined')!=-1){
		stageids=$("#stageids").val();
	}
	
	var stageid = stageids.split(',');
	if(stageid.length>0){
		var sign="";
		var message = "";
		 $.ajax({
				url : 'changeBulletinController.do?validateChangeBulletin',
				type : 'post',
				async : false,
				data : {
					stageids:stageids,
					isChangetime:isChangetime,
					isReDoBiddingFile:isReDoBiddingFile
				},
				cache : false,
				success : function(data) {
					if ($.parseJSON(data).success) {
						sign = "yes";
					} else {
						message = $.parseJSON(data).msg;
						sign = "no";
					}
				}
			});
		 if(sign=="no"){
			 $('input[type=checkbox][name=packname]:checked').each(function(){
 				$(this).attr("checked",false);
	    	 });
			alert(message);
			return;
		 }
			
		getTimeRule(stageid[0]);
	}
}
function selectPackageNo(){
	$("input[name='packname']:not(:disabled)").attr("checked",false);
	$("#spanid").html("<a href='#' id='selectid' onclick='selectPackage()' style='border: 1px #f90 solid;border-radius: 3px;padding: 2px 5px;color: #f90;'>全选</a>");
}
///////////----------------------------选择项目标段控制结束---------------------------

////////------------------重新上传招标文件开始-------------
//使用工具制作招标文件
function makePurchaseFile(packCode){//分包按项目制作，跟按项目制作不传packCode
	// if($("#isInstallBidingTools").val()=="true"){
      //   alert("请安装招标文件制作工具!");return;
   // }
	if($('#packisNoMakePack').val()=='true'){packCode='';}
	var userName=$("#userName").val();
	var password=$("#password").val();
	var stageType = $("#phaseType").val();
	var tenderNo=$("#tenderNo").val();
	var isPack=$("#isPack").val();
	var tenderType=$("#tenderType").val();
	var packNo='';

	var stageids='';
	 $('input[type=checkbox][name=packname]:checked').each(function(){
		 if(packNo!=''){
			 packNo+=",";
			}
			packNo = packNo+$(this).attr("packNo");
			if(stageids!=''){
				stageids+=",";
			}
			stageids = stageids+$(this).attr("stageid");
	 })
	//if($("#packids").val()=='') {//未重新添加
	 /*
		$("input[name='packname']").each(function(i,n){
			if($(n).attr("checked")== 'checked'){
				if(packNo!=''){
					packNo+=",";
				}
				packNo = packNo+$(n).attr("packNo");
				if(stageids!=''){
					stageids+=",";
				}
				stageids = stageids+$(n).attr("stageid");
			}
		})
		*/
	//}
	if(stageids.indexOf('undefined')!=-1)
		{
			stageids=$("#stageids").val();
			packNo=$("#packCodes").val();
		}
    if(packNo==''||typeof(packNo) == "undefined"){
    	alert('请选择项目包组制作文件');
		return;
    }
    $("#stageids").val(stageids);
    //00未分包 01分包
    var isPackValue='';
    if(isPack==0)
    {
    	isPackValue='00';
    }
    if(isPack==1)
    {isPackValue='01';}
    var serviceUrl=$("#applicationInternetAddress").val();
    var tenderNoNumber=  $("#tenderNoNumber").val();
	//var url = "gxtbm://userName="+userName+"&password="+password+"&packCodes="+packNo+"&tenderNo="+tenderNo+"&stageIds="+stageids+"&stageType="+stageType+"&isPack="+isPackValue+"&serviceUrl="+serviceUrl+"&mode=01"+"&tenderNoNumber="+tenderNoNumber+"&tenderType="+tenderType;
	
	/////////////////////////////////////////////////
	var url = "gxtbm://userName="+userName+"&password="+password+"&tenderNo="+tenderNo+"&stageType="+stageType+"&isPack="+isPackValue+"&serviceUrl="+serviceUrl+"&mode=01"+"&tenderNoNumber="+tenderNoNumber+"&tenderType="+tenderType;
    //alert(url);
	 $.ajax({
			url: "tBProjectProcfileBizController.do?makePurchaseFile",
			data: {tenderNoNumber:tenderNoNumber,
					stageids:stageids,
					packNos:packNo,
					projectProcfileBizId:$("#projectProcfileBizId").val()
					},
			type: "post",
			success:function(d){
				var data = $.parseJSON(d);
				 if (data.success == true) {
					url+="&timeStamp="+data.obj.timeStamp;
					$("#projectProcfileBizId").val(data.obj.id);
					$("#gjtjDiv").removeClass("hidden");//工具提交显示出来
					$("#sgtjDiv").addClass("hidden");//保存提交隐藏
					window.open(url, "_self");
					selectIds=stageids;
					isFinish1=0;//重新监听
					setInterval(backLogin1, 2000);
    			 }
			}
		});
	/////////////////////////////////////////////////
	
}

//每2秒检测是否完成制作招标文件
function backLogin1() {
	if(isFinish1==0||true)
		{
			$.ajax({
					url : 'tBTenderProcfileController.do?checkProcFiles&exceptionApply=true&stageids='+selectIds,
				type : 'post',
				data:{ 
					projectProcfileBizId:$("#projectProcfileBizId").val()
				},
				cache : false,
				success : function(data) {
					var d = $.parseJSON(data);
					var packObject = d.obj;// 公告
					var tBTenderProcfileId=d.attributes.tBTenderProcfileId;
					if(tBTenderProcfileId!=''&&tBTenderProcfileId!=$("#procfileId").val())//未生成找不文件id且重新修改
						{isFinish1=1;//监听完毕
						$("#procfileId").val(tBTenderProcfileId);
						$("#purfileidDivSuccess").load("cgUploadController.do?viewFile&cgFormId="+tBTenderProcfileId+"&cgFormField=purfileid&cgFormName=t_b_tender_procfile&deleteFlag=true");
						$("#attrationidDivSuccess").load("cgUploadController.do?viewFile&cgFormId="+tBTenderProcfileId+"&cgFormField=attrationid&cgFormName=t_b_tender_procfile&deleteFlag=true");
						
						}
				
				}
			});
		}
}

/////////------------------重新上传招标文件结束------------

///---------------------手动上传招标文件开始-------------

//上传附件
//function dealFile(procfileId) {
//	//上传附件处理
//	$("#cgFormId_attrationid").val(procfileId );
//	var selectNum = $("#attrationid").data('uploadify').queueData.queueLength*1 ;
//	biddocjavascript.uploadStandby = selectNum;
//	if(biddocjavascript.uploadStandby == 0 ){
//	} else{
//		$('#attrationid').uploadify('upload', '*');
//	}
//	//招标文件上传
//	$("#cgFormId_purfileid").val( procfileId );
//	var selectNum2 = $("#purfileid").data('uploadify').queueData.queueLength*1 ;
//	biddocjavascript.uploadStandby += selectNum2;
//	if(biddocjavascript.uploadStandby == 0 ){
//		biddocjavascript.uploadToList();//没有上传附件直接返回
//	} else{
//		$("#purfileid").uploadify('upload', '*');//上传附件
//	}
//	}
//
//var biddocjavascript={};
//biddocjavascript.uploadStandby = 0;// 计算附件数量
//biddocjavascript.uploadComplete = 0;// 计算完成数量
//var isFinish=0;//工具未完成
//var selectIds='';//选择的阶段id
////准备跳转列表前处理函数
//biddocjavascript.uploadToList = function(){
//	biddocjavascript.backToList();
////假如是导入的招标文件，且提交时
////var projid=$("#projid").val();
////var phaseType = $("#phaseType").val();
////var stageids=$("#stageids").val();
////alert(stageids);
////	$.ajax({
////		url : 'tBTenderProcfileController.do?saveExpertProcfile&exceptionApply=true&stageids='+stageids+'&projid='+projid+'&phaseType='+phaseType,
////		type : 'post',
////		data:{ 
////		},
////		cache : false,
////		success : function(data) {
////			biddocjavascript.backToList();
////		}
////	});
//}
////上传附件后回调函数
//biddocjavascript.uploadToListSucess=function() {
////假如附件数量=完成数量则返回列表
//biddocjavascript.uploadComplete += 1;
//if(biddocjavascript.uploadComplete == biddocjavascript.uploadStandby){
//	biddocjavascript.uploadToList();
//}
//}

//返回列表页面
biddocjavascript.backToList = function(){
	var id=$("#bulletinId").val();
	window.location.href = 'changeBulletinController.do?goChangeBulletinContentAdd&id='+id;//跳转到编辑公告页面
}


//////------------------手动上传招标文件结束-------------


//时间非空校验
function checkDateEmpty() {
	if ($("#effectStartDate").val() == ""
			|| $("#effectStartDate").val() == null) {
		alert("报名开始时间不能为空！");
		return false;
	}
	if ($("#effectEndDate").val() == "" || $("#effectEndDate").val() == null) {
		alert("报名截止时间不能为空！");
		return false;
	}

	if ($("#docDownloadStartTime").val() == ""
			|| $("#docDownloadStartTime").val() == null) {
		alert("文件下载开始时间不能为空！");
		return false;
	}
	if ($("#docDownloadEndTime").val() == ""
			|| $("#docDownloadEndTime").val() == null) {
		alert("文件下载截止时间不能为空！");
		return false;
	}

	if ($('#flage').val() == 'yes') {
		if ($("input:radio[name=isSaleOnline]:checked").val() == "1"
				&& $("input:radio[name=isSaleDocFee]:checked").val() == "1") {
			if ($("#docSaleStartTime").val() == ""
					|| $("#docSaleStartTime").val() == null) {
				alert("招标文件售卖开始时间不能为空！");
				return false;
			}
			if ($("#docSaleEndTime").val() == ""
					|| $("#docSaleEndTime").val() == null) {
				alert("招标文件售卖结束时间不能为空！");
				return false;
			}
		}
		/**
		if ($("input:radio[name=isRemoteOpening]:checked").val() == "1"
			&& $("input:radio[name=isTwoBidOpening]:checked").val() == "1") {
			if ($("#technicalOpenBidStartDate").val() == ""
					|| $("#technicalOpenBidStartDate").val() == null) {
				alert("商务标、技术标开标时间不能为空！");
				return false;
			}
		}*/
	}

	if ($("#submitStartDate").val() == ""
			|| $("#submitStartDate").val() == null) {
		alert("投标开始时间不能为空！");
		return false;
	}
	if ($("#submitEndDate").val() == "" || $("#submitEndDate").val() == null) {
		alert("投标结束时间不能为空！");
		return false;
	}
	
	var isTwoBidOpening=$("#isTwoBidOpening").val();//是否两步开标
	if(isTwoBidOpening=='1'){//如果是两步开标
		var technicalOpenBidStartDate= $("#technicalOpenBidStartDate").val();
		if(technicalOpenBidStartDate==''||technicalOpenBidStartDate==null){
			alert("商务技术标开标时间不能为空！");
			return false;
		}
		if ($("#openBidStartDate").val() == ""|| $("#openBidStartDate").val() == null) {
			alert("经济开标时间不能为空！");
			return false;
		}
	}else{
		if ($("#openBidStartDate").val() == ""|| $("#openBidStartDate").val() == null) {
			alert("开标时间不能为空！");
			return false;
		}
	}
}


function setChangeTimes(){
	var effectStartDate = $("#effectStartDate").val();//报名开始时间
	var effectEndDate =$("#effectEndDate").val();//报名结束时间
	
	$("#docDownloadStartTime").val(effectStartDate);//文件下载开始时间
	$("#docDownloadEndTime").val(effectEndDate);//文件下载结束时间
	
	var isSaleOnline=$("#isSaleOnline").val();//是否在线售卖标书费
	var isSaleDocFee=$("#isSaleDocFee").val();//是否收取标书费
	if(isSaleOnline=='1'&&isSaleDocFee=='1'){
		$("#docSaleStartTime").val(effectStartDate);
		$("#docSaleEndTime").val(effectEndDate);
	}
	$("#submitStartDate").val(effectStartDate);//投标开始时间默认为报名时间
}

function openBidToSubmitEnd(){
	var isTwoBidOpening=$("#isTwoBidOpening").val();//是否两步开标
	if(isTwoBidOpening=='0'){
		var openBidStartDate= $("#openBidStartDate").val();//开标时间
		var submitEndDate = $("#submitEndDate").val();
		if(openBidStartDate!=''){
		//	if(submitEndDate==''){
			   $("#submitEndDate").val(openBidStartDate);
		//	}
		}
	}
}
function tecOpenBidToSubmitEnd(){
	var isTwoBidOpening=$("#isTwoBidOpening").val();//是否两步开标
	if(isTwoBidOpening=='1'){
		var technicalOpenBidStartDate= $("#technicalOpenBidStartDate").val();//商务技术标开标时间
		var submitEndDate = $("#submitEndDate").val();//投标截止时间
		if(technicalOpenBidStartDate!=''){
		//	if(submitEndDate==''){
			   $("#submitEndDate").val(technicalOpenBidStartDate);
		//	}
		}
	}
}
function setOpenbidStartTime(){
	var submitEndDate =$("#submitEndDate").val();//投标结束时间
	if(submitEndDate!=''){
		var isTwoBidOpening=$("#isTwoBidOpening").val();//是否两步开标
		if(isTwoBidOpening=='1'){
			 $("#technicalOpenBidStartDate").val(submitEndDate);
		}else{
			$("#openBidStartDate").val(submitEndDate);
		}
	}
}


function timeFn(d1,d2) {//di作为一个变量传进来
    //如果时间格式是正确的，那下面这一步转化时间格式就可以不用了
    var dateBegin = new Date(d1.replace(/-/g, "/"));//将-转化为/，使用new Date
    var dateEnd =  new Date(d2.replace(/-/g, "/"));//将-转化为/，使用new Date
    var dateDiff = dateEnd.getTime() - dateBegin.getTime();//时间差的毫秒数
    var dayDiff = Math.floor(dateDiff / (24 * 3600 * 1000));//计算出相差天数
    return dayDiff;
}