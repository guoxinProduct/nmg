$(function() {
    $("#formobj").Validform({
        tiptype: 1,
        btnSubmit: "#btn_sub",
        btnReset: "#btn_reset",
        ajaxPost: true,
		beforeSubmit: function(curform) {
			$(".btn").attr("disabled", "disabled");
            return true;
        },
        callback: function(data) {
            if (data.success == true) {
			     var win = frameElement.api.opener;
                 win.reloadTable();
 				 win.tip(data.msg);
 				 frameElement.api.close();
            } else {
                if (data.responseText == '' || data.responseText == undefined) {
                    $.messager.alert('错误', data.msg);
                    $.Hidemsg();
                } else {
                    try {
                        var emsg = data.responseText.substring(data.responseText.indexOf('错误描述'), data.responseText.indexOf('错误信息'));
                        $.messager.alert('错误', emsg);
                        $.Hidemsg();
                    } catch(ex) {
                        $.messager.alert('错误', data.responseText + '');
                    }
                }
                return false;
            }
        }
    });
});

//保存公告
function neibuClick() {
	if($("#projInput").val()=="" || $("#projInput").val()==null){
		alert("项目信息不能为空！");
		return;
	}
	if($("#title").val()=="" || $("#title").val()==null){
		alert("公告标题不能为空！");
		return;
	}
    var tenderIds = "";//选择的标段id串
    $('input[type=checkbox][name=packname]').each(function(){
  	    if(this.checked)
  		    tenderIds += this.value+",";
    })
    if(tenderIds=="" || tenderIds==null){
    	alert("请选择标段");
		return;
	}else{
		tenderIds = tenderIds.substring(0,tenderIds.length-1);
		$("#packids").val(tenderIds);
	}
  
    $(".btn").attr("disabled", "disabled");
    $.ajax({
		url : 'tBCgBidBulletinController.do?doAdd',
		type : 'post',
		data:{
			tenderIds:tenderIds,
			title:$("#title").val(),
			bulletinType:$("#bulletinType").val(),
			effectStartDate:$("#effectStartDate").val(),
			effectEndDate:$("#effectEndDate").val(),
			projectId:$("#projid").val()
		},
		cache : false,
		success : function(data) {
			var d = $.parseJSON(data);
			//公告
			var tBBulletin = d.obj;
			//公告id
			var id = tBBulletin.id;
			
			window.location.href = 'tBCgBidBulletinController.do?goBidBulletinContentAdd&id='+id;
		}
	});
}
  //返回
  function back() {
		var loadPageUrl = parent.document.getElementById("loadPageUrl");
		var loadPageUrlStr  = (loadPageUrl!=null&&loadPageUrl!="")?$(loadPageUrl).val():'';
		window.location.href = (loadPageUrlStr!=null&&loadPageUrlStr!="")?loadPageUrlStr:'tBCgBidBulletinController.do?list';
  }
 
  //选择项目
  function openTenderSelect(confirmDesc, cancelDesc) {
		$.dialog({
			width:600,
			height:500,
	        id: 'LHG1976Daaa',
	        title: "选择项目",
	        max: false,
	        min: false,
	        resize: false,
	        content: 'url:tBProjectFileController.do?selectProjectForBidResult',
	        lock:true,
	        button: [
	                 {name: confirmDesc, callback: callbackTenderSelect, focus: true},
	                 {name: cancelDesc, callback: function (){}}
	             ]
	        
	    });
	}

	//回调函数存储选中的值
	function callbackTenderSelect() {
		var iframe = this.iframe.contentWindow;
		var names=iframe.gettendersListSelections('packidnames').toString();
		var id=iframe.gettendersListSelections('id');
		var tendername=iframe.gettendersListSelections('tendername');
		var projInput = "";
		var packDiv = "";
		var packids = "";
		//接收弹框的回填值
			$("#packDiv").empty();
			$.ajax({
					url : 'tBProjectFileController.do?getPackListbyTenderidForBidResult&tenderId='+id,
					type : 'post',
					data:{
					},
					cache : false,
					success : function(data) {
						var d = $.parseJSON(data);
						var packObject = d.obj;//公告
						var myobj=eval(packObject);
						for(var i=0;i<myobj.length;i++){
						    var packid=myobj[i].id;
						    var packname=myobj[i].packName;
						    var packStatus=myobj[i].packNo;
						    if(packStatus=='00'){
							    $("#packDiv").append("<input type='checkbox' disabled='disabled' name='packname' value='"+packid+"'/>"+packname);
						    }else{
					    	    $("#packDiv").append("<input type='checkbox' name='packname' value='"+packid+"'/>"+packname);
					        }
						} 
							$("#projInput").val(tendername);
							$("#projid").val(id);
							$("#title").val("【"+tendername+"】"+"中标结果公示");
					}
			});
	}
