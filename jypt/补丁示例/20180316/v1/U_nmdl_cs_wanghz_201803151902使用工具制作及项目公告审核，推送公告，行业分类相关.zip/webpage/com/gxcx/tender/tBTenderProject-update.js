
//保存
function save() {
	var tenderno=$("#tenderno").val();
	if(tenderno == ""){
		$("#tendernoCheck").html('编号不能为空！');
		$("#tendernoCheck").addClass("Validform_wrong");
		$("#tendernoCheck").removeClass("Validform_right");
		return;
	}
	if(tenderno != "" && tenderno.length > 50){
		$("#tendernoCheck").html('编号不能超过50个字符！');
		$("#tendernoCheck").addClass("Validform_wrong");
		$("#tendernoCheck").removeClass("Validform_right");
		return;
	}
	var reg =/[\"\'\#\%\&\<>\{}\=\\]+/;
	if (reg.test(tenderno)) {
 	 	$("#tendernoCheck").html('项目编号不能含有非法字符!');
		$("#tendernoCheck").addClass("Validform_wrong");
		$("#tendernoCheck").removeClass("Validform_right");
 	 	return;
	} 
	//二次招标的项目，不进行项目编号重复性校验操作
	var sourceTenderId = $("#sourceTenderId").val();
	//if (sourceTenderId == undefined || sourceTenderId == "") {
		$.ajax({
			url: "tBTenderProjectController.do?checkTenderNo",
			data: {tenderno:tenderno,
					id:$("#id").val(),
					sourceTenderId:sourceTenderId
					},
			type: "post",
			dataType:'json',
			success:function(d){
				if (d.msg == '00') {
					$("#tendernoCheck").html('编号已存在！');
					$("#tendernoCheck").addClass("Validform_wrong");
					$("#tendernoCheck").removeClass("Validform_right");
					alert('编号已存在！');
					//$("#tenderno").focus();
					return ;
				} 
				/**else if(d.msg == '02') {
					$("#tendernoCheck").html('项目编码不能包含汉字或中文符号！');
					$("#tendernoCheck").addClass("Validform_wrong");
					$("#tendernoCheck").removeClass("Validform_right");
					alert('项目编码不能包含汉字或中文符号！');
					//$("#tenderno").focus();
					return ;
				}*/ 
				else {
					saveConfirm();
				}
			}
		});
	//}
	
}

function saveConfirm(){
	$.dialog.confirm("确认保存?", function(){
        if (checkMoney()) {
        	var jsonObj = formToJsonObject("formobj");
        	jsonObj.useStatus = "00";
        	jsonObj.tenderno = $.trim($("#tenderno").val());
        	//按钮不可用
        	$(".btn").attr("disabled", true);
        	$.ajax({
        		url : 'tBTenderProjectController.do?doUpdate&optFlag=save',
        		type : 'post',
        		data: jsonObj,
        		cache : false,
        		success : function(jsonData){
        			var data = $.parseJSON(jsonData);
        			alert(data.msg);
       			 	if (data.success == true) {
	        			//上传附件处理
	        			dealFile(data);
       			 	}
        		}
        	});
        }
	});
}

