function checkBudget(i){
	var contractBudget = $("#contractBudget"+i).val();
	var maxLimitPrice = $("#maxLimitPrice"+i).val();
	var val=/^0$|^[0-9]\d{0,15}$|^[1-9]\d{0,15}\.{1}\d{1,6}$|^0\.{1}\d{1,6}$/;
	if(contractBudget!=''){
		if (!val.test(contractBudget)) {  
			alert("请输入正确的数额！");
			return;
	   }
	}
	if(maxLimitPrice!=''){
		if (!val.test(maxLimitPrice)) {  
			alert("请输入正确的数额！");
			return;
	   }
	}
	if(maxLimitPrice!=''&&contractBudget!=''){
		if (val.test(contractBudget)&&val.test(maxLimitPrice)){
			if(parseFloat(contractBudget)<parseFloat(maxLimitPrice)){
				alert('项目预算不能小于最高限价');
				return;
			}
		}
	}
}

function save(){
	$("#btn_sub").attr("disabled","disabled");
	var checkContractBudget=true;
	var checkBudget = true;
	var checkMaxLimit = true;
	var packNum = $("#packNum").val();
	var val=/^0$|^[0-9]\d{0,15}$|^[1-9]\d{0,15}\.{1}\d{1,6}$|^0\.{1}\d{1,6}$/;
	var objArr = [];
	//获取选中的复选框值
	for ( var index = 0; index < packNum; index++) {
		if($("#contractBudget"+index).val()==''){
			$("#contractBudget"+index).val('0');
		}else{
			if (!val.test($("#contractBudget"+index).val())) {
				checkBudget = false;
		    }
		}
		if($("#maxLimitPrice"+index).val()==''){
			$("#maxLimitPrice"+index).val('0');
		}else{
			if (!val.test($("#maxLimitPrice"+index).val())) {  
				checkMaxLimit = false;
		   }
		}
		if($("#contractBudget"+index).val()!=''&&$("#maxLimitPrice"+index).val()!=''){
			if (val.test($("#contractBudget"+index).val())&&val.test($("#maxLimitPrice"+index).val())){
				if(parseFloat($("#contractBudget"+index).val())<parseFloat($("#maxLimitPrice"+index).val())){
					checkContractBudget = false;
				}
			}
		}
		objArr.push($("#id"+index).val()+"IwM"+$("#contractBudget"+index).val()+"IwM"+$("#maxLimitPrice"+index).val());
	}
	if(!checkBudget){
		alert("请输入正确的数额！");
		return;
	}
	if(!checkMaxLimit){
		alert("请输入正确的数额！");
		return;
	}
	if(!checkContractBudget){
	   alert('项目预算不能小于最高限价');
	   return;
	 }
    $.ajax({
		url : 'tBProjectPackageController.do?setMaxLimitPrice',
		type : 'post',
		data:{ 
			jsonData:objArr.toString(),
			phaseType:$("#phaseType").val(),
			tenderId:$("#tenderId").val()
		},
		cache : false,
		success : function(jsonData) {
			debugger;
		 var data = $.parseJSON(jsonData);
			console.dir(data);
			 if (data.success == true) {
				 //alert(data.attributes.totalBudget);
				frameElement.api.opener.$("#budgetTotalMoney").val(data.attributes.totalBudget);   
				frameElement.api.opener.$("#isclickSure").val('1');   
				frameElement.api.close();
			 }
			//alert("设置成功！");
			
		}
	});
}
function back(){
	frameElement.api.close();
}
