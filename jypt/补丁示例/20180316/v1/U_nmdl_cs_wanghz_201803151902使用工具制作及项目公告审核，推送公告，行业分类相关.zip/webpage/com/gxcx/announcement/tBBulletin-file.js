var isFinish=0;//工具未完成
var timer; //定时任务
var count = 0;
var flags = false;
function makeBulletinFile(){
	var bulletinId = $("#bulletinId").val();
	var stageIds = "";
	var packCodes = "";
	
	var flag = false;
	
	if($("#projInput").val()=="" || $("#projInput").val()==null){
		alert("项目信息不能为空！");
		return;
	}
	if($("#title").val()=="" || $("#title").val()==null){
		alert("公告标题不能为空！");
		return;
	}
	//增加了时间的校验
	/*if(checkDate()==false){//时间校验
		return;
	}*/
	
    var tenderIds = [];//选择的标段id
    $('input[type=checkbox][name=packname]:checked').each(function(){
  		tenderIds.push(this.value);
    })
    if(tenderIds.length==0){
    	alert("请选择标段");
		return;
	}else{
		$("#packids").val(tenderIds.toString());
	}
    
 	// 时间非空校验
	/**if (checkDateEmpty() == false) {
		return;
	}*/
    
    $("input[name='packname']").each(function(i,n){
		if($(n).attr("checked")== 'checked'){
			if(packCodes!=''){
				packCodes+=",";
			}
			packCodes = packCodes+$(n).attr("title");
			
			if(stageIds!=''){
				stageIds+=",";
			}
			stageIds = stageIds+$(n).attr("class");
		}
	})
	
	$("#saveid").attr("disabled",true);
    $("#finishid").attr("disabled",true);
	
	if(bulletinId==""){
		
	    $.ajax({
			url : 'tBBulletinController.do?doAdd',
			type : 'post',
			async : false,
			data:{
				tenderIds:tenderIds.toString(),
				title:$("#title").val(),
				bulletinType:$("#bulletinTypeTemp").val(),
				effectStartDate:$("#effectStartDate").val(),
				effectEndDate:$("#effectEndDate").val(),
				submitStartDate:$("#submitStartDate").val(),
				submitEndDate:$("#submitEndDate").val(),
				docSaleStartTime:$("#docSaleStartTime").val(),
				docSaleEndTime:$("#docSaleEndTime").val(),
				openBidStartDate:$("#openBidStartDate").val(),
				docDownloadStartTime:$("#docDownloadStartTime").val(),
				docDownloadEndTime:$("#docDownloadEndTime").val(),
				technicalOpenBidStartDate:$("#technicalOpenBidStartDate").val(),
				projectId:$("#projid").val(),
				isSaleDocByProject:$("input:radio[name=isSaleDocByProject]:checked").val(),
				isSaleBidByProject:$("input:radio[name=isSaleBidByProject]:checked").val(),
				isSaleOnline:$("input:radio[name=isSaleOnline]:checked").val(),
				isTwoBidOpening:$("input:radio[name=isTwoBidOpening]:checked").val(),
				isSaleDocFee:$("input:radio[name=isSaleDocFee]:checked").val(),
				isSaleBidFee:$("input:radio[name=isSaleBidFee]:checked").val(),
				isRemoteOpening:$("input:radio[name=isRemoteOpening]:checked").val(),
				isAuditPayment:$("input:radio[name=isAuditPayment]:checked").val(),
				iscaSignup:$("input:radio[name=iscaSignup]:checked").val(),
				isAssociationSignup:$("input:radio[name=isAssociationSignup]:checked").val(),
				isNatureSignup:$("input:radio[name=isNatureSignup]:checked").val(),
				remark:$("#remark").val(),
				makeType:$("[name='makeType']:checked").val()
			},
			cache : false,
			success : function(data) {
				flag = true;
				var d = $.parseJSON(data);
				var tBBulletin = d.obj;//公告
				var id = tBBulletin.id//公告id
				$("#bulletinId").val(id);
				$("#cgFormId").val(id);
				
				var map = d.attributes;
				$("#userName").val(map.userName);
				$("#accessToken").val(map.accessToken);
				$("#password").val(map.password);
				$("#tenderNo").val(map.tenderNo);
				$("#tenderNoNumber").val(map.tenderNoNumber);
				$("#tenderType").val(map.tenderType);
				$("#packCodes").val(map.packCodes);
				$("#stageType").val(map.stageType);
				$("#isPack").val(map.isPack);
				$("#serviceUrl").val(map.serviceUrl);
				$("#mode").val(map.mode);
				$("#generalFileType").val(map.generalFileType);
				$("#relationID").val(map.relationID);
				$("#departId").val(map.departId);
				$("#isPush").val(map.isPush);
				$("#tenderProjectType").val(map.tenderProjectType);
				
			}
		});
	    
	}else{
	    $.ajax({
			url : 'tBBulletinController.do?doUpdate',
			type : 'post',
			async : false,
			data:{
				id:$("#bulletinId").val(),
				tenderIds:tenderIds.toString(),
				title:$("#title").val(),
				bulletinType:$("#bulletinTypeTemp").val(),
				effectStartDate:$("#effectStartDate").val(),
				effectEndDate:$("#effectEndDate").val(),
				submitStartDate:$("#submitStartDate").val(),
				submitEndDate:$("#submitEndDate").val(),
				docSaleStartTime:$("#docSaleStartTime").val(),
				docSaleEndTime:$("#docSaleEndTime").val(),
				openBidStartDate:$("#openBidStartDate").val(),
				docDownloadStartTime:$("#docDownloadStartTime").val(),
				technicalOpenBidStartDate:$("#technicalOpenBidStartDate").val(),
				docDownloadEndTime:$("#docDownloadEndTime").val(),
				projectId:$("#projid").val(),
				isSaleDocByProject:$("input:radio[name=isSaleDocByProject]:checked").val(),
				isSaleBidByProject:$("input:radio[name=isSaleBidByProject]:checked").val(),
				isSaleOnline:$("input:radio[name=isSaleOnline]:checked").val(),
				isSaleDocFee:$("input:radio[name=isSaleDocFee]:checked").val(),
				isTwoBidOpening:$("input:radio[name=isTwoBidOpening]:checked").val(),
				isSaleBidFee:$("input:radio[name=isSaleBidFee]:checked").val(),
				isRemoteOpening:$("input:radio[name=isRemoteOpening]:checked").val(),
				iscaSignup:$("input:radio[name=iscaSignup]:checked").val(),
				isAuditPayment:$("input:radio[name=isAuditPayment]:checked").val(),
				isAssociationSignup:$("input:radio[name='isAssociationSignup']:checked").val(),
				isNatureSignup:$("input:radio[name='isNatureSignup']:checked").val(),
				remark:$("#remark").val(),
				makeType:$("[name='makeType']:checked").val()
				
			},
			cache : false,
			success : function(data) {
				flag = true;
				
				var d = $.parseJSON(data);
				var map = d.attributes;
				$("#userName").val(map.userName);
				$("#accessToken").val(map.accessToken);
				$("#password").val(map.password);
				$("#tenderNo").val(map.tenderNo);
				$("#tenderNoNumber").val(map.tenderNoNumber);
				$("#tenderType").val(map.tenderType);
				$("#packCodes").val(map.packCodes);
				$("#stageType").val(map.stageType);
				$("#isPack").val(map.isPack);
				$("#serviceUrl").val(map.serviceUrl);
				$("#mode").val(map.mode);
				$("#generalFileType").val(map.generalFileType);
				$("#relationID").val(map.relationID);
				$("#departId").val(map.departId);
				$("#isPush").val(map.isPush);
				$("#tenderProjectType").val(map.tenderProjectType);
			}
		});
	}
    
	if(flag){
		
		var userName = $("#userName").val();
		var accessToken = $("#accessToken").val();
		var password = $("#password").val();
		var tenderNo = $("#tenderNo").val();
		var tenderNoNumber = $("#tenderNoNumber").val();
		var tenderType = $("#tenderType").val();
		var stageType = $("#stageType").val();
		var isPack = $("#isPack").val();
		var serviceUrl = $("#serviceUrl").val();
		var mode = $("#mode").val();
		var generalFileType = $("#generalFileType").val();
		var relationID = $("#relationID").val();
		var departId = $("#departId").val();
		var isPush = $("#isPush").val();
		var tenderProjectType = $("#tenderProjectType").val();
		
		//var url = "gxtam://userName="+userName+"&accessToken="+accessToken+"&password="+password+"&tenderNo="+tenderNo+"&tenderNoNumber="+tenderNoNumber+"&tenderType="+tenderType+"&packCodes="+packCodes+"&stageType="+stageType+"&stageIds="+stageIds+"&isPack="+isPack+"&serviceUrl="+serviceUrl+"&mode="+mode+"&generalFileType="+generalFileType+"&relationID="+relationID+"&departId="+departId+"&isPush="+isPush+"&tenderProjectType="+tenderProjectType;
		var url = "gxtam://userName="+userName+"&accessToken="+accessToken+"&password="+password+"&tenderNo="+tenderNo+"&tenderNoNumber="+tenderNoNumber+"&tenderType="+tenderType+"&packCodes=&stageType="+stageType+"&stageIds=&isPack="+isPack+"&serviceUrl="+serviceUrl+"&mode="+mode+"&generalFileType="+generalFileType+"&relationID="+relationID+"&departId="+departId+"&isPush="+isPush+"&tenderProjectType="+tenderProjectType;
		window.open(url, "_self");
		isFinish=0;//重新监听
		timer = setInterval(backLogin, 2000);
	}
}


//每2秒检测是否完成制作公告文件
function backLogin(){
	if(isFinish==0 || true){
		$.ajax({
			url : 'tBBulletinController.do?checkBulletinFiles',
			type : 'post',
			data:{ 
				bulletinId:$("#bulletinId").val()
			},
			cache : false,
			success : function(data) {
				var d = $.parseJSON(data);
				var packObject = d.obj;// 公告
				var bulletinId=d.attributes.bulletinId;
				if(bulletinId!=''){//未生成找不文件id且重新修改
					isFinish=1;//监听完毕	
					$("#saveid").attr("disabled",false);
                    $("#finishid").attr("disabled", false);
					$("#bulletinId").val(bulletinId);
					$("#bulletinDivSuccess").load("cgUploadController.do?viewFile&cgFormId="+bulletinId+"&cgFormField=bulletinContent&cgFormName=t_b_tender_bulletin&deleteFlag=true");
					$("#attachmentDivSuccess").load("cgUploadController.do?viewFile&cgFormId="+bulletinId+"&cgFormField=attachment&cgFormName=t_b_tender_bulletin&deleteFlag=true");
				}
			
			}
		});
	}
}

//保存公告
function saveBulletin() {
	if($("#projInput").val()=="" || $("#projInput").val()==null){
		alert("项目信息不能为空！");
		return;
	}
	if($("#title").val()=="" || $("#title").val()==null){
		alert("公告标题不能为空！");
		return;
	}
	
    var tenderIds = [];//选择的标段id
    $('input[type=checkbox][name=packname]:checked').each(function(){
  		tenderIds.push(this.value);
    })
    if(tenderIds.length==0){
    	alert("请选择标段");
		return;
	}else{
		$("#packids").val(tenderIds.toString());
	}
    
    /**
 	// 时间非空校验
	if (checkDateEmpty() == false) {
		return;
	}
	//增加了时间的校验
	if(checkDate()==false){//时间校验
		return;
	}
	*/
	if($("#bulletinDiv").find("div").size()>0 || $("#attachmentDiv").find("div").size()>0){
		alert("文件正在上传，请稍后保存!!");
		return ;
	}
	
	$("#saveid").attr("disabled",true);
	$("#finishid").attr("disabled",true);

	saveOrUpdate();
	
	if(flags){
		var makeType = $("[name='makeType']:checked").val();
		
		$.messager.progress({ // 显示进度条  
		       title:"数据存储",  
		           text:"正在处理...",  
		           interval:300  
		          });
		
		$.ajax({
			url : 'tBBulletinController.do?createSWFFile',
			type : 'post',
			data:{
				id:$('#bulletinId').val(),
				tableName:"t_b_tender_bulletin", //保存
				cgField:"bulletinContent"
			},
			cache : false,
			success : function(data) {
				var d = $.parseJSON(data);
				if (d.success) {
					
					$.ajax({
						url : 'tBBulletinController.do?doBulletinContentAdd',
						type : 'post',
						data:{
							id:$("#bulletinId").val(),
							relstatus:"00", //保存
							makeType:makeType,
							remark:$("#remark").val()
						},
						cache : false,
						success : function(data) {
							
							$.messager.progress('close');
							
							var d = $.parseJSON(data);
							if (d.success == true) {
								alert("数据存储成功");
								backlist();
							}else{
								alert("数据存储失败");
							}
						}
					});
					
				}else{
					$.messager.progress('close');
					
					alert("公告内容文件不符合规范，请确认后重新上传");
					clearBulletinFile();
					$("#bulletinDivSuccess").empty();
					$("#attachmentDivSuccess").empty();
					$("#saveid").attr("disabled",false);
					$("#finishid").attr("disabled",false);
				}
			}
		});
	}else{
		alert("保存或修改失败!");
	}
}


//发布公告
function relBulletin() {
	if($("#projInput").val()=="" || $("#projInput").val()==null){
		alert("项目信息不能为空！");
		return;
	}
	if($("#title").val()=="" || $("#title").val()==null){
		alert("公告标题不能为空！");
		return;
	}
	
    var tenderIds = [];//选择的标段id
    $('input[type=checkbox][name=packname]:checked').each(function(){
  		tenderIds.push(this.value);
    })
    if(tenderIds.length==0){
    	alert("请选择标段");
		return;
	}else{
		$("#packids").val(tenderIds.toString());
	}
    
  /**
 	// 时间非空校验
	if (checkDateEmpty() == false) {
		return;
	}
	
	//增加了时间的校验
	if(checkDate()==false){//时间校验
		return;
	}
    */
 	
	if($("#bulletinDiv").find("div").size()>0 || $("#attachmentDiv").find("div").size()>0){
		alert("文件正在上传，请稍后提交!!");
		return ;
	}
	
 	var makeType = $("[name='makeType']:checked").val();	
	if(makeType=="00"){	//工具制作
		
		//提交时候文件不能为空保存的时候可以为空
		if($("#bulletinDivSuccess").find("table tbody tr").text().trim()=='')
		{
		  alert('请上传公告文件!');
		  return;
		}
		
	}else{	//上传
		
		//提交时候文件不能为空保存的时候可以为空
		if( $("#bulletinDivSuccess").find("table tbody tr").text().trim()=='')
		{
		  alert('请上传公告文件!');
		  return;
		}
	}
	
	$("#saveid").attr("disabled",true);
	$("#finishid").attr("disabled",true);
	
	saveOrUpdate();
	
	if(flags){
		neibuClickFlag = true;
		
		$.messager.progress({ // 显示进度条  
		       title:"数据存储",  
		           text:"正在处理...",  
		           interval:300  
		          });
		
		$.ajax({
			url : 'tBBulletinController.do?createSWFFile',
			type : 'post',
			data:{
				id:$('#bulletinId').val(),
				tableName:"t_b_tender_bulletin", //保存
				cgField:"bulletinContent"
			},
			cache : false,
			success : function(data) {
				var d = $.parseJSON(data);
				if (d.success) {
					
					$.ajax({
						url : 'tBBulletinController.do?doBulletinContentAdd',
						type : 'post',
						data:{
							id:$("#bulletinId").val(),
							relstatus:"01", //发布
							makeType:makeType,
							remark:$("#remark").val()
						},
						cache : false,
						success : function(data) {
							
							$.messager.progress('close');
							
							var d = $.parseJSON(data);
							if (d.success == true) {
								alert("数据存储成功");
								backlist();
							}else{
								alert("数据存储失败");
							}
						}
					});
					
				}else{
					
					$.messager.progress('close');
					
					alert("公告内容文件不符合规范，请确认后重新上传");
					clearBulletinFile();
					$("#bulletinDivSuccess").empty();
					$("#attachmentDivSuccess").empty();
					$("#saveid").attr("disabled",false);
					$("#finishid").attr("disabled",false);
				}
			}
		});
	}else{
		alert("保存或修改失败!");
	}
	
	
}

function saveOrUpdate(){
	var tenderIds = [];//选择的标段id
    $('input[type=checkbox][name=packname]:checked').each(function(){
  		tenderIds.push(this.value);
    })
	
	if($("#bulletinId").val()==''){
		$.ajax({
			url : 'tBBulletinController.do?doAdd',
			type : 'post',
			async : false,
			data:{
				tenderIds:tenderIds.toString(),
				title:$("#title").val(),
				bulletinType:$("#bulletinTypeTemp").val(),
				effectStartDate:$("#effectStartDate").val(),
				effectEndDate:$("#effectEndDate").val(),
				submitStartDate:$("#submitStartDate").val(),
				submitEndDate:$("#submitEndDate").val(),
				docSaleStartTime:$("#docSaleStartTime").val(),
				docSaleEndTime:$("#docSaleEndTime").val(),
				openBidStartDate:$("#openBidStartDate").val(),
				docDownloadStartTime:$("#docDownloadStartTime").val(),
				docDownloadEndTime:$("#docDownloadEndTime").val(),
				technicalOpenBidStartDate:$("#technicalOpenBidStartDate").val(),
				projectId:$("#projid").val(),
				isSaleDocByProject:$("input:radio[name=isSaleDocByProject]:checked").val(),
				isSaleBidByProject:$("input:radio[name=isSaleBidByProject]:checked").val(),
				isSaleOnline:$("input:radio[name=isSaleOnline]:checked").val(),
				isTwoBidOpening:$("input:radio[name=isTwoBidOpening]:checked").val(),
				isSaleDocFee:$("input:radio[name=isSaleDocFee]:checked").val(),
				isSaleBidFee:$("input:radio[name=isSaleBidFee]:checked").val(),
				isRemoteOpening:$("input:radio[name=isRemoteOpening]:checked").val(),
				isAuditPayment:$("input:radio[name=isAuditPayment]:checked").val(),
				iscaSignup:$("input:radio[name=iscaSignup]:checked").val(),
				isAssociationSignup:$("input:radio[name=isAssociationSignup]:checked").val(),
				isNatureSignup:$("input:radio[name=isNatureSignup]:checked").val(),
				remark:$("#remark").val(),
				makeType:$("[name='makeType']:checked").val(),
				cgFormId:$('#cgFormId').val()
			},
			cache : false,
			success : function(data) {
				flags = true;
				var d = $.parseJSON(data);
				var tBBulletin = d.obj;//公告
				var id = tBBulletin.id//公告id
				$("#bulletinId").val(id);
				$("#cgFormId").val(id);
			}
		});
	}else{
		$.ajax({
			url : 'tBBulletinController.do?doUpdate',
			type : 'post',
			async : false,
			data:{
				id:$("#bulletinId").val(),
				tenderIds:tenderIds.toString(),
				title:$("#title").val(),
				bulletinType:$("#bulletinTypeTemp").val(),
				effectStartDate:$("#effectStartDate").val(),
				effectEndDate:$("#effectEndDate").val(),
				submitStartDate:$("#submitStartDate").val(),
				submitEndDate:$("#submitEndDate").val(),
				docSaleStartTime:$("#docSaleStartTime").val(),
				docSaleEndTime:$("#docSaleEndTime").val(),
				openBidStartDate:$("#openBidStartDate").val(),
				docDownloadStartTime:$("#docDownloadStartTime").val(),
				technicalOpenBidStartDate:$("#technicalOpenBidStartDate").val(),
				docDownloadEndTime:$("#docDownloadEndTime").val(),
				projectId:$("#projid").val(),
				isSaleDocByProject:$("input:radio[name=isSaleDocByProject]:checked").val(),
				isSaleBidByProject:$("input:radio[name=isSaleBidByProject]:checked").val(),
				isSaleOnline:$("input:radio[name=isSaleOnline]:checked").val(),
				isSaleDocFee:$("input:radio[name=isSaleDocFee]:checked").val(),
				isTwoBidOpening:$("input:radio[name=isTwoBidOpening]:checked").val(),
				isSaleBidFee:$("input:radio[name=isSaleBidFee]:checked").val(),
				isRemoteOpening:$("input:radio[name=isRemoteOpening]:checked").val(),
				iscaSignup:$("input:radio[name=iscaSignup]:checked").val(),
				isAuditPayment:$("input:radio[name=isAuditPayment]:checked").val(),
				isAssociationSignup:$("input:radio[name='isAssociationSignup']:checked").val(),
				isNatureSignup:$("input:radio[name='isNatureSignup']:checked").val(),
				remark:$("#remark").val(),
				makeType:$("[name='makeType']:checked").val()
				
			},
			cache : false,
			success : function(data) {
				flags = true;
			}
		});
	}
	
	
}

//返回列表页面
function backlist(){
	var loadPageUrl = parent.document.getElementById("loadPageUrl");
	var loadPageUrlStr  = (loadPageUrl!=null&&loadPageUrl!="")?$(loadPageUrl).val():'';
	window.location.href = (loadPageUrlStr!=null&&loadPageUrlStr!="")?loadPageUrlStr:'tBBulletinController.do?list'
}


//切换公告制作方式
function changeMakeBulletin(){
	
	$.dialog.confirm("切换公告制作方式将会将之前保存的文件清除，是否切换?", function(){
		var makeType = $("[name='makeType']:checked").val();
		if(makeType!=$("#change").val()){
			$("#change").val(makeType);
			if(makeType=='00'){
				
				if( $("#bulletinDivSuccess").find("table tbody tr").text().trim()!='' || $("#attachmentDivSuccess").find("table tbody tr").text().trim()!=''){
					clearBulletinFile();
					
					$("#bulletinDivSuccess").empty(); 
					$("#attachmentDivSuccess").empty();
					$(".up").hide();
					$("#tools").show();
				}else{
					$("#bulletinDivSuccess").children().find("a").each(function(){
						$(this).append("<span id='bulletinContent"+count+"' hidden='hidden'>x</span>");
						$("#bulletinContent"+count).click();
						count++;
					});
					
					$("#attachmentDivSuccess").children().find("a").each(function(){
						$(this).append("<span id='attachment"+count+"' hidden='hidden'>x</span>");
						$("#attachment"+count).click();
						count++;
					});
					
					setTimeout(function(){
						$("#bulletinDivSuccess").empty(); 
						$("#attachmentDivSuccess").empty();
						$(".up").hide();
						$("#tools").show();
					},
					1000);
				}
				
			}else{
				
				if($("#bulletinDivSuccess").find("table tbody tr").text().trim()!=''){
					$.ajax({
						url : 'tBBulletinController.do?clearBulletinFile',
						async : false,
						type : 'post',
						data:{
							bulletinId:$("#bulletinId").val()
						},
						cache : false,
						success : function(data) {
							flag = $.parseJSON(data).success;
						}
					});
				}
				
				clearInterval(timer);
				$("#bulletinDivSuccess").empty(); 
				$("#attachmentDivSuccess").empty();
				$(".up").show();
				$("#tools").hide();
			}
			
			$("#saveid").attr("disabled",false);
		    $("#finishid").attr("disabled",false);
		}
	},function(){
		$("[name='makeType']").each(function(){
			if($("[name='makeType']").attr("checked")){
				$(this).attr("checked",false);
			}else{
				$(this).attr("checked",true);
			}
		});
	})
	
}


function clearBulletinFile(){
	$.ajax({
		url : 'tBBulletinController.do?clearBulletinFile',
		type : 'post',
		async : false,
		data:{
			bulletinId:$("#cgFormId").val()
		},
		cache : false,
		success : function(data) {
			flag = $.parseJSON(data).success;
		}
	});
}