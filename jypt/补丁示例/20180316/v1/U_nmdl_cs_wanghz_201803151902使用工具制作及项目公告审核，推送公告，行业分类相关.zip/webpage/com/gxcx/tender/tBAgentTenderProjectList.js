function detail(id) {
	window.location.href = 'tBClarificationController.do?clarificationTabs&id='+id;
}
