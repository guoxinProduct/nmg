$(function() {
	init();
});
//页面初始化
function init() {
	editor.addListener("ready", function() {
		editor.setContent($("#content").val(), false);
	});//防止在按钮按下的时候，编辑器还没初始化
}

$(function() {
	//查看模式情况下,删除和上传附件功能禁止使用
	if (location.href.indexOf("load=detail") != -1) {
		$(".jeecgDetail").hide();
	}
});

//返回
function back() {
	window.location.href = 'tBCgBidBulletinController.do?list';
}