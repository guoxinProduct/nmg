//表单提交前校验
function checkMoney() {
	var remainderMoney = parseFloat($("#remainderMoney").val());
	var contractBudget = parseFloat($("#contractBudget").val());
	if (remainderMoney<contractBudget) {
		alert('录入金额超过总预算金额！');
	  	return false;
	}
	return true;
}

//同一个项目标段编号唯一校验
function checkPackNo() {
	var packNo = $("#packNo").val();
	if(packNo == ""){
		 return;
	}else{
		var reg =/[\"\'\#\%\&\<>\{}\=\\]+/;
		if (reg.test(packNo)) {
	 	 	$("#packNoCheck").html('标段编号不能含有非法字符!');
			$("#packNoCheck").addClass("Validform_wrong");
			$("#packNoCheck").removeClass("Validform_right");
	 	 	return;
		} 
		$.ajax({
			url: "tBProjectPackageController.do?checkPackNo",
			data: {
					packNo : packNo,
					tenderid : $("#tenderid").val(),
					id: $("#id").val()
				  },
			type: "post",
			dataType:'json',
			success:function(d){
				if (d.msg == '00') {
					$("#packNoCheck").html('<font color="red">编号已存在！</font>');
					$("#packNo").focus();
				} else {
					$("#packNoCheck").html('');
				}
			}
		}) 
	}					
}


/******   选择品目     ******/
function openPurcategorySelect(confirmDesc, cancelDesc) {
	$.dialog.setting.zIndex = 9999; 
	$.dialog({content: 'url:basePurcatalogCategoryController.do?purcatacategorySelect&enable=true&searchId='+$('#purcategoryIds').val(), zIndex: 2100, title: '品目列表', lock: true, width: '400px', height: '350px', opacity: 0.4, button: [
    {name: confirmDesc, callback: callbackPurcategorySelect, focus: true},
    {name: cancelDesc, callback: function (){}}
    ]}).zindex();
}	
function callbackPurcategorySelect() {
	var iframe = this.iframe.contentWindow;
	var treeObj = iframe.$.fn.zTree.getZTreeObj("departSelect");
	//多选(enable=true)
	var nodes = treeObj.getCheckedNodes(true);
	//单选(enable=false)
	//var nodes = treeObj.getSelectedNodes();
	if(nodes.length>0){
		var ids='',names='';
		for(i=0;i<nodes.length;i++){
			var node = nodes[i];
			ids += node.id+',';
			names += node.name+',';
			//ids += node.id;
			//names += node.name;
		}
		if (ids!='') {
			 ids = ids.substr(0, ids.length-1);
		 } 
		 if (names!='') {
			 names = names.substr(0, names.length-1);
		 } 
		$('#purcategoryNames').val(names);
		$('#purcategoryNames').blur();		
		$('#purcategoryIds').val(ids);		
	}
}
function callbackPurcategoryClean(){
	$('#purcategoryNames').val('');
	$('#purcategoryIds').val('');	
}
/******   选择品目     ******/

function callbackPurcategoryClean(){
	$('#purcategoryNames').val('');
	$('#purcategoryIds').val('');	
}

function setMaxLimitPrice(){
	var contractBudget = $("#contractBudget").val();
	var ex = /^0$|^[1-9]\d{0,15}$|^[1-9]\d{0,15}\.{1}\d{1,6}$|^0\.{1}\d{1,6}$/g;
	if(contractBudget!=''){
	    if (!ex.test(contractBudget)) {  
	     	 alert("请输入数字!");
	     	 return;
	    }else{
	    	 $("#maxLimitPrice").val(contractBudget);
	    	 checkMoney();//校验金额
	    }  
	}
	
	
}

function checkPackName(){
	var packName = $("#packName").val();
	var reg =/[\"\'\#\%\&\<>\{}\=\\]+/;
	if(packName!=''){
		if (reg.test(packName)) {
	 	 	$("#packNameCheck").html('标段名称不能含有非法字符!');
			$("#packNameCheck").addClass("Validform_wrong");
			$("#packNameCheck").removeClass("Validform_right");
	 	 	return;
		} 
	}
}