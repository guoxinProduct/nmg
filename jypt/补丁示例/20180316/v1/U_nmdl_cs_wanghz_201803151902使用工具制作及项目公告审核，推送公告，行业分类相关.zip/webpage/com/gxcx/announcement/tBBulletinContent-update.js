$(function() {  
	  init();
 }); 
//页面初始化
function init(){
	editor.addListener("ready",function(){
		editor.setContent($("#content").val(), false);
		});//防止在按钮按下的时候，编辑器还没初始化
}
//编写自定义JS代码
function setContent(){
    if(editor.queryCommandState( 'source' ))
    	editor.execCommand('source');//切换到编辑模式才提交，否则有bug
            
    if(editor.hasContents()){
    	editor.sync();
	    $("#content").val(editor.getContent());
	    return "yes";
	}else{
		return "no";
	}
}

var  bulletinjavascript = {};
bulletinjavascript.uploadStandby = 0;
bulletinjavascript.uploadComplete = 0;
var state = "";
//保存公告
function saveBulletin() {
	  state = "save";
	  var flage=setContent();
	  if(flage=="no"){
		  alert("请填写公告内容");
		  return ;
	  }
	  neibuClickFlag = true; 
	  $("#saveid").attr("disabled",true);
	  $("#relid").attr("disabled",true);
	  $.ajax({
			url : 'tBBulletinController.do?doBulletinContentAdd',
			type : 'post',
			data:{
				id:$("#id").val(),
				content:$("#content").val(),
				remark:$("#remark").val()
			},
			cache : false,
			success : function(data) {
				var d = $.parseJSON(data);
				tip(d.msg);
				$("#cgFormId_attachment").val( d.obj.id );
				var selectNum = $("#attachment").data('uploadify').queueData.queueLength ;
				bulletinjavascript.uploadStandby = ( selectNum>0?selectNum:0 );
				if(bulletinjavascript.uploadStandby == 0 ){
					if($("#type").val()!='delay'){
						backlist();//没有上传附件直接返回
					}
				} else{
					$("#attachment").uploadify('upload');//上传附件
					upload();
				}
			}
		});
}

//上传附件成功后回调方法
bulletinjavascript.uploadToList = function(){
	bulletinjavascript.uploadComplete += 1;
	if(bulletinjavascript.uploadComplete == bulletinjavascript.uploadStandby ){
		if($("#type").val()=='delay' && state=="save"){//延期公告保存不跳转
		}else{
			backlist();;
		}
	}
}

//发布公告
function relBulletin() {
	  var flage=setContent();
	  if(flage=="no"){
		  alert("请填写公告内容");
		  return ;
	  }
	  neibuClickFlag = true; 
	  $("#saveid").attr("disabled",true);
	  $("#relid").attr("disabled",true);
	  $.ajax({
			url : 'tBBulletinController.do?doBulletinContentAdd',
			type : 'post',
			data:{
				id:$("#id").val(),
				content:$("#content").val(),
				remark:$("#remark").val(),
				relstatus:"01" //发布
			},
			cache : false,
			success : function(data) {
				var d = $.parseJSON(data);
				tip(d.msg)
				$("#cgFormId_attachment").val( d.obj.id );
				var selectNum = $("#attachment").data('uploadify').queueData.queueLength ;
				bulletinjavascript.uploadStandby = ( selectNum>0?selectNum:0 );
				if(bulletinjavascript.uploadStandby == 0 ){
					backlist();//没有上传附件直接返回
				} else{
					$("#attachment").uploadify('upload');//上传附件
					upload();
				}
			}
		});
}


function backlist(){
	var loadPageUrl = parent.document.getElementById("loadPageUrl");
	var loadPageUrlStr  = (loadPageUrl!=null&&loadPageUrl!="")?$(loadPageUrl).val():'';
	window.location.href = (loadPageUrlStr!=null&&loadPageUrlStr!="")?loadPageUrlStr:'tBBulletinController.do?list'
}
  
//返回
function back() {
	window.location.href = 'tBBulletinController.do?goUpdate&id='+$("#id").val();
}

//返回延期公告
function backDelay(){
	window.location.href = 'tBBulletinController.do?goUpdateDelay&id='+$("#id").val();
}