
//通用弹出式文件上传
function commonUpload(callback){
    $.dialog({
           content: "url:systemController.do?commonUpload",
           lock : true,
           title:"文件上传",
           zIndex:2100,
           width:700,
           height: 200,
           parent:windowapi,
           cache:false,
       ok: function(){
               var iframe = this.iframe.contentWindow;
               iframe.uploadCallback(callback);
                   return true;
       },
       cancelVal: '关闭',
       cancel: function(){
       } 
   });
}
function browseImages(inputId, Img) {// 图片管理器，可多个上传共用
		var finder = new CKFinder();
		finder.selectActionFunction = function(fileUrl, data) {//设置文件被选中时的函数 
			$("#" + Img).attr("src", fileUrl);
			$("#" + inputId).attr("value", fileUrl);
		};
		finder.resourceType = 'Images';// 指定ckfinder只为图片进行管理
		finder.selectActionData = inputId; //接收地址的input ID
		finder.removePlugins = 'help';// 移除帮助(只有英文)
		finder.defaultLanguage = 'zh-cn';
		finder.popup();
	}
function browseFiles(inputId, file) {// 文件管理器，可多个上传共用
	var finder = new CKFinder();
	finder.selectActionFunction = function(fileUrl, data) {//设置文件被选中时的函数 
		$("#" + file).attr("href", fileUrl);
		$("#" + inputId).attr("value", fileUrl);
		decode(fileUrl, file);
	};
	finder.resourceType = 'Files';// 指定ckfinder只为文件进行管理
	finder.selectActionData = inputId; //接收地址的input ID
	finder.removePlugins = 'help';// 移除帮助(只有英文)
	finder.defaultLanguage = 'zh-cn';
	finder.popup();
}
function decode(value, id) {//value传入值,id接受值
	var last = value.lastIndexOf("/");
	var filename = value.substring(last + 1, value.length);
	$("#" + id).text(decodeURIComponent(filename));
}

$(function() {  
	  init();
 }); 
//页面初始化
function init(){
	editor.addListener("ready",function(){
		editor.setContent($("#content").val(), false);
		});//防止在按钮按下的时候，编辑器还没初始化
}
//编写自定义JS代码
function setContent(){
    if(editor.queryCommandState( 'source' ))
    	editor.execCommand('source');//切换到编辑模式才提交，否则有bug
            
    if(editor.hasContents()){
    	editor.sync();
	    $("#content").val(editor.getContent());
	}
}

$(function() {
    $("#formobj").Validform({
        tiptype: 1,
        btnSubmit: "#btn_sub",
        btnReset: "#btn_reset",
        ajaxPost: true,
		beforeSubmit: function(curform) {
            var tag = true;
			//提交前处理
            return tag;
        },
        usePlugin: {
            passwordstrength: {
                minLen: 6,
                maxLen: 18,
                trigger: function(obj, error) {
                    if (error) {
                        obj.parent().next().find(".Validform_checktip").show();
                        obj.find(".passwordStrength").hide();
                    } else {
                        $(".passwordStrength").show();
                        obj.parent().next().find(".Validform_checktip").hide();
                    }
                }
            }
        },
        callback: function(data) {
            if (data.success == true) {
			     var win = frameElement.api.opener;
                 win.reloadTable();
 				 win.tip(data.msg);
 				 frameElement.api.close();
            } else {
                if (data.responseText == '' || data.responseText == undefined) {
                    $.messager.alert('错误', data.msg);
                    $.Hidemsg();
                } else {
                    try {
                        var emsg = data.responseText.substring(data.responseText.indexOf('错误描述'), data.responseText.indexOf('错误信息'));
                        $.messager.alert('错误', emsg);
                        $.Hidemsg();
                    } catch(ex) {
                        $.messager.alert('错误', data.responseText + '');
                    }
                }
                return false;
            }
        }
    });
});

$(function(){
    //查看模式情况下,删除和上传附件功能禁止使用
	if(location.href.indexOf("load=detail")!=-1){
		$(".jeecgDetail").hide();
	}
	
	if(location.href.indexOf("mode=read")!=-1){
		//查看模式控件禁用
		$("#formobj").find(":input").attr("disabled","disabled");
	}
	if(location.href.indexOf("mode=onbutton")!=-1){
		//其他模式显示提交按钮
		$("#sub_tr").show();
	}
});

var  bulletinjavascript = {};

bulletinjavascript.uploadStandby = 0;
bulletinjavascript.uploadComplete = 0;

//保存公告
function saveBulletin() {
	  setContent();
	  $.ajax({
			url : 'tBFailBulletinController.do?doFailBulletinContentAdd',
			type : 'post',
			data:{
				id:$("#id").val(),
				remark:$("#remark").val(),
				content:$("#content").val()
			},
			cache : false,
			success : function(data) {
				var d = $.parseJSON(data);
				tip(d.msg)
				
				$("#cgFormId_attachment").val( d.obj.id );
				
				var selectNum = $("#attachment").data('uploadify').queueData.queueLength ;
				bulletinjavascript.uploadStandby = ( selectNum>0?selectNum:0 );
				
				if(bulletinjavascript.uploadStandby == 0 ){
					backlist();
				} else{
					$("#attachment").uploadify('upload');//上传附件
					upload();
				}
			}
		});
}

bulletinjavascript.uploadToList = function(){
	bulletinjavascript.uploadComplete += 1;
	if(bulletinjavascript.uploadComplete == bulletinjavascript.uploadStandby ){
		backlist();
	}
}

//发布公告
function relBulletin() {
	  setContent();
	  $.ajax({
			url : 'tBFailBulletinController.do?doFailBulletinContentAdd',
			type : 'post',
			data:{
				id:$("#id").val(),
				content:$("#content").val(),
				remark:$("#remark").val(),
				relstatus:"01" //发布
			},
			cache : false,
			success : function(data) {
				var d = $.parseJSON(data);
				tip(d.msg);
				
				$("#cgFormId_attachment").val( d.obj.id );
				
				var selectNum = $("#attachment").data('uploadify').queueData.queueLength ;
				
				bulletinjavascript.uploadStandby = ( selectNum>0?selectNum:0 );
				
				if(bulletinjavascript.uploadStandby == 0 ){
					backlist();//没有上传附件直接返回
				} else{
					$("#attachment").uploadify('upload');//上传附件
					upload();
				}
			}
		});
}
  

function backlist(){
	var loadPageUrl = parent.document.getElementById("loadPageUrl");
	var loadPageUrlStr  = (loadPageUrl!=null&&loadPageUrl!="")?$(loadPageUrl).val():'';
	window.location.href = (loadPageUrlStr!=null&&loadPageUrlStr!="")?loadPageUrlStr:'tBFailBulletinController.do?list'
}


 //返回
  function back(){
	  window.location.href = 'tBFailBulletinController.do?goUpdate&id='+$("#id").val();
  }