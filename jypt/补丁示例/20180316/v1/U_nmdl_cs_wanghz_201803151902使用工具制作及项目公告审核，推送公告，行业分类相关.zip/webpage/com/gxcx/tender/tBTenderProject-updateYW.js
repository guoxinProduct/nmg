var tenderproject = {};
tenderproject.uploadStandby = 0;//计算附件数量
tenderproject.uploadComplete = 0;//计算完成数量

//初始化加载资金来源列表
$(document).ready(function(){
	 //招标项目性质初始化
	 $("select[name=projectNature]").change();
	 
	 $("#formobj").Validform({
		tiptype: 4,
		btnSubmit: "#btn_sub",
		btnReset: "#btn_reset",
		ajaxPost: true,
		beforeSubmit: function(curform) {
			//按钮不可用
        	$(".btn").attr("disabled", true);
        	return true;
		},
		usePlugin: {
			passwordstrength: {
				minLen: 6,
				maxLen: 18,
				trigger: function(obj, error) {
					if (error) {
						obj.parent().next().find(".Validform_checktip").show();
						obj.find(".passwordStrength").hide();
					} else {
						$(".passwordStrength").show();
						obj.parent().next().find(".Validform_checktip").hide();
					}
				}
			}
		},
		callback: function(data) {
			alert(data.msg);
			if (data.success == true) {
				//上传附件处理
   			 	dealFile(data);
			}
		}
	});
});

//提交
function finish() {
	var tenderno=$("#tenderno").val();
	if(tenderno == ""){
		$("#tendernoCheck").html('编号不能为空！');
		$("#tendernoCheck").addClass("Validform_wrong");
		$("#tendernoCheck").removeClass("Validform_right");
		return;
	}
	if(tenderno != "" && tenderno.length > 50){
		$("#tendernoCheck").html('编号不能超过50个字符！');
		$("#tendernoCheck").addClass("Validform_wrong");
		$("#tendernoCheck").removeClass("Validform_right");
		return;
	}
	var reg =/[\"\'\#\%\&\<>\{}\=\\]+/;
	if (reg.test(tenderno)) {
 	 	$("#tendernoCheck").html('项目编号不能含有非法字符!');
		$("#tendernoCheck").addClass("Validform_wrong");
		$("#tendernoCheck").removeClass("Validform_right");
 	 	return;
	} 
	var tendername = $("#tendername").val();
	if(tendername!=''){
		if (reg.test(tendername)) {
	 	 	$("#tendernameCheck").html('项目名称不能含有非法字符!');
			$("#tendernameCheck").addClass("Validform_wrong");
			$("#tendernameCheck").removeClass("Validform_right");
	 	 	return;
		} 
	}
	//二次招标的项目，不进行项目编号重复性校验操作
	var sourceTenderId = $("#sourceTenderId").val();
	//if (sourceTenderId == undefined || sourceTenderId == "") {
		$.ajax({
			url: "tBTenderProjectController.do?checkTenderNo",
			data: {tenderno:tenderno,
					id:$("#id").val(),
					sourceTenderId:sourceTenderId
					},
			type: "post",
			dataType:'json',
			success:function(d){
				if (d.msg == '00') {
					$("#tendernoCheck").html('编号已存在！');
					$("#tendernoCheck").addClass("Validform_wrong");
					$("#tendernoCheck").removeClass("Validform_right");
					alert('编号已存在！');
					//$("#tenderno").focus();
					return ;
				} 
				/**else if(d.msg == '02') {
					$("#tendernoCheck").html('项目编码不能包含汉字或中文符号！');
					$("#tendernoCheck").addClass("Validform_wrong");
					$("#tendernoCheck").removeClass("Validform_right");
					alert('项目编码不能包含汉字或中文符号！');
					//$("#tenderno").focus();
					return ;
				} */
				else {
					$.dialog.confirm("确认提交?", function(){
						if (checkMoney()) {
							$("#useStatus").val("01");
							$("#tenderno").val($.trim($("#tenderno").val()));
							//提交操作
							$('#btn_sub').trigger('click');
						}
					});
				}
			}
		});
	/**
	if (beforeSubmit()) {
		$.dialog.confirm("确认提交?", function(){
			if (checkMoney()) {
				$("#useStatus").val("01");
				$("#tenderno").val($.trim($("#tenderno").val()));
				//提交操作
				$('#btn_sub').trigger('click');
			}
		});
	}
	*/
}

//提交前校验
function beforeSubmit() {
	//校验机构名称
	checkTenderno();
	if($('#tendernoCheck').hasClass("Validform_wrong") == true){
		return;
	}
	return true;
}

//返回
function back() {
	var loadPageUrl = parent.document.getElementById("loadPageUrl");
	var loadPageUrlStr  = (loadPageUrl!=null&&loadPageUrl!="")?$(loadPageUrl).val():'';
	window.location.href = (loadPageUrlStr!=null&&loadPageUrlStr!="")?loadPageUrlStr:'tBTenderProjectController.do?listYW';
}

//表单提交前,需要校验资金来源总金额和项目总概算相等
function checkMoney() {
	//总金额
	var investent = parseFloat($("#budgetTotalMoney").val()*1);
	//总输入金额
	var totalMoney = parseFloat($("#totalMoney0").val()*1)+parseFloat($("#totalMoney1").val()*1)
		+parseFloat($("#totalMoney2").val()*1)+parseFloat($("#totalMoney3").val()*1)+parseFloat($("#totalMoney4").val()*1);
	//总输入金额必须等于总金额
	if(totalMoney!=investent){
		alert("资金来源总金额必须等于项目总概算");
		return;
	}
	return true;
}

//输入金额后,需要与总金额校验
function checkTotalMoney(obj) {
	if ($("#ck_"+obj.id).hasClass("Validform_wrong")) {
		return;
	}
	//总金额
	var investent = parseFloat($("#budgetTotalMoney").val()*1);
	if (investent == '') {
		alert("请输入项目总概算！");
		$("#budgetTotalMoney").focus();
		return;
	}
	//输入金额
	var money = parseFloat(obj.value*1);
	//输入金额不能大于总金额
	if(money>investent){
		alert("输入金额不能大于项目总概算！");
		$("#"+obj.id).val("");
		return;
	}
	
	//总输入金额
	var totalMoney = parseFloat($("#totalMoney0").val()*1)+parseFloat($("#totalMoney1").val()*1)
		+parseFloat($("#totalMoney2").val()*1)+parseFloat($("#totalMoney3").val()*1)+parseFloat($("#totalMoney4").val()*1);
	//总输入金额不能大于总金额
	if(totalMoney>investent){
		alert("资金来源总金额不能大于项目总概算！");
		$("#"+obj.id).val("");
		return;
	}
}

//上传附件后回调函数
tenderproject.uploadToList=function() {
	//假如附件数量=完成数量则返回列表
	tenderproject.uploadComplete += 1;
	if(tenderproject.uploadComplete == tenderproject.uploadStandby){
		tenderproject.backToList();
	}
}

//附件全都上传完后操作
tenderproject.backToList = function(){
	var loadPageUrl = parent.document.getElementById("loadPageUrl");
	var loadPageUrlStr  = (loadPageUrl!=null&&loadPageUrl!="")?$(loadPageUrl).val():'';
	window.location.href =  (loadPageUrlStr!=null&&loadPageUrlStr!="")?loadPageUrlStr:'tBTenderProjectController.do?listYW';
}

//上传附件
function dealFile(data) {
	//上传附件处理
	//委托合同复印件
	$("#cgFormId_contractFile").val( data.obj.id );
	var selectNum1 = $("#contractFile").data('uploadify').queueData.queueLength ;
	tenderproject.uploadStandby = selectNum1;
	if(tenderproject.uploadStandby == 0 ){
	} else{
		$('#contractFile').uploadify('upload', '*');
	}
	
	//招标项目性质
	var projectNature = data.obj.projectNature;
	if (projectNature == "00") {
		//勘察规划用地复印件
		$("#cgFormId_landplanKCAttache").val( data.obj.id );
		var selectNum2 = $("#landplanKCAttache").data('uploadify').queueData.queueLength ;
		tenderproject.uploadStandby += selectNum2;
		if(tenderproject.uploadStandby == 0 ){
			tenderproject.backToList();//没有上传附件直接返回
		} else{
			$("#landplanKCAttache").uploadify('upload', '*');//上传附件
		}
	} else if (projectNature == "01") {
		//用地手续
		$("#cgFormId_landClearanceAttache").val( data.obj.id );
		var selectNum3 = $("#landClearanceAttache").data('uploadify').queueData.queueLength ;
		tenderproject.uploadStandby += selectNum3;
		if(tenderproject.uploadStandby == 0 ){
		} else{
			$("#landClearanceAttache").uploadify('upload', '*');//上传附件
		}
		
		//规划用地复印件
		$("#cgFormId_landplanAttache").val( data.obj.id );
		var selectNum4 = $("#landplanAttache").data('uploadify').queueData.queueLength ;
		tenderproject.uploadStandby += selectNum4;
		if(tenderproject.uploadStandby == 0 ){
		} else{
			$("#landplanAttache").uploadify('upload', '*');//上传附件
		}
		
		//开户银行证明
		$("#cgFormId_bankCertificateAttache").val( data.obj.id );
		var selectNum5 = $("#bankCertificateAttache").data('uploadify').queueData.queueLength ;
		tenderproject.uploadStandby += selectNum5;
		if(tenderproject.uploadStandby == 0 ){
			tenderproject.backToList();//没有上传附件直接返回
		} else{
			$("#bankCertificateAttache").uploadify('upload', '*');//上传附件
		}
	} else if (projectNature == "02") {
		//产权证明
		$("#cgFormId_propertyCertificateAttache").val( data.obj.id );
		var selectNum6 = $("#propertyCertificateAttache").data('uploadify').queueData.queueLength ;
		tenderproject.uploadStandby += selectNum6;
		if(tenderproject.uploadStandby == 0 ){
		} else{
			$("#propertyCertificateAttache").uploadify('upload', '*');//上传附件
		}
		
		//消防意见
		$("#cgFormId_fireadviceAttacheAttache").val( data.obj.id );
		var selectNum7 = $("#fireadviceAttacheAttache").data('uploadify').queueData.queueLength ;
		tenderproject.uploadStandby += selectNum7;
		if(tenderproject.uploadStandby == 0 ){
		} else{
			$("#fireadviceAttacheAttache").uploadify('upload', '*');//上传附件
		}
		
		//规划意见
		$("#cgFormId_planningAdviceAttache").val( data.obj.id );
		var selectNum8 = $("#planningAdviceAttache").data('uploadify').queueData.queueLength ;
		tenderproject.uploadStandby += selectNum8;
		if(tenderproject.uploadStandby == 0 ){
			tenderproject.backToList();//没有上传附件直接返回
		} else{
			$("#planningAdviceAttache").uploadify('upload', '*');//上传附件
		}
	} else if (projectNature == "03") {
		//其他
		$("#cgFormId_othersAttache").val( data.obj.id );
		var selectNum9 = $("#othersAttache").data('uploadify').queueData.queueLength ;
		tenderproject.uploadStandby += selectNum9;
		if(tenderproject.uploadStandby == 0 ){
			tenderproject.backToList();//没有上传附件直接返回
		} else{
			$("#othersAttache").uploadify('upload', '*');//上传附件
		}
	}
}

/******   选择地区     ******/
function openDepartmentSelect(confirmDesc, cancelDesc) {
	$.dialog.setting.zIndex = 9999; 
	$.dialog({content: 'url:baseTerritoryController.do?territorySelect&searchId='+$('#projectAreaCode').val(), zIndex: 2100, title: '地区列表', lock: true, width: '400px', height: '350px', opacity: 0.4, button: [
	   {name: confirmDesc, callback: callbackDepartmentSelect, focus: true},
	   {name: cancelDesc, callback: function (){}}
 ]}).zindex();
}	
function callbackDepartmentSelect() {
	  var iframe = this.iframe.contentWindow;
	  var treeObj = iframe.$.fn.zTree.getZTreeObj("departSelect");
	  var nodes = treeObj.getSelectedNodes();
	  if(nodes.length>0){
		  var ids='',names='';
		  //选中节点
		  var node = nodes[0];
		  //节点级别(0:省,1:市,2:县)
		  var level = node.level;
		  if (level == 0) {//省
			  ids = node.id;
			  names = node.name;
		  } else if (level == 1) {//市
			  //父节点(省)
			  var provNode = node.getParentNode();
			  
			  ids = provNode.id+","+node.id;
			  names = provNode.name+","+node.name;
		  } else if (level == 2) {//县
			  //父节点(市)
			  var cityNode = node.getParentNode();
			  //父节点(省)
			  var provNode = cityNode.getParentNode();
			  
			  ids = provNode.id+","+cityNode.id+","+node.id;
			  names = provNode.name+","+cityNode.name+","+node.name;
		  }
		  
		 //赋值 
		 $('#projectAreaName').val(names);
		 $('#projectAreaName').blur();		
		 $('#projectAreaCode').val(ids);		
	}
}
function callbackClean(){
	$('#projectAreaName').val('');
	 $('#projectAreaCode').val('');	
}
/******   选择地区     ******/

/******   选择行业分类     ******/
function openIndustrySelect(confirmDesc, cancelDesc) {
	$.dialog.setting.zIndex = 9999; 
	$.dialog({content: 'url:tBBaseIndustryController.do?tBBaseIndustrySelect&searchId='+$('#projectIndustryCode').val(), zIndex: 2100, title: '行业分类列表', lock: true, width: '400px', height: '350px', opacity: 0.4, button: [
	   {name: confirmDesc, callback: callbackIndustrySelect, focus: true},
	   {name: cancelDesc, callback: function (){}}
 ]}).zindex();
}	
function callbackIndustrySelect() {
	var iframe = this.iframe.contentWindow;
	  var treeObj = iframe.$.fn.zTree.getZTreeObj("departSelect");
	  var nodes = treeObj.getCheckedNodes(true);
	  if(nodes.length>0){
	  var ids='',names='';
	  for(i=0;i<nodes.length;i++){
	     var node = nodes[i];
	     ids += node.id+',';
	     names += node.name+',';
	 }
	 if (ids!='') {
		 ids = ids.substr(0, ids.length-1);
	 } 
	 if (names!='') {
		 names = names.substr(0, names.length-1);
	 } 
	 $('#projectIndustryName').val(names);
	 $('#projectIndustryName').blur();		
	 $('#projectIndustryCode').val(ids);		
	}
}
function callbackIndustryClean(){
	$('#projectIndustryName').val('');
	$('#projectIndustryCode').val('');	
}
/******   选择行业分类     ******/

/******   选择品目     ******/
function openPurcategorySelect(confirmDesc, cancelDesc) {
	$.dialog.setting.zIndex = 9999; 
	$.dialog({content: 'url:basePurcatalogCategoryController.do?purcatacategorySelect&enable=true&searchId='+$('#purcategoryIds').val(), zIndex: 2100, title: '品目列表', lock: true, width: '400px', height: '350px', opacity: 0.4, button: [
    {name: confirmDesc, callback: callbackPurcategorySelect, focus: true},
    {name: cancelDesc, callback: function (){}}
    ]}).zindex();
}	
function callbackPurcategorySelect() {
	var iframe = this.iframe.contentWindow;
	var treeObj = iframe.$.fn.zTree.getZTreeObj("departSelect");
	//多选(enable=true)
	var nodes = treeObj.getCheckedNodes(true);
	//单选(enable=false)
	//var nodes = treeObj.getSelectedNodes();
	if(nodes.length>0){
		var ids='',names='';
		for(i=0;i<nodes.length;i++){
			var node = nodes[i];
			ids += node.id+',';
			names += node.name+',';
			//ids += node.id;
			//names += node.name;
		}
		if (ids!='') {
			 ids = ids.substr(0, ids.length-1);
		 } 
		 if (names!='') {
			 names = names.substr(0, names.length-1);
		 } 
		$('#purcategoryNames').val(names);
		$('#purcategoryNames').blur();		
		$('#purcategoryIds').val(ids);		
	}
}
function callbackPurcategoryClean(){
	$('#purcategoryNames').val('');
	$('#purcategoryIds').val('');	
}
/******   选择品目     ******/

/******   选择招标人     ******/
//选择招标人
function openBuyersSelect(confirmDesc, cancelDesc) {
	$.dialog({
		width:600,
		height:500,
      id: 'BUYER1988SELECT',
      title: "<t:mutiLang langKey='zfcg.buyersCode'/>",
      max: false,
      min: false,
      resize: false,
      content: 'url:tBTenderProjectController.do?goBuyersSelect',
      lock:true,
      button: [
          {name: confirmDesc, callback: callbackBuyersSelect, focus: true},
        	{name: cancelDesc, callback: function (){}}
      ]
  });
}
//回调函数存储选中的值
function callbackBuyersSelect() {
	var iframe = this.iframe.contentWindow;
	$("#buyersId").val(iframe.getbuyersListSelections('departId'));
	$("#buyersName").val(iframe.getbuyersListSelections('departName'));
	$("#buyersCode").val(iframe.getbuyersListSelections('orglicensecerno'));
	$("#buyersLinkerName").val(iframe.getbuyersListSelections('linkname'));
	$("#buyersLinkerTel").val(iframe.getbuyersListSelections('linktel'));
	$("#buyersLinkerAddress").val(iframe.getbuyersListSelections('address'));
	$("#buyersLinkerEmail").val(iframe.getbuyersListSelections('email'));
	$('#buyersName').blur();
	$('#buyersLinkerName').blur();
	$('#buyersLinkerTel').blur();
}
//清空
function callbackBuyersClean(){
	$("#buyersId").val('');
	$("#buyersName").val('');
	$("#buyersCode").val('');
	$("#buyersLinkerName").val('');
	$("#buyersLinkerTel").val('');
	$("#buyersLinkerAddress").val('');
}
/******   选择招标人     ******/

/******   项目编号唯一校验     ******/
function checkTenderno() {
	var tenderno=$("#tenderno").val();
	if(tenderno == ""){
		$("#tendernoCheck").html('编号不能为空！');
		$("#tendernoCheck").addClass("Validform_wrong");
		$("#tendernoCheck").removeClass("Validform_right");
		return;
	}
	if(tenderno != "" && tenderno.length > 50){
		$("#tendernoCheck").html('编号不能超过50个字符！');
		$("#tendernoCheck").addClass("Validform_wrong");
		$("#tendernoCheck").removeClass("Validform_right");
		return;
	}
	var reg =/[\"\'\#\%\&\<>\{}\=\\]+/;
	if (reg.test(tenderno)) {
 	 	$("#tendernoCheck").html('项目编号不能含有非法字符!');
		$("#tendernoCheck").addClass("Validform_wrong");
		$("#tendernoCheck").removeClass("Validform_right");
 	 	return;
	} 
	//二次招标的项目，不进行项目编号重复性校验操作
	var sourceTenderId = $("#sourceTenderId").val();
//	if (sourceTenderId == undefined || sourceTenderId == "") {
		$.ajax({
			url: "tBTenderProjectController.do?checkTenderNo",
			data: {tenderno:tenderno,
					id:$("#id").val(),
					sourceTenderId:sourceTenderId
					},
			type: "post",
			dataType:'json',
			success:function(d){
				if (d.msg == '00') {
					$("#tendernoCheck").html('编号已存在！');
					$("#tendernoCheck").addClass("Validform_wrong");
					$("#tendernoCheck").removeClass("Validform_right");
					//$("#tenderno").focus();
					return;
				} 
				/**else if(d.msg == '02') {
					$("#tendernoCheck").html('项目编码不能包含汉字或中文符号！');
					$("#tendernoCheck").addClass("Validform_wrong");
					$("#tendernoCheck").removeClass("Validform_right");
					//$("#tenderno").focus();
					return;
				}*/ 
				else {
					$("#tendernoCheck").html('通过信息验证！');
					$("#tendernoCheck").removeClass("Validform_wrong");
					$("#tendernoCheck").addClass("Validform_right");
				} 
			}
		});
//	}
}
/******   项目编号唯一校验     ******/


function checkTenderName(){
	var tendername = $("#tendername").val();
	var reg =/[\"\'\#\%\&\<>\{}\=\\]+/;
	if(tendername!=''){
		if (reg.test(tendername)) {
	 	 	$("#tendernameCheck").html('项目名称不能含有非法字符!');
			$("#tendernameCheck").addClass("Validform_wrong");
			$("#tendernameCheck").removeClass("Validform_right");
	 	 	return;
		} 
	}
}