//返回列表页面
function getTenderProjectList() {
	var loadPageUrl = parent.document.getElementById("loadPageUrl");
	var loadPageUrlStr  = (loadPageUrl!=null&&loadPageUrl!="")?$(loadPageUrl).val():'';
    window.location.href= (loadPageUrlStr!=null&&loadPageUrlStr!="")?loadPageUrlStr:"tBBulletinController.do?list";
}