$(function(){
	showSaleDocSelect();
	showSaleDocDate();
});
//保存并生成公告
function neibuClick() {
	if($("#title").val()=="" || $("#title").val()==null){
		alert("公告标题不能为空！");
		return;
	}
//	if(checkDate()==false){//时间校验
//		return;
//	}
	var tenderIds = [];//选择的标段id
    $('input[type=checkbox][name=packname]:checked').each(function(){
  		tenderIds.push(this.value);
    })
    if(tenderIds.length==0){
    	alert("请选择标段");
		return;
	}else{
		$("#packids").val(tenderIds.toString());
	}
    $("#saveid").attr("disabled",true);
    $.ajax({
		url : 'tBBulletinController.do?doAddDelayBulletin',
		type : 'post',
		data:{
			id:$("#id").val(),
			tenderIds:tenderIds.toString(),
			title:$("#title").val(),
			effectStartDate:$("#effectStartDate").val(),
			effectEndDate:$("#effectEndDate").val(),
			submitStartDate:$("#submitStartDate").val(),
			submitEndDate:$("#submitEndDate").val(),
			docSaleStartTime:$("#docSaleStartTime").val(),
			docSaleEndTime:$("#docSaleEndTime").val(),
			openBidStartDate:$("#openBidStartDate").val(),
			docDownloadStartTime:$("#docDownloadStartTime").val(),
			docDownloadEndTime:$("#docDownloadEndTime").val(),
			projectId:$("#projid").val(),
			isSaleDocByProject:$("input:radio[name=isSaleDocByProject]:checked").val(),
			isSaleOnline:$("input:radio[name=isSaleOnline]:checked").val(),
			isSaleDocFee:$("input:radio[name=isSaleDocFee]:checked").val()
		},
		cache : false,
		success : function(data) {
			var d = $.parseJSON(data);
			var tBBulletin = d.obj;//公告
			var id = tBBulletin.id//公告id
			window.location.href = 'tBBulletinController.do?goBulletinContentAdd&type=delay&id='+id;
		}
	});
}
//返回
function back() {
	var loadPageUrl = parent.document.getElementById("loadPageUrl");
	var loadPageUrlStr  = (loadPageUrl!=null&&loadPageUrl!="")?$(loadPageUrl).val():'';
	window.location.href = (loadPageUrlStr!=null&&loadPageUrlStr!="")?loadPageUrlStr:'tBBulletinController.do?list';
}

//校验时间
function checkDate(){
  	if($("#effectStartDate").val()=="" || $("#effectEndDate").val()==""){
  		alert('报名时间不能为空！');
  		return false;
  	}
  	if($("#docDownloadStartTime").val()=="" || $("#docDownloadEndTime").val()==""){
  		alert('文件下载时间不能为空！');
  		return false;
  	}
  	if($("input:radio[name=isSaleOnline]:checked").val()=="1"){
  		if($("#docSaleStartTime").val()=="" || $("#docSaleEndTime").val()==""){
	  		alert('招标文件售卖时间不能为空！');
	  		return false;
	  	}
  	}
  	if($("#submitStartDate").val()=="" || $("#submitEndDate").val()==""){
  		alert('投标时间不能为空！');
  		return false;
  	}
  	if($("#openBidStartDate").val()==""){
  		alert('开标时间不能为空！');
  		return false;
  	}
  	
	if($("#effectStartDate").val()>$("#effectEndDate").val()){alert('【报名截止时间】应大于【报名开始时间】！');return false;}
	if($("#submitStartDate").val()>$("#submitEndDate").val()){alert('【投标结束时间】应大于【投标开始时间】！');return false;}
	if($("#docSaleStartTime").val()>$("#docSaleEndTime").val()){alert('【招标文件售卖结束时间】应大于【招标文件售卖开始时间】！');return false;}
	if($("#submitEndDate").val()>$("#openBidStartDate").val()){alert('【开标时间】应大于等于【投标结束时间】！');return false;}
	if($("#docDownloadStartTime").val()>$("#docDownloadEndTime").val()){alert('【文件下载截止时间】应大于等于【文件下载开始时间】！');return false;}
	
	if((newDate($('#submitEndDate').val()).getTime()-newDate($('#submitStartDate').val()).getTime())/(1000*60*60*24)<5){
		alert('【投标结束时间】距离【投标开始时间】应不小于5天');
		return false;
	}
	if((newDate($('#docSaleEndTime').val()).getTime()-newDate($('#docSaleStartTime').val()).getTime())/(1000*60*60*24)<5){
		alert('【招标文件售卖结束时间】距离【招标文件售卖开始时间】应不小于5天');
		return false;
	}
	if((newDate($('#docDownloadEndTime').val()).getTime()-newDate($('#docDownloadStartTime').val()).getTime())/(1000*60*60*24)<5){
		alert('【文件下载截止时间】距离【文件下载开始时间】应不小于5天');
		return false;
	}
	if((newDate($('#openBidStartDate').val()).getTime()-newDate($('#docSaleStartTime').val()).getTime())/(1000*60*60*24)<20){
		alert('【开标时间】距离【招标文件售卖开始时间】应不小于20天');
		return false;
	}
}
  
function newDate(str){
	strall=str.split(' ');
	var datestr = strall[0].split('-');
	var timestr = new Array();
	if(strall.length>=2){
		timestr = strall[1].split(':');
	}
	var date = new Date();
	//**月份记得减一
	date.setUTCFullYear(datestr[0], datestr[1]-1, datestr[2]);
	if(timestr.length!=0){
		date.setUTCHours(timestr[0], timestr[1], timestr[2], 0);
	}
	return date;
}

//切换是否收取标书费
function showSaleDocSelect(){
    var isSaleDocFee = $("input:radio[name=isSaleDocFee]:checked").val();
    if(isSaleDocFee=='0'){
	    $("#isSaleDocFeeId_1").hide();
	    $("#isSaleDocFeeId_2").hide();
	    $("#isSaleDocFeeId_3").hide();
	    $("input:radio[name=isSaleOnline][value=0]").attr("checked",'checked');
	    showSaleDocDate();
	    $("#isSaleDocFeeId").attr("colspan","3");
    }else{
	    $("#isSaleDocFeeId_1").show();
	    $("#isSaleDocFeeId_2").show();
	    $("#isSaleDocFeeId_3").show();
	    $("#isSaleDocFeeId").attr("colspan","1");
    }
}

//切换是否在线收取标书费
function showSaleDocDate(){
    var isSaleOnline = $("input:radio[name=isSaleOnline]:checked").val();
    if(isSaleOnline=='0'){
	    $("#saleDocDateId_1").hide();
	    $("#saleDocDateId_2").hide();
	    $("#docSaleStartTime").val("");
	    $("#docSaleEndTime").val("");
	    $("#saleDocDateId").attr("colspan","3");
    }else{
	    $("#saleDocDateId_1").show();
	    $("#saleDocDateId_2").show();
	    $("#saleDocDateId").attr("colspan","1");
    }
}
