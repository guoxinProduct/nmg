$(function(){
	/*showisRemoteOpening();*/
	showTwoBidOpening();
});
//页面初始化
//function init() {
//	editor.addListener("ready", function() {
//		editor.setContent($("#content").val(), false);
//	});//防止在按钮按下的时候，编辑器还没初始化
//}
//返回
function back() {
	if('yes'==$(isProcurement).val()){
		window.location.href = 'tBPurchaseApplyController.do?procurementBulletinList';
	}else{
		window.location.href = 'tBBulletinController.do?list&tenderId='+$("#tenderId").val() +"&batches="+$("#batches").val();
	}
}
//切换是否远程开标
/*function showisRemoteOpening(){
	var isRemoteOpening = $("input:radio[name=isRemoteOpening]:checked").val();
	alert(isRemoteOpening);
    if(isRemoteOpening=='0'){
	    $("#isTwoBidOpeningId_3").hide();
	    showTwoBidOpening();
    }else{
	    $("#isTwoBidOpeningId_3").show();
    }
}*/
	
//切换是否两步开标
function showTwoBidOpening(){
	var isTwoBidOpening = $("#isTwoBidOpening").val();
    if(isTwoBidOpening=='0'){
    	$("#technicalOpenBidStartDate_1").hide();
  	    $("#technicalOpenBidStartDate_2").hide();
	    $("#technicalOpenBidStartDate").val("");
	    $("#openBidStartDateId").attr("colspan","3");
	    $("#openingTimeTxt").text('开标时间：');
    }else{
    	$("#technicalOpenBidStartDate_1").show();
 	    $("#technicalOpenBidStartDate_2").show();
 	    $("#openBidStartDateId").attr("colspan","1");
 	    $("#openingTimeTxt").text('经济标开标时间：');
	}
}



/**
 * 审核通过
 */
function auditPass() {
	var variable1=$('#auditReason').val();
	var id=$("#id").val();
	$("#buttonAuditPass").attr("disabled", 'disabled');
	$("#buttonAuditNoPass").attr("disabled", 'disabled');
	$.ajax({
		url : 'tBBulletinController.do?auditBulletin&id='+id+"&relstatus=01",
		type : 'post',
		data: {
			auditReason:variable1
		},
		cache : false,
		success : function(data) {
			alert('操作成功');
			frameElement.api.close();
		}
	});
}
/**
 * 退回审核
 */
function auditNoPass() {
	//add by hubin
	var variable1=$('#auditReason').val();
	if ($.trim(variable1) == null || $.trim(variable1) == '') {
		alert("请输入审核意见");
		return false;
	} 
	// end  add by hubin
	var id=$("#id").val();
	$("#buttonAuditNoPass").attr("disabled", 'disabled');
	$.ajax({
		url : 'tBBulletinController.do?auditBulletin&id='+id+"&relstatus=02",
		type : 'post',
		data: {
			auditReason:variable1
		},
		cache : false,
		success : function(data) {
			alert('操作成功');
			frameElement.api.close();
		}
	});
}
