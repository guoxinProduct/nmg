
function openBidToSubmitEnd(){
	var isTwoBidOpening=$("input:radio[name=isTwoBidOpening]:checked").val();//是否两步开标
	if(isTwoBidOpening=='0'){
		var openBidStartDate= $("#openBidStartDate").val();//开标时间
		var submitEndDate = $("#submitEndDate").val();
		if(openBidStartDate!=''){
			if(submitEndDate==''){
			   $("#submitEndDate").val(openBidStartDate);
			}
		}
	}
}
function tecOpenBidToSubmitEnd(){
	var isTwoBidOpening=$("input:radio[name=isTwoBidOpening]:checked").val();//是否两步开标
	if(isTwoBidOpening=='1'){
		var technicalOpenBidStartDate= $("#technicalOpenBidStartDate").val();//商务技术标开标时间
		var submitEndDate = $("#submitEndDate").val();//投标截止时间
		if(technicalOpenBidStartDate!=''){
			if(submitEndDate==''){
			   $("#submitEndDate").val(technicalOpenBidStartDate);
			}
		}
	}
}
function setOpenbidStartTime(){
	var submitEndDate =$("#submitEndDate").val();//投标结束时间
	if(submitEndDate!=''){
		var isTwoBidOpening=$("input:radio[name=isTwoBidOpening]:checked").val();//是否两步开标
		if(isTwoBidOpening=='1'){
			 $("#openBidStartDate").val("");//先把开标时间给清空
			 $("#technicalOpenBidStartDate").val(submitEndDate);
		}else{
			$("#openBidStartDate").val(submitEndDate);
		}
	}
}
function checkSubmitStartDate(){
	var startTime = $("#effectStartDate").val();
	var endTime = $("#submitStartDate").val();
	if(startTime == ''){
		$("#submitStartDateCheck").html('请选择报名时间');
		$("#submitStartDateCheck").addClass("Validform_wrong");
		$("#submitStartDateCheck").removeClass("Validform_right");
		return;
	}
	if(endTime == ''){
		$("#submitStartDateCheck").html('请选择文件递交开始时间');
		$("#submitStartDateCheck").addClass("Validform_wrong");
		$("#submitStartDateCheck").removeClass("Validform_right");
		return;
	}
	if(endTime<startTime){
		$("#submitStartDateCheck").html('文件递交开始时间不得小于报名时间');
		$("#submitStartDateCheck").addClass("Validform_wrong");
		$("#submitStartDateCheck").removeClass("Validform_right");
	}else{
		$("#submitStartDateCheck").html('校验通过！');
		$("#submitStartDateCheck").addClass("Validform_right");
		$("#submitStartDateCheck").removeClass("Validform_wrong");
	}
	
}
function checkSubmitEndDate(){
	var beforeOpenTime = "0";
	var startTime = "";
	var timeName = "";
	startTime = $("#docSaleStartTime").val();
	timeName = "文件售卖开始时间";
	var endTime = $("#submitEndDate").val();
	if(startTime == ''){
		$("#submitEndDateCheck").html('请选择'+timeName);
		$("#submitEndDateCheck").addClass("Validform_wrong");
		$("#submitEndDateCheck").removeClass("Validform_right");
		return;
	}
	if(endTime == ''){
		$("#submitEndDateCheck").html('请选择文件递交结束时间');
		$("#submitEndDateCheck").addClass("Validform_wrong");
		$("#submitEndDateCheck").removeClass("Validform_right");
		return;
	}
	var beforeOpen = parseInt(beforeOpenTime);	
	var selectTime = 0;
	var msg = '';
	var beginDate = new Date(startTime.replace(/-/g, "/"));  
	var endDate = new Date(endTime.replace(/-/g, "/"));  
	//日期差值,即包含周六日、以天为单位的工时，86400000=1000*60*60*24.  
	if((endDate - beginDate)<0){
		selectTime = -1
	}else{
		selectTime = (endDate - beginDate)/86400000 + 1; 
	}
	msg += (beforeOpen + "天");
	if(selectTime<beforeOpen){
		$("#submitEndDateCheck").html('文件递交结束时间不得小于'+timeName);
		$("#submitEndDateCheck").addClass("Validform_wrong");
		$("#submitEndDateCheck").removeClass("Validform_right");
	}else{
		$("#submitEndDateCheck").html('校验通过！');
		$("#submitEndDateCheck").addClass("Validform_right");
		$("#submitEndDateCheck").removeClass("Validform_wrong");
	}
}
function checkOpenBidStartDate(){
	var beforeOpenTime = "20";
	var startTime = "";
	var timeName = "";
	startTime = $("#docSaleStartTime").val();
	timeName = "文件售卖开始时间20天";
	var endTime = $("#openBidStartDate").val();
	if(startTime == ''){
		$("#openBidStartDateCheck").html('请选择'+timeName);
		$("#openBidStartDateCheck").addClass("Validform_wrong");
		$("#openBidStartDateCheck").removeClass("Validform_right");
		return;
	}
	if(endTime == ''){
		$("#openBidStartDateCheck").html('请选择开标时间');
		$("#openBidStartDateCheck").addClass("Validform_wrong");
		$("#openBidStartDateCheck").removeClass("Validform_right");
		return;
	}
	var beforeOpen = parseInt(beforeOpenTime);
	var selectTime = 0;
	var msg = '';
	var beginDate = new Date(startTime.replace(/-/g, "/"));  
	var endDate = new Date(endTime.replace(/-/g, "/"));  
	//日期差值,即包含周六日、以天为单位的工时，86400000=1000*60*60*24.  
	if((endDate - beginDate)<0){
		selectTime = -1
	}else{
		selectTime = (endDate - beginDate)/86400000 + 1; 
	}
	msg += (beforeOpen + "天");
	if(selectTime<beforeOpen){
		$("#openBidStartDateCheck").html('开标时间不得小于'+timeName);
		$("#openBidStartDateCheck").addClass("Validform_wrong");
		$("#openBidStartDateCheck").removeClass("Validform_right");
	}else{
		$("#openBidStartDateCheck").html('校验通过！');
		$("#openBidStartDateCheck").addClass("Validform_right");
		$("#openBidStartDateCheck").removeClass("Validform_wrong");
	}
}
//时间规则校验
function checkTime(){
	//报名时间校验
	checkEffectStartDate();
	//文件售卖开始时间校验
	checkDocSaleStartTime();
	//文件售卖结束时间校验
	checkDocSaleEndTime();
	//文件递交开始时间
	checkSubmitEndDate();
	//文件递交结束时间
	checkSubmitStartDate();
	//投标时间
	checkOpenBidStartDate();
}
function getWorkDay(startTime,endTime){
	var beginDate = new Date(startTime.replace(/-/g, "/"));  
	//结束日期  
	var endDate = new Date(endTime.replace(/-/g, "/")); 
	//日期差值,即包含周六日、以天为单位的工时，86400000=1000*60*60*24.  
	var workDayVal = 0;
	if((endDate - beginDate)<0){
		workDayVal = -1;
		return workDayVal;
	}else{
		workDayVal = (endDate - beginDate)/86400000 + 1;  
	}
	//工时的余数  
	var remainder = workDayVal % 7;
	//工时向下取整的除数  
	var divisor = Math.floor(workDayVal / 7);  
	var weekendDay = 2 * divisor;  
	  
	//起始日期的星期，星期取值有（1,2,3,4,5,6,0）  
	var nextDay = beginDate.getDay();  
	//从起始日期的星期开始 遍历remainder天  
	for(var tempDay = remainder; tempDay>=1; tempDay--) {  
	    //第一天不用加1  
	    if(tempDay == remainder) {  
	        nextDay = nextDay + 0;  
	    } else if(tempDay != remainder) {  
	        nextDay = nextDay + 1;  
	    }  
	    //周日，变更为0  
	    if(nextDay == 7) {  
	        nextDay = 0;  
	    }  
	  
	    //周六日  
	    if(nextDay == 0 || nextDay == 6) {  
	        weekendDay = weekendDay + 1;  
	    }  
	}  
	//实际工时（天） = 起止日期差 - 周六日数目。  
	workDayVal = workDayVal - weekendDay;  
	return workDayVal;

}

function setTimes(){
	var effectStartDate = $("#effectStartDate").val();//报名开始时间
	var effectEndDate =$("#effectEndDate").val();//报名结束时间
	
	$("#docDownloadStartTime").val(effectStartDate);//文件下载开始时间
	$("#docDownloadEndTime").val(effectEndDate);//文件下载结束时间
	
	var isSaleOnline=$("input:radio[name=isSaleOnline]:checked").val();//是否在线售卖标书费
	var isSaleDocFee=$("input:radio[name=isSaleDocFee]:checked").val();//是否收取标书费
	if(isSaleOnline=='1'&&isSaleDocFee=='1'){
		$("#docSaleStartTime").val(effectStartDate);
		$("#docSaleEndTime").val(effectEndDate);
	}
	$("#submitStartDate").val(effectStartDate);//投标开始时间默认为报名时间
}


function timeFn(d1,d2) {//di作为一个变量传进来
    //如果时间格式是正确的，那下面这一步转化时间格式就可以不用了
    var dateBegin = new Date(d1.replace(/-/g, "/"));//将-转化为/，使用new Date
    var dateEnd =  new Date(d2.replace(/-/g, "/"));//将-转化为/，使用new Date
    var dateDiff = dateEnd.getTime() - dateBegin.getTime();//时间差的毫秒数
    var dayDiff = Math.floor(dateDiff / (24 * 3600 * 1000));//计算出相差天数
    return dayDiff;
}