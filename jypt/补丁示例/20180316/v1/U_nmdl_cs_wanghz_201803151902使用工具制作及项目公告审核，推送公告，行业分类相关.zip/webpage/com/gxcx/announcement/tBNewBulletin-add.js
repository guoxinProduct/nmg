$(function(){
});

//保存并生成公告
function neibuClick() {
	if($("#projInput").val()=="" || $("#projInput").val()==null){
		alert("项目信息不能为空！");
		return;
	}
	if($("#title").val()=="" || $("#title").val()==null){
		alert("公告标题不能为空！");
		return;
	}

    var tenderIds = [];//选择的标段id
    $('input[type=checkbox][name=packname]:checked').each(function(){
  		tenderIds.push(this.value);
    })
    if(tenderIds.length==0){
    	alert("请选择标段");
		return;
	}else{
		$("#packids").val(tenderIds.toString());
	}
    
    var stageids='';
		$("input[name='packname']").each(function(i,n){
			if($(n).attr("checked")== 'checked'){
				if(stageids!=''){
					stageids+=",";
				}
				stageids = stageids+$(n).attr("stageid");
			}
		})
	if(stageids.indexOf('undefined')!=-1)
		{
			stageids=$("#stageids").val();
		}
		$("#stageids").val(stageids);
		var stageType = $("#phaseType").val();
    $("#saveid").attr("disabled",true);
    $.ajax({
		url : 'newBulletinController.do?doAddNewBulletin',
		type : 'post',
		data:{
			tenderIds:tenderIds.toString(),
			stageids:stageids,
			stageType:stageType,
			title:$("#title").val(),
			id:$("#id").val(),
			projectId:$("#projid").val()
			
			
		},
		cache : false,
		success : function(data) {
			var d = $.parseJSON(data);
			var tBBulletin = d.obj;//公告
			var id = tBBulletin.id//公告id
			window.location.href = 'newBulletinController.do?goNewBulletinContentAdd&id='+id;//跳转到编辑公告页面
		}
	});
}
//返回
function back() {
	window.location.href = 'newBulletinController.do?list&tenderId='+$("#projectId").val() +"&batches="+$("#batches").val();
}
  
  
//选择项目
function openTenderSelect(confirmDesc, cancelDesc) {
	$.dialog({
		width:600,
		height:500,
        id: 'LHG1976Daaa',
        title: "选择项目",
        max: false,
        min: false,
        resize: false,
        //content: 'url:tBTenderProjectController.do?selectProject&tenderId='+$("#projectId").val()+'&type=bulletin',
        content: 'url:tBTenderProjectController.do?selectProject&tenderId='+$("#projectId").val(),
        lock:true,
        button: [
                {name: confirmDesc, callback: callbackTenderSelect, focus: true},
               	{name: cancelDesc, callback: function (){}}
             ]
        
    });
}
//点击标段
function getPack(e, bulletinId,stageid,procfileId,packstageType,isSaleOnline,isSaleDocFee){
 
 
}

//回调函数存储选中的值
function callbackTenderSelect() {
	var iframe = this.iframe.contentWindow;
	var names=iframe.gettendersListSelections('packidnames').toString();
	var id=iframe.gettendersListSelections('id');
	var tendername=iframe.gettendersListSelections('tendername');
	var tenderNo=iframe.gettendersListSelections('tenderno');
	$("#tenderNo").val(tenderNo);
	var projInput = "";
	var packDiv = "";
	var packids = "";
	//接收弹框的回填值
		$("#packDiv").empty();
		$.ajax({
			url : 'tBTenderProjectController.do?getPackbyTenderid&tenderId='+id+'&type=changebulletin',
			type : 'post',
			data:{
			},
			cache : false,
			success : function(data) {
				var d = $.parseJSON(data);
				var isPack=d.attributes.tBTenderProject.isPack;
				$("#isPack").val(isPack);
				var tenderType = d.msg;//资格审查方式(00:资审,01:后审)
				$("#bulletinTypeId").empty();
				if(tenderType=='00'){
					$("#bullTypeSpan2").hide();
					$("#bullTypeSpan").show();
					$("#bulletinTypeTemp").val('21');
					$("input:radio[name=bulletinType][value=01]").attr("checked",'');
					$("input:radio[name=bulletinType][value=21]").attr("checked",'checked');
				}else{
//					$("input:radio[name=bulletinType][value=21]").hide();
//					$("input:radio[name=bulletinType][value=01]").attr("checked",'checked');
					$("#bullTypeSpan").hide();
					$("#bullTypeSpan2").show();
					$("#bulletinTypeTemp").val('01');
				}
				var packObject = d.obj;//公告
				var myobj=eval(packObject);
				for(var i=0;i<myobj.length;i++){
					var packid=myobj[i].id;
					var packname=myobj[i].packName;
					var packStatus=myobj[i].packNo;
					var packstageType=myobj[i].packstageType;
					 var bulletinId=myobj[i].bulletinId;
					 var procfileId=myobj[i].procfileId;
					 var stageid=myobj[i].stageid;
					 var packNo=myobj[i].tenderNo;//包组
					 var isSaleOnline=myobj[i].isSaleOnline;
					 var isSaleDocFee=myobj[i].isSaleDocFee;
					 if(packStatus=='00'){
							$("#packDiv").append("<input type='checkbox' disabled='disabled' name='packname' value='"+packid+"'/><label>"+"["+packNo+"]"+packname+"</label>");
						}else{
							$("#packDiv").append("<input type='checkbox'    name='packname' onchange=\"getPack(this,'"+bulletinId+"\','"+stageid+"\','"+procfileId+"\','"+packstageType+"\','"+isSaleOnline+"\','"+isSaleDocFee+"\');\" stageid='"+stageid+"' id='"+stageid+"'  bulletinId='"+bulletinId+"' procfileId='"+procfileId+"' packNo='"+packNo+"' value='"+packid+"'/><label>"+"["+packNo+"]"+packname+"</label>");
					    }
				} 
				$("#packDiv").append("<span id='spanid' style='display: block;clear: both;line-height: 30px;'><a href='#' id='selectid' onclick='selectPackage()' style='border: 1px #f90 solid;border-radius: 3px;padding: 2px 5px;color: #f90;'>全选</a></span>");
				$("#projInput").val(tendername);
				$("#title").val("【"+tendername+"】"+"二次公告");
				$("#projid").val(id);
			}
		});
}

function selectPackage(){
	$("input[name='packname']:not(:disabled)").attr("checked",true);
	$("#spanid").html("<a href='#' id='selectid' onclick='selectPackageNo()' style='border: 1px #f90 solid;border-radius: 3px;padding: 2px 5px;color: #f90;'>反选</a>");
}
function selectPackageNo(){
	$("input[name='packname']:not(:disabled)").attr("checked",false);
	$("#spanid").html("<a href='#' id='selectid' onclick='selectPackage()' style='border: 1px #f90 solid;border-radius: 3px;padding: 2px 5px;color: #f90;'>全选</a>");
}