function projectProgressView(id) {
	window.location.href = 'tBProjectNodeController.do?toProjectProgressView&tenderId='+id+"&falge="+"isdepart";
}
