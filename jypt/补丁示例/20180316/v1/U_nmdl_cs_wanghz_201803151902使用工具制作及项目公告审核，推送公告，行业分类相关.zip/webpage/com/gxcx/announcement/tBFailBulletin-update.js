$(function() {
    $("#formobj").Validform({
        tiptype: 1,
        btnSubmit: "#btn_sub",
        btnReset: "#btn_reset",
        ajaxPost: true,
		beforeSubmit: function(curform) {
            var tag = true;
			//提交前处理
            return tag;
        },
        usePlugin: {
            passwordstrength: {
                minLen: 6,
                maxLen: 18,
                trigger: function(obj, error) {
                    if (error) {
                        obj.parent().next().find(".Validform_checktip").show();
                        obj.find(".passwordStrength").hide();
                    } else {
                        $(".passwordStrength").show();
                        obj.parent().next().find(".Validform_checktip").hide();
                    }
                }
            }
        },
        callback: function(data) {
            if (data.success == true) {
			     var win = frameElement.api.opener;
                 win.reloadTable();
 				 win.tip(data.msg);
 				 frameElement.api.close();
            } else {
                if (data.responseText == '' || data.responseText == undefined) {
                    $.messager.alert('错误', data.msg);
                    $.Hidemsg();
                } else {
                    try {
                        var emsg = data.responseText.substring(data.responseText.indexOf('错误描述'), data.responseText.indexOf('错误信息'));
                        $.messager.alert('错误', emsg);
                        $.Hidemsg();
                    } catch(ex) {
                        $.messager.alert('错误', data.responseText + '');
                    }
                }
                return false;
            }
        }
    });
});

$(function(){
	showSaleDocSelect();
	showSaleDocDate();
    //查看模式情况下,删除和上传附件功能禁止使用
	if(location.href.indexOf("load=detail")!=-1){
		$(".jeecgDetail").hide();
	}
	
	if(location.href.indexOf("mode=read")!=-1){
		//查看模式控件禁用
		$("#formobj").find(":input").attr("disabled","disabled");
	}
	if(location.href.indexOf("mode=onbutton")!=-1){
		//其他模式显示提交按钮
		$("#sub_tr").show();
	}
});

//保存
function neibuClick() {
	if($("#projInput").val()=="" || $("#projInput").val()==null){
		alert("项目信息不能为空！");
		return;
	}
	if($("#title").val()=="" || $("#title").val()==null){
		alert("公告标题不能为空！");
		return;
	}
    var tenderIds = "";//选择的标段id串
    $('input[type=checkbox][name=packname]').each(function(){
  	    if(this.checked)
  		    tenderIds += this.value+",";
    })
    if(tenderIds=="" || tenderIds==null){
    	alert("请选择标段");
		return;
	}else{
		tenderIds = tenderIds.substring(0,tenderIds.length-1);
		$("#packids").val(tenderIds);
	}

    if($("#effectStartDate").val()=="" || $("#effectStartDate").val()==null){
		alert("公告起始时间不能为空！");
		return;
	}
    if($("#effectEndDate").val()=="" || $("#effectEndDate").val()==null){
		alert("公告结束时间不能为空！");
		return;
	}
  
  $.ajax({
		url : 'tBFailBulletinController.do?doUpdate',
		type : 'post',
		data:{
			id:$("#id").val(),
			tenderIds:tenderIds,
			title:$("#title").val(),
			bulletinType:$("#bulletinType").val(),
			effectStartDate:$("#effectStartDate").val(),
			effectEndDate:$("#effectEndDate").val(),
			projectId:$("#projid").val()
		},
		cache : false,
		success : function(data) {
			var d = $.parseJSON(data);
			//公告
			var tBBulletin = d.obj;
			//公告id
			var id = tBBulletin.id;
			window.location.href = 'tBFailBulletinController.do?goFailBulletinContentUpdate&id='+id;
		}
	});
}
  //返回
  function back() {
		var loadPageUrl = parent.document.getElementById("loadPageUrl");
		var loadPageUrlStr  = (loadPageUrl!=null&&loadPageUrl!="")?$(loadPageUrl).val():'';
		window.location.href = (loadPageUrlStr!=null&&loadPageUrlStr!="")?loadPageUrlStr:'tBFailBulletinController.do?list';
  }
  
 //选择项目
  function openTenderSelect(confirmDesc, cancelDesc) {
		$.dialog({
			width:600,
			height:500,
	        id: 'LHG1976Daaa',
	        title: "选择项目",
	        max: false,
	        min: false,
	        resize: false,
	        content: 'url:tBTenderProjectController.do?selectProject',
	        lock:true,
	        button: [
	                 {name: confirmDesc, callback: callbackTenderSelect, focus: true},
	               	 {name: cancelDesc, callback: function (){}}
	             ]
	        
	    });
	}

	//回调函数存储选中的值
	function callbackTenderSelect() {
		var iframe = this.iframe.contentWindow;
		var names=iframe.gettendersListSelections('packidnames').toString();
		var id=iframe.gettendersListSelections('id');
		var tendername=iframe.gettendersListSelections('tendername');
		var projInput = "";
		var packDiv = "";
		var packids = "";
		//接收弹框的回填值
			$("#packDiv").empty();
			$.ajax({
					url : 'tBTenderProjectController.do?getPackListbyTenderidForFailBid&tenderId='+id,
					type : 'post',
					data:{
					},
					cache : false,
					success : function(data) {
						var d = $.parseJSON(data);
						var packObject = d.obj;//公告
						var myobj=eval(packObject);
						for(var i=0;i<myobj.length;i++){
						    var packid=myobj[i].id;
						    var packname=myobj[i].packName;
						    var packStatus=myobj[i].packNo;
						    var packNo=myobj[i].tenderNo;//包组
						    if(packStatus=='00'){
						  	    $("#packDiv").append("<input type='checkbox' disabled='disabled' name='packname' value='"+packid+"'/><label>"+"["+packNo+"]"+packname+"</label>");
						    }else{
					      	    $("#packDiv").append("<input type='checkbox' name='packname' value='"+packid+"'/><label>"+"["+packNo+"]"+packname+"</label>");
					        }
						} 
						$("#packDiv").append("<span id='spanid' style='display: block;clear: both;line-height: 30px;'><a href='#' id='selectid' onclick='selectPackage() style='border: 1px #f90 solid;border-radius: 3px;padding: 2px 5px;color: #f90;''>全选</a></span>");
							$("#projInput").val(tendername);
							$("#projid").val(id);
					}
			});
	}

	
	function selectPackage(){
		$("input[name='packname']:not(:disabled)").attr("checked",true);
		$("#spanid").html("<a href='#' id='selectid' onclick='selectPackageNo()' style='border: 1px #f90 solid;border-radius: 3px;padding: 2px 5px;color: #f90;'>反选</a>");
	}
	function selectPackageNo(){
		$("input[name='packname']:not(:disabled)").attr("checked",false);
		$("#spanid").html("<a href='#' id='selectid' onclick='selectPackage()' style='border: 1px #f90 solid;border-radius: 3px;padding: 2px 5px;color: #f90;'>全选</a>");
	}