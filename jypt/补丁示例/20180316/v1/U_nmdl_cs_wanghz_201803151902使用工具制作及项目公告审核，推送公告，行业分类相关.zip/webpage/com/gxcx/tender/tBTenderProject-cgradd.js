//保存
function save() {
	var tenderno = $("#tenderno").val().trim();
	$.ajax({
		url: "tBTenderProjectController.do?checkTenderNo",
		data: {tenderno:tenderno},
		type: "post",
		dataType:"json",
		success:function(d){
			if (d.msg == '00') {
				$("#tendernoCheck").html('编号已存在！');
				$("#tendernoCheck").addClass("Validform_wrong");
				$("#tendernoCheck").removeClass("Validform_right");
				alert('编号已存在！');
				//$("#tenderno").focus();
				return ;
			}/**
			else if(d.msg == '02') {
				$("#tendernoCheck").html('项目编码不能包含汉字或中文符号！');
				$("#tendernoCheck").addClass("Validform_wrong");
				$("#tendernoCheck").removeClass("Validform_right");
				alert('项目编码不能包含汉字或中文符号！');
				//$("#tenderno").focus();
				return ;
			} */
			else {
				saveConfirm();
			}
		}
	});
}

function saveConfirm(){
	$.dialog.confirm("确认保存?", function(){
        if (checkMoney()) {
        	var jsonObj = formToJsonObject("formobj");
        	jsonObj.useStatus = "00";
        	jsonObj.tenderno = $.trim($("#tenderno").val());
        	//按钮不可用
			$(".btn").attr("disabled", "disabled");
        	$.ajax({
        		url : 'tBTenderProjectController.do?doAdd&optFlag=save',
        		type : 'post',
        		data: jsonObj,
        		cache : false,
        		success : function(jsonData){
        			 var data = $.parseJSON(jsonData);
        			 alert(data.msg);
        			 if (data.success == true) {
        				 //上传附件处理
        				 dealFile(data);
        			 }
        		}
        	});
        }
	});
}



function checkTendernoChild(childId) {
	var tenderno=$("#"+childId).val();
	if(tenderno == ""){
		$("#tendernoCheck").html('编号不能为空！');
		$("#tendernoCheck").addClass("Validform_wrong");
		$("#tendernoCheck").removeClass("Validform_right");
		return false;
	}else{
		if(tenderno.length > 50){
			$("#tendernoCheck").html('编号不能超过50个字符！');
			$("#tendernoCheck").addClass("Validform_wrong");
			$("#tendernoCheck").removeClass("Validform_right");
			return false;
		}else{
			$("#tendernoCheck").html('校验通过');
			$("#tendernoCheck").addClass("Validform_right");
			$("#tendernoCheck").removeClass("Validform_wrong");
		}
	}
	buildTenderno();
	
	//校验合同编号唯一性
	var tenderNo = $("#tenderno").val();
	$.ajax({
		url : 'tBTenderProjectController.do?checkTenderNo',
		type : 'post',
		data : {tenderno:tenderNo,
			id:$("#id").val()
		},
		cache : false,
		async: false,
		success : function(data) {
			var d = $.parseJSON(data);
			if(d.msg == 00){
				$("#tendernoCheck").html('编号已存在！');
				$("#tendernoCheck").addClass("Validform_wrong");
				$("#tendernoCheck").removeClass("Validform_right");
			}else{
				$("#tendernoCheck").html('校验通过');
				$("#tendernoCheck").addClass("Validform_right");
				$("#tendernoCheck").removeClass("Validform_wrong");
			}
		}
	});	
}
function buildTenderno(){
	var tenderno1=$("#tenderno1").val();
	var tenderno2=$("#tenderno2").val();
	$("#tenderno").val(tenderno1+"-"+tenderno2);
}
/******   项目编号唯一校验     ******/
function checkTenderno() {
	buildTenderno();
	var tenderno=$("#tenderno").val();
	var tenderno1=$("#tenderno1").val();
	var tenderno2=$("#tenderno2").val();
	if(tenderno == ""||tenderno1 == ""||tenderno2 == ""){
		$("#tendernoCheck").html('编号不能为空！');
		$("#tendernoCheck").addClass("Validform_wrong");
		$("#tendernoCheck").removeClass("Validform_right");
		return;
	}else{
		if(tenderno.length > 50){
			$("#tendernoCheck").html('编号不能超过50个字符！');
			$("#tendernoCheck").addClass("Validform_wrong");
			$("#tendernoCheck").removeClass("Validform_right");
			return;
		}else{
			$("#tendernoCheck").html('校验通过');
			$("#tendernoCheck").addClass("Validform_right");
			$("#tendernoCheck").removeClass("Validform_wrong");
		}
	}
	//二次招标的项目，不进行项目编号重复性校验操作
	var sourceTenderId = $("#sourceTenderId").val();
	if (sourceTenderId == undefined || sourceTenderId == "") {
		$.ajax({
			url: "tBTenderProjectController.do?checkTenderNo",
			data: {tenderno:tenderno,
					id:$("#id").val()
					},
			type: "post",
			dataType:'json',
			async: false,
			success:function(d){
				if (d.msg == '00') {
					$("#tendernoCheck").html('编号已存在！');
					$("#tendernoCheck").addClass("Validform_wrong");
					$("#tendernoCheck").removeClass("Validform_right");
				} else {
					$("#tendernoCheck").html('通过信息验证！');
					$("#tendernoCheck").removeClass("Validform_wrong");
					$("#tendernoCheck").addClass("Validform_right");
				}
			}
		});
	}
}

