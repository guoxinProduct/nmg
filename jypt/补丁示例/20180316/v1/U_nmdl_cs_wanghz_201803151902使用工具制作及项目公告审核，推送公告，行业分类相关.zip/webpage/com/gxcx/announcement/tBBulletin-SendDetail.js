$(function() {
	init();
});
//页面初始化
function init() {
	editor.addListener("ready", function() {
		editor.setContent($("#content").val(), false);
	});//防止在按钮按下的时候，编辑器还没初始化
}
//返回
function back() {
	window.location.href = 'tBBulletinController.do?sendlist';
}
//保存并生成公告
function neibuClick() {
    $("#saveid").attr("disabled",true);
    $.ajax({
		url : 'tBBulletinController.do?doSendBulletin',
		type : 'post',
		data:{
			id:$("#id").val()
		},
		cache : false,
		success : function(data) {
			var d = $.parseJSON(data);
			var tBBulletin = d.obj;//公告
			var id = tBBulletin.id//公告id
			alert('操作成功');
			window.location.href = 'tBBulletinController.do?sendlist';
		}
	});
}