function add(title,url,id) {
	window.location.href = url;
}


function detail(title,url) {
	window.location.href = url;
}
