$(function() {
	init();
});
//页面初始化
function init() {
	editor.addListener("ready", function() {
		editor.setContent($("#content").val(), false);
	});//防止在按钮按下的时候，编辑器还没初始化
}

$(function() {
	//查看模式情况下,删除和上传附件功能禁止使用
	if (location.href.indexOf("load=detail") != -1) {
		$(".jeecgDetail").hide();
	}
});

//返回
function back() {
	window.location.href = 'tBBidBulletinController.do?list';
}

/**
 * 审核通过
 */
function auditPass() {
	var id=$("#id").val();
	var reason=$('#auditReason').val();
	/**if ($.trim(reason) == null || $.trim(reason) == '') {
		alert("请输入审核意见！");
		return false;
	}*/
	$("#buttonAuditPass").attr("disabled","disabled");
	$("#buttonAuditNoPass").attr("disabled", 'disabled');
	$.ajax({
		url : 'tBBidBulletinController.do?auditBulletin',
		type : 'post',
		data: {
			id:id,
			relstatus:"01",
			auditReason:reason
		},
		cache : false,
		success : function(data) {
			alert('操作成功！');
			frameElement.api.close();
		}
	});
}
/**
 * 退回审核
 */
function auditNoPass() {
	var id=$("#id").val();
	var reason=$('#auditReason').val();
	if ($.trim(reason) == null || $.trim(reason) == '') {
		alert("请输入审核意见！");
		return false;
	} 
	$.ajax({
		url : 'tBBidBulletinController.do?auditBulletin',
		type : 'post',
		data: {
			id:id,
			relstatus:"02",
			auditReason:reason
		},
		cache : false,
		success : function(data) {
			alert('操作成功！');
			frameElement.api.close();
		}
	});
}
