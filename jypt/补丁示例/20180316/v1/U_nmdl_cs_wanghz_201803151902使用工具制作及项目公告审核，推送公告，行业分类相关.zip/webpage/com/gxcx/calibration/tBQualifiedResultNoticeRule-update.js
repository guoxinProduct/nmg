$(function(){
	showSaleDocSelect();
	showSaleDocDate();
	showSaleBidSelect();
	showisRemoteOpening();
	showTwoBidOpening();
	
});

//下一步
function neibuClick() {
	/**
	// 时间非空校验
	if (checkDateEmpty() == false) {
		return;
	}
	
	if(checkDate()==false){//时间校验
		return;
	}*/
	var jsonObj = formToJsonObject("formobj");
    $("#saveid").attr("disabled",true);
    $.ajax({
		url : 'tBBaseNoticeController.do?doRuleUpdate',
		type : 'post',
		data:jsonObj,
		cache : false,
		success : function(data) {
			var type = $("#type").val();
			if(type=="add"){
				window.location.href = 'tBQualifiedSupplierController.do?goNoticeAdd&id='+$("#qualifiedResultId").val();//跳转到编辑资审结果通知书
			}else{
				window.location.href = 'tBQualifiedSupplierController.do?goNoticeUpdate&id='+$("#qualifiedResultId").val();//跳转到编辑资审结果通知书
			}
		}
	});
}
//返回
function back() {
	window.location.href = 'tBQualifiedSupplierController.do?noticeList';
}
 
//时间非空校验
function checkDateEmpty() {
	if ($("#effectStartDate").val() == ""
			|| $("#effectStartDate").val() == null) {
		alert("报名开始时间不能为空！");
		return false;
	}
	if ($("#effectEndDate").val() == "" || $("#effectEndDate").val() == null) {
		alert("报名截止时间不能为空！");
		return false;
	}

	if ($("#docDownloadStartTime").val() == ""
			|| $("#docDownloadStartTime").val() == null) {
		alert("文件下载开始时间不能为空！");
		return false;
	}
	if ($("#docDownloadEndTime").val() == ""
			|| $("#docDownloadEndTime").val() == null) {
		alert("文件下载截止时间不能为空！");
		return false;
	}

	if ($('#flage').val() == 'yes') {
		if ($("input:radio[name=isSaleOnline]:checked").val() == "1"
				&& $("input:radio[name=isSaleDocFee]:checked").val() == "1") {
			if ($("#docSaleStartTime").val() == ""
					|| $("#docSaleStartTime").val() == null) {
				alert("招标文件售卖开始时间不能为空！");
				return false;
			}
			if ($("#docSaleEndTime").val() == ""
					|| $("#docSaleEndTime").val() == null) {
				alert("招标文件售卖结束时间不能为空！");
				return false;
			}
		}
	/**	
		if ($("input:radio[name=isRemoteOpening]:checked").val() == "1"
			&& $("input:radio[name=isTwoBidOpening]:checked").val() == "1") {
			if ($("#technicalOpenBidStartDate").val() == ""
					|| $("#technicalOpenBidStartDate").val() == null) {
				alert("商务标、技术标开标时间不能为空！");
				return false;
			}
		}*/
	}

	if ($("#submitStartDate").val() == ""
			|| $("#submitStartDate").val() == null) {
		alert("投标开始时间不能为空！");
		return false;
	}
	if ($("#submitEndDate").val() == "" || $("#submitEndDate").val() == null) {
		alert("投标结束时间不能为空！");
		return false;
	}
	var isTwoBidOpening=$("input:radio[name=isTwoBidOpening]:checked").val();//是否两步开标
	if(isTwoBidOpening=='1'){//如果是两步开标
		var technicalOpenBidStartDate= $("#technicalOpenBidStartDate").val();
		if(technicalOpenBidStartDate==''||technicalOpenBidStartDate==null){
			alert("商务技术标开标时间不能为空！");
			return false;
		}
		if ($("#openBidStartDate").val() == ""|| $("#openBidStartDate").val() == null) {
			alert("经济开标时间不能为空！");
			return false;
		}
	}else{
		if ($("#openBidStartDate").val() == ""|| $("#openBidStartDate").val() == null) {
			alert("开标时间不能为空！");
			return false;
		}
	}
}

//校验时间
function checkDate(){
  	/*if($("#effectStartDate").val()=="" || $("#effectEndDate").val()==""){
		alert('报名时间不能为空！');
		return false;
    }
  	if($("#docDownloadStartTime").val()=="" || $("#docDownloadEndTime").val()==""){
  		alert('文件下载时间不能为空！');
  		return false;
  	}
  	if($("input:radio[name=isSaleOnline]:checked").val()=="1"){
  		if($("#docSaleStartTime").val()=="" || $("#docSaleEndTime").val()==""){
	  		alert('招标文件售卖时间不能为空！');
	  		return false;
	  	}
  	}
  	if($("#submitStartDate").val()=="" || $("#submitEndDate").val()==""){
  		alert('投标时间不能为空！');
  		return false;
  	}
  	if($("#openBidStartDate").val()==""){
  		alert('开标时间不能为空！');
  		return false;
  	}*/
	
	//报名开始时间不能小于当前时间
	var effectStartDate = $("#effectStartDate").val();
	var selectDate = new Date(effectStartDate.replace(/-/g, "/"));  
	var nowDate = new Date()-1000*60;
	if(selectDate<nowDate){
		alert('报名开始时间不得小于当前时间！');
		return false;
	}
  	
	if($("#effectStartDate").val()>$("#effectEndDate").val()){alert('【报名截止时间】应大于【报名开始时间】！');return false;}
	if($("#submitStartDate").val()>$("#submitEndDate").val()){alert('【投标结束时间】应大于【投标开始时间】！');return false;}
	if($("#docSaleStartTime").val()>$("#docSaleEndTime").val()){alert('【招标文件售卖结束时间】应大于【招标文件售卖开始时间】！');return false;}
	//if($("#submitEndDate").val()>$("#openBidStartDate").val()){alert('【开标时间】应大于等于【投标结束时间】！');return false;}
	if($("#docDownloadStartTime").val()>$("#docDownloadEndTime").val()){alert('【文件下载截止时间】应大于等于【文件下载开始时间】！');return false;}
	/**
	if((newDate($('#submitEndDate').val()+':00').getTime()-newDate($('#submitStartDate').val()+':00').getTime())/(1000*60*60*24)<5){
		alert('【投标结束时间】距离【投标开始时间】应不小于5天');
		return false;
	}
	if((newDate($('#docSaleEndTime').val()+':00').getTime()-newDate($('#docSaleStartTime').val()+':00').getTime())/(1000*60*60*24)<5){
		alert('【招标文件售卖结束时间】距离【招标文件售卖开始时间】应不小于5天');
		return false;
	}
	if((newDate($('#docDownloadEndTime').val()+':00').getTime()-newDate($('#docDownloadStartTime').val()+':00').getTime())/(1000*60*60*24)<5){
		alert('【文件下载截止时间】距离【文件下载开始时间】应不小于5天');
		return false;
	}*/
	var isTwoBidOpening=$("input:radio[name=isTwoBidOpening]:checked").val();//是否两步开标
	var isSaleOnline=$("input:radio[name=isSaleOnline]:checked").val();//是否在线售卖标书费
	var isSaleDocFee=$("input:radio[name=isSaleDocFee]:checked").val();//是否收取标书费
	if($('#flage').val()=='yes'){
		if(isTwoBidOpening=='1'){
		//	if($("#technicalOpenBidStartDate").val()>$("#openBidStartDate").val()){alert('【商务技术标开标时间】不能大于【经济标开标时间】！');return false;}
			var aaa=timeFn($('#technicalOpenBidStartDate').val(),$('#openBidStartDate').val());
			if(aaa<=0){
				alert('【经济标开标时间】应该大于【商务技术标开标时间】！');
				return false;
			}
			
			var techDiff=timeFn($('#docSaleStartTime').val(),$('#technicalOpenBidStartDate').val());
			if(techDiff<20){
				alert('【商务技术标开标时间】距离【招标文件售卖开始时间】应不小于20天');
				return false;
			}
		}else{
			var diff=timeFn($('#docSaleStartTime').val(),$('#openBidStartDate').val());
			if(diff<20){
				alert('【开标时间】距离【招标文件售卖开始时间】应不小于20天');
				return false;
			}
		}
		
	}//else{
	//	if((newDate($('#openBidStartDate').val()).getTime()-newDate($('#docDownloadStartTime').val()).getTime())/(1000*60*60*24)<20){
	//		alert('【开标时间】距离【文件下载开始时间】应不小于20天');
	//			return false;
	//	}
	//}
}
  
function newDate(str){
	strall=str.split(' ');
	var datestr = strall[0].split('-');
	var timestr = new Array();
	if(strall.length>=2){
		timestr = strall[1].split(':');
	}
	var date = new Date();
	//**月份记得减一
	date.setUTCFullYear(datestr[0], datestr[1]-1, datestr[2]);
	if(timestr.length!=0){
		date.setUTCHours(timestr[0], timestr[1], timestr[2], 0);
	}
	return date;
}
  
//切换是否收取标书费
function showSaleDocSelect(){
	var isSaleDocFee = $("input:radio[name=isSaleDocFee]:checked").val();
    if(isSaleDocFee=='0'){
	    $("#isSaleDocFeeId_1").hide();
	    $("#isSaleDocFeeId_2").hide();
	    $("#isSaleDocFeeId_3").hide();
	    $("input:radio[name=isSaleOnline][value=0]").attr("checked",'checked');
	    showSaleDocDate();
	    $("#isSaleDocFeeId").attr("colspan","3");
    }else{
	    $("#isSaleDocFeeId_1").show();
	    $("#isSaleDocFeeId_2").show();
	    $("#isSaleDocFeeId_3").show();
	    $("#isSaleDocFeeId").attr("colspan","1");
	}
}
  
//切换是否在线收取标书费
function showSaleDocDate(){
	var isSaleOnline = $("input:radio[name=isSaleOnline]:checked").val();
    if(isSaleOnline=='0'){
	    $("#saleDocDateId_1").hide();
	    $("#saleDocDateId_2").hide();
	    $("#docSaleStartTime").val("");
	    $("#docSaleEndTime").val("");
	    $("#saleDocDateId").attr("colspan","3");
    }else{
	    $("#saleDocDateId_1").show();
	    $("#saleDocDateId_2").show();
	    $("#saleDocDateId").attr("colspan","1");
	}
}

//切换是否收取投标服务费
function showSaleBidSelect(){
	var isSaleBidFee = $("input:radio[name=isSaleBidFee]:checked").val();
	if(isSaleBidFee=='0'){
		$("#isSaleBidFeeId_1").hide();
		$("#isSaleBidFeeId_2").hide();
		$("#isSaleBidFeeId").attr("colspan","3");
	}else{
		$("#isSaleBidFeeId_1").hide();
		$("#isSaleBidFeeId_2").hide();
		$("#isSaleBidFeeId").attr("colspan","1");
	}
}
//切换是否远程开标
function showisRemoteOpening(){
	var isRemoteOpening = $("input:radio[name=isRemoteOpening]:checked").val();//是否远程开标
    if(isRemoteOpening=='0'){//不是远程开标 隐藏两步开标，并且只显示开标时间
	    $("#isTwoBidOpeningId_1").hide();
	    $("#isTwoBidOpeningId").hide();
	    $("#isRemoteOpeningId").attr("colspan","3");
	    $("#technicalOpenBidStartDate").val("");
	    $("input[type=radio][name=isTwoBidOpening][value=0]").attr("checked",true);  
	    $("#openingTimeTxt").text('开标时间:');
	    showTwoBidOpening();
    }else{//显示是否两步开标
    	$("#isTwoBidOpeningId_1").show();
  	    $("#isTwoBidOpeningId").show();
  	    $("#isRemoteOpeningId").attr("colspan","1");
    }
}
	
//切换是否两步开标
function showTwoBidOpening(){
	var isTwoBidOpening = $("input:radio[name=isTwoBidOpening]:checked").val();
    if(isTwoBidOpening=='0'){
    	$("#technicalOpenBidStartDate_1").hide();
  	    $("#technicalOpenBidStartDate_2").hide();
	    $("#technicalOpenBidStartDate").val("");
	    $("#openBidStartDateId").attr("colspan","3");
	    $("#openingTimeTxt").text('开标时间:');
    }else{
	    $("#technicalOpenBidStartDate_1").show();
	    $("#technicalOpenBidStartDate_2").show();
	    $("#openBidStartDateId").attr("colspan","1");
	    $("#openingTimeTxt").text('经济标开标时间:');
	}
}