
//编辑
function update(id) {
	createwindow('编辑','tBWorkGroupController.do?goUpdate&id='+id);
}
 
//查看
function detail(title, url) {
	createdetailwindow('查看', url);
}

//返回列表页面
function getTenderProjectList() {
    window.location.href= "tBTenderProjectController.do?list";
}