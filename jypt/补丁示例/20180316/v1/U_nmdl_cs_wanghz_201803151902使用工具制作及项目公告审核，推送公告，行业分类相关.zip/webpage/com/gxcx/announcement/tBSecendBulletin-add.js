$(function(){
	showSaleDocSelect();
	showSaleDocDate();
});

//保存并生成公告
function neibuClick() {
	if($("#projInput").val()=="" || $("#projInput").val()==null){
		alert("项目信息不能为空！");
		return;
	}
	if($("#title").val()=="" || $("#title").val()==null){
		alert("公告标题不能为空！");
		return;
	}
	var isChangetime = $("input:radio[name=isChangetime]:checked").val();
	if(isChangetime=='1')//时间变更时
		{
		//增加了时间的校验
		if(checkDate()==false){//时间校验
			return;
		}
		}
	
    var tenderIds = [];//选择的标段id
    $('input[type=checkbox][name=packname]:checked').each(function(){
  		tenderIds.push(this.value);
    })
    if(tenderIds.length==0){
    	alert("请选择标段");
		return;
	}else{
		$("#packids").val(tenderIds.toString());
	}
    $("#saveid").attr("disabled",true);
    var isChangetime = $("input:radio[name=isChangetime]:checked").val();
    $.ajax({
		url : 'secendBulletinController.do?doAddSecendBulletin',
		type : 'post',
		data:{
			tenderIds:tenderIds.toString(),
			title:$("#title").val(),
			id:$("#id").val(),
			effectStartDate:$("#effectStartDate").val(),
			effectEndDate:$("#effectEndDate").val(),
			submitStartDate:$("#submitStartDate").val(),
			submitEndDate:$("#submitEndDate").val(),
			docSaleStartTime:$("#docSaleStartTime").val(),
			docSaleEndTime:$("#docSaleEndTime").val(),
			openBidStartDate:$("#openBidStartDate").val(),
			docDownloadStartTime:$("#docDownloadStartTime").val(),
			docDownloadEndTime:$("#docDownloadEndTime").val(),
			projectId:$("#projid").val(),
			isChangetime:isChangetime,
			isSaleDocByProject:$("input:radio[name=isSaleDocByProject]:checked").val(),
			isSaleOnline:$("input:radio[name=isSaleOnline]:checked").val(),
			isSaleDocFee:$("input:radio[name=isSaleDocFee]:checked").val(),
			isReDoBiddingFile:$("input:radio[name=isReDoBiddingFile]:checked").val()
			
		},
		cache : false,
		success : function(data) {
			var d = $.parseJSON(data);
			var tBBulletin = d.obj;//公告
			var id = tBBulletin.id//公告id
			window.location.href = 'secendBulletinController.do?goSecendBulletinContentAdd&id='+id;//跳转到编辑公告页面
		}
	});
}
//返回
function back() {
	window.location.href = 'secendBulletinController.do?list&tenderId='+$("#projectId").val() +"&batches="+$("#batches").val();
}
 
//校验时间
function checkDate(){
  	if($("#effectStartDate").val()=="" || $("#effectEndDate").val()==""){
		alert('报名时间不能为空！');
		return false;
    }
  	if($("#docDownloadStartTime").val()=="" || $("#docDownloadEndTime").val()==""){
  		alert('文件下载时间不能为空！');
  		return false;
  	}
  	if($("input:radio[name=isSaleOnline]:checked").val()=="1"){
  		if($("#docSaleStartTime").val()=="" || $("#docSaleEndTime").val()==""){
	  		alert('招标文件售卖时间不能为空！');
	  		return false;
	  	}
  	}
  	if($("#submitStartDate").val()=="" || $("#submitEndDate").val()==""){
  		alert('投标时间不能为空！');
  		return false;
  	}
  	if($("#openBidStartDate").val()==""){
  		alert('开标时间不能为空！');
  		return false;
  	}
  	
	if($("#effectStartDate").val()>$("#effectEndDate").val()){alert('【报名截止时间】应大于【报名开始时间】！');return false;}
	if($("#submitStartDate").val()>$("#submitEndDate").val()){alert('【投标结束时间】应大于【投标开始时间】！');return false;}
	if($("#docSaleStartTime").val()>$("#docSaleEndTime").val()){alert('【招标文件售卖结束时间】应大于【招标文件售卖开始时间】！');return false;}
	if($("#submitEndDate").val()>$("#openBidStartDate").val()){alert('【开标时间】应大于等于【投标结束时间】！');return false;}
	if($("#docDownloadStartTime").val()>$("#docDownloadEndTime").val()){alert('【文件下载截止时间】应大于等于【文件下载开始时间】！');return false;}
	
	if((newDate($('#submitEndDate').val()).getTime()-newDate($('#submitStartDate').val()).getTime())/(1000*60*60*24)<5){
		alert('【投标结束时间】距离【投标开始时间】应不小于5天');
		return false;
	}
	if((newDate($('#docSaleEndTime').val()).getTime()-newDate($('#docSaleStartTime').val()).getTime())/(1000*60*60*24)<5){
		alert('【招标文件售卖结束时间】距离【招标文件售卖开始时间】应不小于5天');
		return false;
	}
	if((newDate($('#docDownloadEndTime').val()).getTime()-newDate($('#docDownloadStartTime').val()).getTime())/(1000*60*60*24)<5){
		alert('【文件下载截止时间】距离【文件下载开始时间】应不小于5天');
		return false;
	}
	if((newDate($('#openBidStartDate').val()).getTime()-newDate($('#docSaleStartTime').val()).getTime())/(1000*60*60*24)<20){
		alert('【开标时间】距离【招标文件售卖开始时间】应不小于20天');
			return false;
	}
}
  
function newDate(str){
	strall=str.split(' ');
	var datestr = strall[0].split('-');
	var timestr = new Array();
	if(strall.length>=2){
		timestr = strall[1].split(':');
	}
	var date = new Date();
	//**月份记得减一
	date.setUTCFullYear(datestr[0], datestr[1]-1, datestr[2]);
	if(timestr.length!=0){
		date.setUTCHours(timestr[0], timestr[1], timestr[2], 0);
	}
	return date;
}
  
//切换是否收取标书费
function showSaleDocSelect(){
	var isSaleDocFee = $("input:radio[name=isSaleDocFee]:checked").val();
    if(isSaleDocFee=='0'){
	    $("#isSaleDocFeeId_1").hide();
	    $("#isSaleDocFeeId_2").hide();
	    $("#isSaleDocFeeId_3").hide();
	    $("input:radio[name=isSaleOnline][value=0]").attr("checked",'checked');
	    showSaleDocDate();
	    $("#isSaleDocFeeId").attr("colspan","3");
    }else{
	    $("#isSaleDocFeeId_1").show();
	    $("#isSaleDocFeeId_2").show();
	    $("#isSaleDocFeeId_3").show();
	    $("#isSaleDocFeeId").attr("colspan","1");
	}
}
  
//切换是否在线收取标书费
function showSaleDocDate(){
	var isSaleOnline = $("input:radio[name=isSaleOnline]:checked").val();
    if(isSaleOnline=='0'){
	    $("#saleDocDateId_1").hide();
	    $("#saleDocDateId_2").hide();
	    $("#docSaleStartTime").val("");
	    $("#docSaleEndTime").val("");
	    $("#saleDocDateId").attr("colspan","3");
    }else{
	    $("#saleDocDateId_1").show();
	    $("#saleDocDateId_2").show();
	    $("#saleDocDateId").attr("colspan","1");
	}
}
  
  
//选择项目
function openTenderSelect(confirmDesc, cancelDesc) {
	$.dialog({
		width:600,
		height:500,
        id: 'LHG1976Daaa',
        title: "选择项目",
        max: false,
        min: false,
        resize: false,
        content: 'url:tBTenderProjectController.do?selectProject&tenderId='+$("#projectId").val()+'&type=bulletin',
        lock:true,
        button: [
                {name: confirmDesc, callback: callbackTenderSelect, focus: true},
               	{name: cancelDesc, callback: function (){}}
             ]
        
    });
}
function getPack(e, bulletinId,stageid){
	var flag=1;
	$("input[name='packname']").each(function(i,n){
		if($(n).attr("checked")== 'checked'){
			 if($(n).attr("bulletinId")!=bulletinId)
			{
				 flag=0; 
			}
		}
	})
	if(flag==0){
		alert('请选择同一招标公告下的标段发起新轮次');
		$("#"+stageid).attr("checked",false);
		return;
	}
	//补充原始时间规则
	
//	$.ajax({
//		url : 'tBProjectRuleController.do?getProjectRuleStageId&stageid='+stageid,
//		type : 'post',
//		data:{
//		},
//		cache : false,
//		success : function(data) {
//			var d = $.parseJSON(data);
//		 
//			var isPack=d.attributes.effectStartDate;
//			var packObject = d.obj;
//			var myobj=eval(packObject);
//			for(var i=0;i<myobj.length;i++){
//				 $("#oldeffectStartDate").text(d.attributes.effectStartDate);
//				 $("#oldeffectEndDate").text(d.attributes.effectEndDate);
//				 $("#oldsubmitStartDate").text(d.attributes.submitStartDate);
//				 $("#oldsubmitEndDate").text(d.attributes.submitEndDate);
//				 $("#olddocSaleStartTime").text(d.attributes.docSaleStartTime);
//				 $("#olddocSaleEndTime").text(d.attributes.docSaleEndTime);
//				 $("#oldopenBidStartDate").text(d.attributes.openBidStartDate);
//				 $("#olddocDownloadStartTime").text(d.attributes.docDownloadStartTime);
//				 $("#olddocDownloadEndTime").text(d.attributes.docDownloadEndTime);
//			} 
//		}
//	});
	
 
}
//回调函数存储选中的值
function callbackTenderSelect() {
	var iframe = this.iframe.contentWindow;
	var names=iframe.gettendersListSelections('packidnames').toString();
	var id=iframe.gettendersListSelections('id');
	var tendername=iframe.gettendersListSelections('tendername');
	var projInput = "";
	var packDiv = "";
	var packids = "";
	//接收弹框的回填值
		$("#packDiv").empty();
		$.ajax({
			url : 'tBTenderProjectController.do?getPackbyTenderid&tenderId='+id+'&type=changebulletin',
			type : 'post',
			data:{
			},
			cache : false,
			success : function(data) {
				var d = $.parseJSON(data);
				var tenderType = d.msg;//资格审查方式(00:资审,01:后审)
				$("#bulletinTypeId").empty();
				if(tenderType=='00'){
					$("#bullTypeSpan2").hide();
					$("#bullTypeSpan").show();
					$("#bulletinTypeTemp").val('21');
					$("input:radio[name=bulletinType][value=01]").attr("checked",'');
					$("input:radio[name=bulletinType][value=21]").attr("checked",'checked');
				}else{
//					$("input:radio[name=bulletinType][value=21]").hide();
//					$("input:radio[name=bulletinType][value=01]").attr("checked",'checked');
					$("#bullTypeSpan").hide();
					$("#bullTypeSpan2").show();
					$("#bulletinTypeTemp").val('01');
				}
				var packObject = d.obj;//公告
				var myobj=eval(packObject);
				for(var i=0;i<myobj.length;i++){
					var packid=myobj[i].id;
					var packname=myobj[i].packName;
					var packStatus=myobj[i].packNo;
					var packstageType=myobj[i].packstageType;
					 var bulletinId=myobj[i].bulletinId;
					 var stageid=myobj[i].stageid;
					 var packNo=myobj[i].tenderNo;//包组
					if(tenderType=='00'){
						if(packstageType=='00'){
							if(packStatus=='00'){
								$("#packDiv").append("<input type='checkbox' disabled='disabled' name='packname' value='"+packid+"'/><label>"+packname+"</label>");
							}else{
								$("#packDiv").append("<input type='checkbox'    name='packname' onchange=\"getPack(this,'"+bulletinId+"\','"+stageid+"\');\" stageid='"+stageid+"' id='"+stageid+"' bulletinId='"+bulletinId+"' packNo='"+packNo+"' value='"+packid+"'/><label>"+packname+"</label>");
						    }
						}
					}else if(tenderType=='01'){
						if(packstageType=='01'){
							if(packStatus=='00'){
								$("#packDiv").append("<input type='checkbox' disabled='disabled' name='packname' value='"+packid+"'/><label>"+packname+"</label>");
							}else{
								$("#packDiv").append("<input type='checkbox'    name='packname' onchange=\"getPack(this,'"+bulletinId+"\','"+stageid+"\');\" stageid='"+stageid+"' id='"+stageid+"' bulletinId='"+bulletinId+"' packNo='"+packNo+"' value='"+packid+"'/><label>"+packname+"</label>");
						    }
						}
					}
				} 
				$("#packDiv").append("<span id='spanid' style='display: block;clear: both;line-height: 30px;'><a href='#' id='selectid' onclick='selectPackage()' style='border: 1px #f90 solid;border-radius: 3px;padding: 2px 5px;color: #f90;'>全选</a></span>");
				$("#projInput").val(tendername);
				$("#title").val("【"+tendername+"】"+"二次公告");
				$("#projid").val(id);
			}
		});
}


function selectPackage(){
	$("input[name='packname']:not(:disabled)").attr("checked",true);
	$("#spanid").html("<a href='#' id='selectid' onclick='selectPackageNo()' style='border: 1px #f90 solid;border-radius: 3px;padding: 2px 5px;color: #f90;'>反选</a>");
}
function selectPackageNo(){
	$("input[name='packname']:not(:disabled)").attr("checked",false);
	$("#spanid").html("<a href='#' id='selectid' onclick='selectPackage()' style='border: 1px #f90 solid;border-radius: 3px;padding: 2px 5px;color: #f90;'>全选</a>");
}
