$(function(){
	showSaleDocSelect();
	showSaleBidSelect();
	showSaleDocDate();
	showisRemoteOpening();
	showTwoBidOpening();
});

//切换是否远程开标
function showisRemoteOpening(){
	var isRemoteOpening = $("input:radio[name=isRemoteOpening]:checked").val();//是否远程开标
    if(isRemoteOpening=='0'){//不是远程开标 隐藏两步开标，并且只显示开标时间
	    $("#isTwoBidOpeningId_1").hide();
	    $("#isTwoBidOpeningId").hide();
	    $("#isRemoteOpeningId").attr("colspan","3");
	    $("#technicalOpenBidStartDate").val("");
	    $("input[type=radio][name=isTwoBidOpening][value=0]").attr("checked",true);  
	    $("#openingTimeTxt").text('开标时间:');
	    showTwoBidOpening();
    }else{//显示是否两步开标
    	$("#isTwoBidOpeningId_1").show();
  	    $("#isTwoBidOpeningId").show();
  	    $("#isRemoteOpeningId").attr("colspan","1");
    }
}
	
//切换是否两步开标
function showTwoBidOpening(){
	var isTwoBidOpening = $("input:radio[name=isTwoBidOpening]:checked").val();
    if(isTwoBidOpening=='0'){
    	$("#technicalOpenBidStartDate_1").hide();
  	    $("#technicalOpenBidStartDate_2").hide();
	    $("#technicalOpenBidStartDate").val("");
	    $("#openBidStartDateId").attr("colspan","3");
	    $("#openingTimeTxt").text('开标时间:');
    }else{
	    $("#technicalOpenBidStartDate_1").show();
	    $("#technicalOpenBidStartDate_2").show();
	    $("#openBidStartDateId").attr("colspan","1");
	    $("#openingTimeTxt").text('经济标开标时间:');
	}
}
//保存并生成公告
function neibuClick() {
	if($("#projInput").val()=="" || $("#projInput").val()==null){
		alert("项目信息不能为空！");
		return;
	}
	if($("#title").val()=="" || $("#title").val()==null){
		alert("公告标题不能为空！");
		return;
	}
	if(checkDate()==false){//时间校验
		return;
	}
	var tenderIds = [];//选择的标段id
    $('input[type=checkbox][name=packname]:checked').each(function(){
  		tenderIds.push(this.value);
    })
    if(tenderIds.length==0){
    	alert("请选择标段");
		return;
	}else{
		$("#packids").val(tenderIds.toString());
	}
    $("#saveid").attr("disabled",true);
    $.ajax({
		url : 'tBBulletinController.do?doAoUpdateYW',
		type : 'post',
		data:{
			id:$("#id").val(),
			tenderIds:tenderIds.toString(),
			title:$("#title").val(),
			bulletinType:$("#bulletinTypeTemp").val(),
			effectStartDate:$("#effectStartDate").val(),
			effectEndDate:$("#effectEndDate").val(),
			submitStartDate:$("#submitStartDate").val(),
			submitEndDate:$("#submitEndDate").val(),
			docSaleStartTime:$("#docSaleStartTime").val(),
			docSaleEndTime:$("#docSaleEndTime").val(),
			openBidStartDate:$("#openBidStartDate").val(),
			docDownloadStartTime:$("#docDownloadStartTime").val(),
			docDownloadEndTime:$("#docDownloadEndTime").val(),
			technicalOpenBidStartDate:$("#technicalOpenBidStartDate").val(),
			projectId:$("#projid").val(),
			isSaleDocByProject:$("input:radio[name=isSaleDocByProject]:checked").val(),
			isSaleBidByProject:$("input:radio[name=isSaleBidByProject]:checked").val(),
			isSaleOnline:$("input:radio[name=isSaleOnline]:checked").val(),
			isSaleDocFee:$("input:radio[name=isSaleDocFee]:checked").val(),
			isSaleBidFee:$("input:radio[name=isSaleBidFee]:checked").val(),
			isRemoteOpening:$("input:radio[name=isRemoteOpening]:checked").val(),
			iscaSignup:$("input:radio[name=iscaSignup]:checked").val(),
			isTwoBidOpening:$("input:radio[name=isTwoBidOpening]:checked").val(),
			isAssociationSignup:$("input:radio[name='isAssociationSignup']:checked").val(),
			isNatureSignup:$("input:radio[name='isNatureSignup']:checked").val()
		},
		cache : false,
		success : function(data) {
			var d = $.parseJSON(data);
			var tBBulletin = d.obj;//公告
			var id = tBBulletin.id//公告id
			window.location.href = 'tBBulletinController.do?listYW';
		}
	});
}
//返回
function back() {
	var loadPageUrl = parent.document.getElementById("loadPageUrl");
	var loadPageUrlStr  = (loadPageUrl!=null&&loadPageUrl!="")?$(loadPageUrl).val():'';
	window.location.href = (loadPageUrlStr!=null&&loadPageUrlStr!="")?loadPageUrlStr:'tBBulletinController.do?listYW';
}
  
//时间校验
function checkDate(){
	if($("#effectStartDate").val()=="" || $("#effectEndDate").val()==""){
		alert('报名时间不能为空！');
		return false;
	}
	if($("#docDownloadStartTime").val()=="" || $("#docDownloadEndTime").val()==""){
		alert('文件下载时间不能为空！');
		return false;
	}
	if($("input:radio[name=isSaleDocFee]:checked").val()=="1"&&$("input:radio[name=isSaleOnline]:checked").val()=="1"){
		if($("#docSaleStartTime").val()=="" || $("#docSaleEndTime").val()==""){
	  		alert('招标文件售卖时间不能为空！');
	  		return false;
	  	}
	}
	if($("#submitStartDate").val()=="" || $("#submitEndDate").val()==""){
		alert('投标时间不能为空！');
		return false;
	}
	if($("#openBidStartDate").val()==""){
		alert('开标时间不能为空！');
		return false;
	}
	
	if($("#effectStartDate").val()>$("#effectEndDate").val()){alert('【报名截止时间】应大于【报名开始时间】！');return false;}
	if($("#submitStartDate").val()>$("#submitEndDate").val()){alert('【投标结束时间】应大于【投标开始时间】！');return false;}
	if($("#docSaleStartTime").val()>$("#docSaleEndTime").val()){alert('【招标文件售卖结束时间】应大于【招标文件售卖开始时间】！');return false;}
	if($("#submitEndDate").val()>$("#openBidStartDate").val()){alert('【开标时间】应大于等于【投标结束时间】！');return false;}
	if($("#docDownloadStartTime").val()>$("#docDownloadEndTime").val()){alert('【文件下载截止时间】应大于等于【文件下载开始时间】！');return false;}
	
	if((newDate($('#submitEndDate').val()).getTime()-newDate($('#submitStartDate').val()).getTime())/(1000*60*60*24)<5){
		alert('【投标结束时间】距离【投标开始时间】应不小于5天');
		return false;
	}
	if((newDate($('#docSaleEndTime').val()).getTime()-newDate($('#docSaleStartTime').val()).getTime())/(1000*60*60*24)<5){
		alert('【招标文件售卖结束时间】距离【招标文件售卖开始时间】应不小于5天');
		return false;
	}
	if((newDate($('#docDownloadEndTime').val()).getTime()-newDate($('#docDownloadStartTime').val()).getTime())/(1000*60*60*24)<5){
		alert('【文件下载截止时间】距离【文件下载开始时间】应不小于5天');
		return false;
	}
	if((newDate($('#openBidStartDate').val()).getTime()-newDate($('#docSaleStartTime').val()).getTime())/(1000*60*60*24)<20){
		alert('【开标时间】距离【招标文件售卖开始时间】应不小于20天');
		return false;
	}
}
  
function newDate(str){
	strall=str.split(' ');
	var datestr = strall[0].split('-');
	var timestr = new Array();
	if(strall.length>=2){
		timestr = strall[1].split(':');
	}
	var date = new Date();
	//**月份记得减一
	date.setUTCFullYear(datestr[0], datestr[1]-1, datestr[2]);
	if(timestr.length!=0){
		date.setUTCHours(timestr[0], timestr[1], timestr[2], 0);
	}
	return date;
}

//切换是否收取标书费
function showSaleDocSelect(){
	var isSaleDocFee = $("input:radio[name=isSaleDocFee]:checked").val();
	if(isSaleDocFee=='0'){
		$("#isSaleDocFeeId_1").hide();
		$("#isSaleDocFeeId_2").hide();
		$("#isSaleDocFeeId_3").hide();
		//$("input:radio[name=isSaleOnline][value=0]").attr("checked",'checked');
		showSaleDocDate();
		$("#isSaleDocFeeId").attr("colspan","3");
	}else{
		$("#isSaleDocFeeId_1").show();
		$("#isSaleDocFeeId_2").show();
		$("#isSaleDocFeeId_3").show();
		$("#isSaleDocFeeId").attr("colspan","1");
	}
}

//切换是否在线收取标书费
function showSaleDocDate(){
	var isSaleOnline = $("input:radio[name=isSaleOnline]:checked").val();
	if(isSaleOnline=='0'){
		$("#saleDocDateId_1").hide();
		$("#saleDocDateId_2").hide();
		$("#docSaleStartTime").val("");
		$("#docSaleEndTime").val("");
		$("#saleDocDateId").attr("colspan","3");
	}else{
		$("#saleDocDateId_1").show();
		$("#saleDocDateId_2").show();
		$("#saleDocDateId").attr("colspan","1");
	}
}

//切换公告类型
function changeBulletinType(){
	var bulletinType = $("input:radio[name=bulletinType]:checked").val();
	var id = $("#projid").val();
	var objid=$("#id").val();
	$("#packDiv").empty();
	$.ajax({
			url : 'tBTenderProjectController.do?getPackbyTenderid&tenderId='+id+'&type=bulletin&objid='+objid,
			type : 'post',
			async: false,
			data:{
			},
			cache : false,
			success : function(data) {
				var d = $.parseJSON(data);
				var packObject = d.obj;//公告
				var myobj=eval(packObject);
				for(var i=0;i<myobj.length;i++){
					var packid=myobj[i].id;
					var packname=myobj[i].packName;
					var packStatus=myobj[i].packNo;
					var packstageType=myobj[i].packstageType;
					if(bulletinType=='01'){
						if(packstageType=='01'){
							if(packStatus=='00'){
								$("#packDiv").append("<input type='checkbox' disabled='disabled' name='packname' value='"+packid+"'/><label><label>"+packname+"</label></label>&nbsp;&nbsp;");}
						    else{
						    	$("#packDiv").append("<input type='checkbox' name='packname' value='"+packid+"'/><label>"+packname+"</label>&nbsp;&nbsp;");
						    }
						}
					}else if(bulletinType=='21'){
						if(packstageType=='00'){
							if(packStatus=='00'){
								$("#packDiv").append("<input type='checkbox' disabled='disabled' name='packname' value='"+packid+"'/><label><label>"+packname+"</label></label>&nbsp;&nbsp;");}
						    else{
						    	$("#packDiv").append("<input type='checkbox' name='packname' value='"+packid+"'/><label><label>"+packname+"</label></label>&nbsp;&nbsp;");
						    }
						}
					}
				} 
				$("#packDiv").append("<span id='spanid' style='display: block;clear: both;line-height: 30px;'><a href='#' id='selectid' onclick='selectPackage()' style='border: 1px #f90 solid;border-radius: 3px;padding: 2px 5px;color: #f90;'>全选</a></span>");
			}
	});
}

//选择项目
function openTenderSelect(confirmDesc, cancelDesc) {
	$.dialog({
		width:600,
		height:500,
        id: 'LHG1976Daaa',
        title: "选择项目",
        max: false,
        min: false,
        resize: false,
        content: 'url:tBTenderProjectController.do?selectProject&type=bulletin&tenderId=',
        lock:true,
        button: [
                {name: confirmDesc, callback: callbackTenderSelect, focus: true},
               	{name: cancelDesc, callback: function (){}}
             ]
        
    });
}

//回调函数存储选中的值
function callbackTenderSelect() {
	var iframe = this.iframe.contentWindow;
	var names=iframe.gettendersListSelections('packidnames').toString();
	var id=iframe.gettendersListSelections('id');
	var tendername=iframe.gettendersListSelections('tendername');
	var projInput = "";
	var packDiv = "";
	var packids = "";
	//接收弹框的回填值
		$("#packDiv").empty();
		var objid=$("#id").val();
		 $.ajax({
				url : 'tBTenderProjectController.do?getPackbyTenderid&tenderId='+id+'&type=bulletin&objid='+objid,
				type : 'post',
				async: false,
				data:{
				},
				cache : false,
				success : function(data) {
					var d = $.parseJSON(data);
					var tenderType = d.msg;//资格审查方式(00:资审,01:后审)
					$("#bulletinTypeId").empty();
					if(tenderType=='00'){
						$("#bullTypeSpan2").hide();
						$("#bullTypeSpan").show();
						$("#bulletinTypeTemp").val('21');
						$("input:radio[name=bulletinType][value=01]").attr("checked",'');
						$("input:radio[name=bulletinType][value=21]").attr("checked",'checked');
					}else{
//						$("input:radio[name=bulletinType][value=21]").hide();
//						$("input:radio[name=bulletinType][value=01]").attr("checked",'checked');
						$("#bullTypeSpan").hide();
						$("#bullTypeSpan2").show();
						$("#bulletinTypeTemp").val('01');
					}
					var packObject = d.obj;//公告
					var myobj=eval(packObject);
					for(var i=0;i<myobj.length;i++){
						var packid=myobj[i].id;
						var packname=myobj[i].packName;
						var packStatus=myobj[i].packNo;
						var packstageType=myobj[i].packstageType;
						if(tenderType=='00'){
							if(packstageType=='00'){
								if(packStatus=='00'){
									$("#packDiv").append("<input type='checkbox' disabled='disabled' name='packname' value='"+packid+"'/>"+packname+"&nbsp;&nbsp;");
								}else{
							    	$("#packDiv").append("<input type='checkbox' name='packname' value='"+packid+"'/>"+packname+"&nbsp;&nbsp;");
							    }
							}
						}else if(tenderType=='01'){
							if(packstageType=='01'){
								if(packStatus=='00'){
									$("#packDiv").append("<input type='checkbox' disabled='disabled' name='packname' value='"+packid+"'/>"+packname+"&nbsp;&nbsp;");
								}else{
							    	$("#packDiv").append("<input type='checkbox' name='packname' value='"+packid+"'/>"+packname+"&nbsp;&nbsp;");
							    }
							}
						}
					}
					$("#packDiv").append("<span id='spanid'><a href='#' id='selectid' onclick='selectPackage()'>全选</a></span>");
					if(tenderType==00){
						$("#title").val("【"+tendername+"】"+"资审公告");
					}else{
						$("#title").val("【"+tendername+"】"+"招标公告");
					}
					$("#projInput").val(tendername);
					$("#projid").val(id);
				}
			});
}

function selectPackage(){
	$("input[name='packname']:not(:disabled)").attr("checked",true);
	$("#spanid").html("<a href='#' id='selectid' onclick='selectPackageNo()'>反选</a>");
}
function selectPackageNo(){
	$("input[name='packname']:not(:disabled)").attr("checked",false);
	$("#spanid").html("<a href='#' id='selectid' onclick='selectPackage()'>全选</a>");
}

//切换是否收取投标服务费
function showSaleBidSelect(){
	var isSaleBidFee = $("input:radio[name=isSaleBidFee]:checked").val();
	if(isSaleBidFee=='0'){
		$("#isSaleBidFeeId_1").hide();
		$("#isSaleBidFeeId_2").hide();
		$("#isSaleBidFeeId").attr("colspan","3");
	}else{
		$("#isSaleBidFeeId_1").hide();
		$("#isSaleBidFeeId_2").hide();
		$("#isSaleBidFeeId").attr("colspan","1");
	}
}
