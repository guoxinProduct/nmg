function save(){
	var jsonObj = formToJsonObject("formobj");
    $.ajax({
		url : 'tBBulletinController.do?doAddBidServicePrice',
		type : 'post',
		data : jsonObj,
		cache : false,
		success : function(data) {
			alert("设置成功！");
			back();
		}
	});
}

function back(){
	window.location.href = "tBBulletinController.do?list";
}

function changePrice(){
	var bidService = $("#bidService").val();
	if(bidService != null){
		for(i = 0; i < $("#mytable tr").length-2; i++){
			$("#bidServicePrice"+i).val(bidService);
		}
	}
}