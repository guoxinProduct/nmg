//保存
function save() {
	var tenderno = $("#tenderno").val().trim();
	$.ajax({
		url: "tBTenderProjectController.do?checkTenderNo",
		data: {tenderno:tenderno},
		type: "post",
		dataType:"json",
		success:function(d){
			if (d.msg == '00') {
				$("#tendernoCheck").html('编号已存在！');
				$("#tendernoCheck").addClass("Validform_wrong");
				$("#tendernoCheck").removeClass("Validform_right");
				alert('编号已存在！');
				//$("#tenderno").focus();
				return ;
			}/**
			else if(d.msg == '02') {
				$("#tendernoCheck").html('项目编码不能包含汉字或中文符号！');
				$("#tendernoCheck").addClass("Validform_wrong");
				$("#tendernoCheck").removeClass("Validform_right");
				alert('项目编码不能包含汉字或中文符号！');
				//$("#tenderno").focus();
				return ;
			} */
			else {
				saveConfirm();
			}
		}
	});
}

function saveConfirm(){
	$.dialog.confirm("确认保存?", function(){
        if (checkMoney()) {
        	var jsonObj = formToJsonObject("formobj");
        	jsonObj.useStatus = "00";
        	jsonObj.tenderno = $.trim($("#tenderno").val());
        	//按钮不可用
			$(".btn").attr("disabled", "disabled");
        	$.ajax({
        		url : 'tBTenderProjectController.do?doAdd&optFlag=save',
        		type : 'post',
        		data: jsonObj,
        		cache : false,
        		success : function(jsonData){
        			 var data = $.parseJSON(jsonData);
        			 alert(data.msg);
        			 if (data.success == true) {
        				 //上传附件处理
        				 dealFile(data);
        			 }
        		}
        	});
        }
	});
}

