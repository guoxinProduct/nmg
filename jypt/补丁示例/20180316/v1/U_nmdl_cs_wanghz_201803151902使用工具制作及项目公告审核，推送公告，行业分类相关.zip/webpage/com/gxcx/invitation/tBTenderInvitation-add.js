$(function() {
	showSaleBidSelect();
	$('#isAuditPayment_ID').hide();
	showisRemoteOpening();
	showTwoBidOpening();
	
})
//切换是否远程开标
function showisRemoteOpening(){
	var isRemoteOpening = $("input:radio[name=isRemoteOpening]:checked").val();//是否远程开标
    if(isRemoteOpening=='0'){//不是远程开标 隐藏两步开标，并且只显示开标时间
	    $("#isTwoBidOpeningId_1").hide();
	    $("#isTwoBidOpeningId").hide();
	    $("#isRemoteOpeningId").attr("colspan","3");
	    $("#technicalOpenBidStartDate").val("");
	    $("input[type=radio][name=isTwoBidOpening][value=0]").attr("checked",true);  
	    $("#openingTimeTxt").text('开标时间:');
	    showTwoBidOpening();
    }else{//显示是否两步开标
    	$("#isTwoBidOpeningId_1").show();
  	    $("#isTwoBidOpeningId").show();
  	    $("#isRemoteOpeningId").attr("colspan","1");
    }
}
	
//切换是否两步开标
function showTwoBidOpening(){
	var isTwoBidOpening = $("input:radio[name=isTwoBidOpening]:checked").val();
    if(isTwoBidOpening=='0'){
    	$("#technicalOpenBidStartDate_1").hide();
  	    $("#technicalOpenBidStartDate_2").hide();
	    $("#technicalOpenBidStartDate").val("");
	    $("#openBidStartDateId").attr("colspan","3");
	    $("#openingTimeTxt").text('开标时间:');
    }else{
	    $("#technicalOpenBidStartDate_1").show();
	    $("#technicalOpenBidStartDate_2").show();
	    $("#openBidStartDateId").attr("colspan","1");
	    $("#openingTimeTxt").text('经济标开标时间:');
	}
}
// 切换是否收取投标服务费
function showSaleBidSelect() {
	var isSaleBidFee = $("input:radio[name=isSaleBidFee]:checked").val();
	if (isSaleBidFee == '0') {
		$("#isSaleBidFeeId_1").hide();
		$("#isSaleBidFeeId_2").hide();
		$("#isSaleBidFeeId").attr("colspan", "3");
	} else {
		$("#isSaleBidFeeId_1").hide();
		$("#isSaleBidFeeId_2").hide();
		$("#isSaleBidFeeId").attr("colspan", "1");
	}
}

// 保存生成附件
var neibuClickFlag = false;
function neibuClick() {
	if ($("#projInput").val() == "" || $("#projInput").val() == null) {
		alert("项目信息不能为空！");
		return;
	}
	if ($("#title").val() == "" || $("#title").val() == null) {
		alert("公告标题不能为空！");
		return;
	}
	var i = 0;
	var tenderIds = "";// 选择的标段id串
	$('input[type=radio][name=packname]').each(function() {
		if (this.checked) {
			i = i * 1 + 1;
			tenderIds += this.value + ",";
		}

	})
	if (tenderIds == "" || tenderIds == null || parseInt(i) > parseInt(1)) {
		alert("请选择标段");
		return;
	} else {
		tenderIds = tenderIds.substring(0, tenderIds.length - 1);
		$("#packids").val(tenderIds);
	}
/**
	// 时间非空校验
	if (checkDateEmpty() == false) {
		return;
	}

	// 时间校验---暂时注释
	if(checkDate()==false){
		return;
	}*/
	$("#saveid").attr("disabled",true);
	neibuClickFlag = true;
	$.ajax({
				url : 'tBTenderInvitationController.do?doAdd',
				type : 'post',
				data : {
					tenderIds : tenderIds,
					title : $("#title").val(),
					invitationType : $(
							"input:radio[name=invitationType]:checked").val(),
					effectStartDate : $("#effectStartDate").val(),
					effectEndDate : $("#effectEndDate").val(),
					submitStartDate : $("#submitStartDate").val(),
					submitEndDate : $("#submitEndDate").val(),
					docSaleStartTime : $("#docSaleStartTime").val(),
					docSaleEndTime : $("#docSaleEndTime").val(),
					openBidStartDate : $("#openBidStartDate").val(),
					docDownloadStartTime : $("#docDownloadStartTime").val(),
					docDownloadEndTime : $("#docDownloadEndTime").val(),
					projectId : $("#projid").val(),
					iscaSignup : $("input:radio[name=iscaSignup]:checked")
							.val(),
					isSaleDocByProject : $(
							"input:radio[name=isSaleDocByProject]:checked")
							.val(),
					isSaleOnline : $("input:radio[name=isSaleOnline]:checked")
							.val(),
					isSaleDocFee : $("input:radio[name=isSaleDocFee]:checked")
							.val(),
					isRemoteOpening : $(
							"input:radio[name=isRemoteOpening]:checked").val(),

					technicalOpenBidStartDate : $("#technicalOpenBidStartDate")
							.val(),
					isSaleBidByProject : $(
							"input:radio[name=isSaleBidByProject]:checked")
							.val(),
					isTwoBidOpening : $(
							"input:radio[name=isTwoBidOpening]:checked").val(),
					isSaleBidFee : $("input:radio[name=isSaleBidFee]:checked")
							.val(),
					isAuditPayment : $(
							"input:radio[name=isAuditPayment]:checked").val()
				//	isAssociationSignup : $("input:radio[name=isAssociationSignup]:checked").val()
				},
				cache : false,
				success : function(data) {
					var d = $.parseJSON(data);
					var tBTenderInvitation = d.obj;// 邀请函
					console.log(data);
					var id = tBTenderInvitation.id// 邀请函id
					window.location.href = 'tBTenderInvitationController.do?goTBTenderInvitationContentAdd&id='
							+ id;
				}
			});
}

// 选择项目
function openTenderSelect(confirmDesc, cancelDesc) {
	$.dialog({
				width : 600,
				height : 500,
				id : 'LHG1976Daaa',
				title : "选择项目",
				max : false,
				min : false,
				resize : false,
				content : 'url:tBTenderProjectController.do?selectProject&tendermethod=01&tenderId='
						+ $("#projectId").val(),
				lock : true,
				button : [ {
					name : confirmDesc,
					callback : callbackTenderSelect,
					focus : true
				}, {
					name : cancelDesc,
					callback : function() {
					}
				} ]

			});
}

// 回调函数存储选中的值
function callbackTenderSelect() {
	var iframe = this.iframe.contentWindow;
	var names = iframe.gettendersListSelections('packidnames').toString();
	var id = iframe.gettendersListSelections('id');
	var tendername = iframe.gettendersListSelections('tendername');
	var projInput = "";
	var packDiv = "";
	var packids = "";
	// 接收弹框的回填值
	$("#packDiv").empty();
	$.ajax({
		url : 'tBTenderProjectController.do?getPackbyTenderid&tenderId=' + id
				+ '&type=invitation',
		type : 'post',
		data : {},
		cache : false,
		success : function(data) {
			var d = $.parseJSON(data);
			var tenderType = d.msg;// 项目类型
			$("#invitationTypeId").empty();
			if (tenderType == '00') {
				$("input:radio[name=invitationType][value=01]").attr("checked",
						'');
				$("input:radio[name=invitationType][value=21]").attr("checked",
						'checked');
			} else {
				$("input:radio[name=invitationType][value=21]").attr("checked",
						'');
				$("input:radio[name=invitationType][value=01]").attr("checked",
						'checked');
			}
			$("#invitationType").val(d.msg);
			var packObject = d.obj;// 包组
			var myobj = eval(packObject);
			// 根据项目类型，显隐包组
			for (var i = 0; i < myobj.length; i++) {
				var packid = myobj[i].id;
				var packname = myobj[i].packName;
				var packStatus = myobj[i].packNo;
				var packstageType = myobj[i].packstageType;
				var tenderNo=myobj[i].tenderNo;
				if(packname==null||$.trim(packname)==''){
					$("#packDiv").empty();
					$("#packDiv").append("<span style='color:red'>此项目的包组信息不全，请完善此项目的包组信息</span>&nbsp;&nbsp;<a href='tBProjectPackageController.do?list&tenderid="+id+"'>完善包组信息</a>");
					break;
				}
				if (tenderType == '00') {
					if (packstageType == '00') {
						if (packStatus == '00') {
							$("#packDiv").append(
									"<input type='radio' disabled='disabled' name='packname' value='"
											+ packid + "'/>"+"["+tenderNo+"]" + packname);
						} else {
							$("#packDiv").append(
									"<input type='radio' name='packname' value='"
											+ packid + "'/>" +"["+tenderNo+"]"+ packname);
						}
					}
				} else if (tenderType == '01') {
					if (packstageType == '01') {
						if (packStatus == '00') {
							$("#packDiv").append(
									"<input type='radio' disabled='disabled' name='packname' value='"
											+ packid + "'/>"+"["+tenderNo+"]" + packname);
						} else {
							$("#packDiv").append(
									"<input type='radio' name='packname' value='"
											+ packid + "'/>"+"["+tenderNo+"]"+ packname);
						}
					}
				}
			}
			$("#title").val("【" + tendername + "】" + "邀请函");
			$("#projInput").val(tendername);
			$("#projid").val(id);
		}
	});
}

// 返回
function back() {
	var loadPageUrl = parent.document.getElementById("loadPageUrl");
	var loadPageUrlStr = (loadPageUrl != null && loadPageUrl != "") ? $(
			loadPageUrl).val() : '';
	window.location.href = (loadPageUrlStr != null && loadPageUrlStr != "") ? loadPageUrlStr
			: 'tBTenderInvitationController.do?getTBTenderInvitationListForAgency';
}

$(function() {
	$("#formobj").Validform(
			{
				tiptype : 1,
				btnSubmit : "#btn_sub",
				btnReset : "#btn_reset",
				ajaxPost : true,
				beforeSubmit : function(curform) {
					var tag = true;
					// 提交前处理
					return tag;
				},
				usePlugin : {
					passwordstrength : {
						minLen : 6,
						maxLen : 18,
						trigger : function(obj, error) {
							if (error) {
								obj.parent().next().find(".Validform_checktip")
										.show();
								obj.find(".passwordStrength").hide();
							} else {
								$(".passwordStrength").show();
								obj.parent().next().find(".Validform_checktip")
										.hide();
							}
						}
					}
				},
				callback : function(data) {
					if (data.success == true) {
						var win = frameElement.api.opener;
						win.reloadTable();
						win.tip(data.msg);
						frameElement.api.close();
					} else {
						if (data.responseText == ''
								|| data.responseText == undefined) {
							$.messager.alert('错误', data.msg);
							$.Hidemsg();
						} else {
							try {
								var emsg = data.responseText.substring(
										data.responseText.indexOf('错误描述'),
										data.responseText.indexOf('错误信息'));
								$.messager.alert('错误', emsg);
								$.Hidemsg();
							} catch (ex) {
								$.messager.alert('错误', data.responseText + '');
							}
						}
						return false;
					}
				}
			});
});

$(function() {
	showSaleDocSelect();
	showSaleDocDate();
	// 查看模式情况下,删除和上传附件功能禁止使用
	if (location.href.indexOf("load=detail") != -1) {
		$(".jeecgDetail").hide();
	}

	if (location.href.indexOf("mode=read") != -1) {
		// 查看模式控件禁用
		$("#formobj").find(":input").attr("disabled", "disabled");
	}
	if (location.href.indexOf("mode=onbutton") != -1) {
		// 其他模式显示提交按钮
		$("#sub_tr").show();
	}
});

// 时间非空校验
function checkDateEmpty() {
	if ($("#effectStartDate").val() == ""
			|| $("#effectStartDate").val() == null) {
		alert("报名开始时间不能为空！");
		return false;
	}
	if ($("#effectEndDate").val() == "" || $("#effectEndDate").val() == null) {
		alert("报名截止时间不能为空！");
		return false;
	}

	if ($("#docDownloadStartTime").val() == ""
			|| $("#docDownloadStartTime").val() == null) {
		alert("文件下载开始时间不能为空！");
		return false;
	}
	if ($("#docDownloadEndTime").val() == ""
			|| $("#docDownloadEndTime").val() == null) {
		alert("文件下载截止时间不能为空！");
		return false;
	}

	if ($('#flage').val() == 'yes') {
		if ($("input:radio[name=isSaleOnline]:checked").val() == "1"
				&& $("input:radio[name=isSaleDocFee]:checked").val() == "1") {
			if ($("#docSaleStartTime").val() == ""
					|| $("#docSaleStartTime").val() == null) {
				alert("招标文件售卖开始时间不能为空！");
				return false;
			}
			if ($("#docSaleEndTime").val() == ""
					|| $("#docSaleEndTime").val() == null) {
				alert("招标文件售卖结束时间不能为空！");
				return false;
			}
		}
		
	/**	if ($("input:radio[name=isRemoteOpening]:checked").val() == "1"
			&& $("input:radio[name=isTwoBidOpening]:checked").val() == "1") {
			if ($("#technicalOpenBidStartDate").val() == ""
					|| $("#technicalOpenBidStartDate").val() == null) {
				alert("商务标、技术标开标时间不能为空！");
				return false;
			}
		}*/
	}

	if ($("#submitStartDate").val() == ""
			|| $("#submitStartDate").val() == null) {
		alert("投标开始时间不能为空！");
		return false;
	}
	if ($("#submitEndDate").val() == "" || $("#submitEndDate").val() == null) {
		alert("投标结束时间不能为空！");
		return false;
	}
	var isTwoBidOpening=$("input:radio[name=isTwoBidOpening]:checked").val();//是否两步开标
	if(isTwoBidOpening=='1'){//如果是两步开标
		var technicalOpenBidStartDate= $("#technicalOpenBidStartDate").val();
		if(technicalOpenBidStartDate==''||technicalOpenBidStartDate==null){
			alert("商务技术标开标时间不能为空！");
			return false;
		}
		if ($("#openBidStartDate").val() == ""|| $("#openBidStartDate").val() == null) {
			alert("经济开标时间不能为空！");
			return false;
		}
	}else{
		if ($("#openBidStartDate").val() == ""|| $("#openBidStartDate").val() == null) {
			alert("开标时间不能为空！");
			return false;
		}
	}
}

// 时间校验
function checkDate() {
	//有效开始时间不能小于当前时间
	var effectStartDate = $("#effectStartDate").val();
	var selectDate = new Date(effectStartDate.replace(/-/g, "/"));  
	var nowDate = new Date()-1000*60;
	if(selectDate<nowDate){
		alert('有效开始时间不得小于当前时间！');
		return false;
	}
	
	if ($("#effectStartDate").val() > $("#effectEndDate").val()) {
		alert('【有效截止时间】应大于【有效开始时间】！');
		return false;
	}
	if ($("#submitStartDate").val() > $("#submitEndDate").val()) {
		alert('【投标结束时间】应大于【投标开始时间】！');
		return false;
	}

	if ($('#flage').val() == 'yes') {
		if ($("#docSaleStartTime").val() > $("#docSaleEndTime").val()) {
			alert('【招标文件售卖结束时间】应大于【招标文件售卖开始时间】！');
			return false;
		}
	}
/**
	if ($("#submitEndDate").val() > $("#openBidStartDate").val()) {
		alert('【开标时间】应大于等于【投标结束时间】！');
		return false;
	}*/
	if ($("#docDownloadStartTime").val() > $("#docDownloadEndTime").val()) {
		alert('【文件下载截止时间】应大于等于【文件下载开始时间】！');
		return false;
	}
/**
	if ((newDate($('#submitEndDate').val()).getTime() - newDate(
			$('#submitStartDate').val()).getTime())
			/ (1000 * 60 * 60 * 24) < 5) {
		alert('【投标结束时间】距离【投标开始时间】应不小于5天');
		return false;
	}
	if ($('#flage').val() == 'yes') {
		if ((newDate($('#docSaleEndTime').val()).getTime() - newDate(
				$('#docSaleStartTime').val()).getTime())
				/ (1000 * 60 * 60 * 24) < 5) {
			alert('【招标文件售卖结束时间】距离【招标文件售卖开始时间】应不小于5天');
			return false;
		}
	}
	if ((newDate($('#docDownloadEndTime').val()).getTime() - newDate(
			$('#docDownloadStartTime').val()).getTime())
			/ (1000 * 60 * 60 * 24) < 5) {
		alert('【文件下载截止时间】距离【文件下载开始时间】应不小于5天');
		return false;
	}*/
	var isTwoBidOpening=$("input:radio[name=isTwoBidOpening]:checked").val();//是否两步开标
	var isSaleOnline=$("input:radio[name=isSaleOnline]:checked").val();//是否在线售卖标书费
	var isSaleDocFee=$("input:radio[name=isSaleDocFee]:checked").val();//是否收取标书费
	if($('#flage').val()=='yes'){
		if(isTwoBidOpening=='1'){
			//if($("#technicalOpenBidStartDate").val()>$("#openBidStartDate").val()){alert('【商务技术标开标时间】不能大于【经济标开标时间】！');return false;}
			var aaa=timeFn($('#technicalOpenBidStartDate').val(),$('#openBidStartDate').val());
			if(aaa<=0){
				alert('【经济标开标时间】应该大于【商务技术标开标时间】！');
				return false;
			}
			
			var techDiff=timeFn($('#docSaleStartTime').val(),$('#technicalOpenBidStartDate').val());
			if(techDiff<20){
				alert('【商务技术标开标时间】距离【招标文件售卖开始时间】应不小于20天');
				return false;
			}
		}else{
			var diff=timeFn($('#docSaleStartTime').val(),$('#openBidStartDate').val());
			if(diff<20){
				alert('【开标时间】距离【招标文件售卖开始时间】应不小于20天');
				return false;
			}
		}
		
	}//else{
	//	if((newDate($('#openBidStartDate').val()).getTime()-newDate($('#docDownloadStartTime').val()).getTime())/(1000*60*60*24)<20){
	//		alert('【开标时间】距离【文件下载开始时间】应不小于20天');
	//			return false;
	//	}
	//}
}

function newDate(str) {
	strall = str.split(' ');
	var datestr = strall[0].split('-');
	var timestr = new Array();
	if (strall.length >= 2) {
		timestr = strall[1].split(':');
	}

	var date = new Date();

	// **月份减一
	date.setUTCFullYear(datestr[0], datestr[1] - 1, datestr[2]);
	if (timestr.length != 0) {
		date.setUTCHours(timestr[0], timestr[1], timestr[2], 0);
	}

	return date;
}
function showSaleDocSelect() {
	var isSaleDocFee = $("input:radio[name=isSaleDocFee]:checked").val();
	if (isSaleDocFee == '0') {
		$("#isSaleDocFeeId_1").hide();
		$("#isSaleDocFeeId_2").hide();
		$("#isSaleDocFeeId_3").hide();
		$("#docSaleStartTime").val("");
		$("#docSaleEndTime").val("");
		$("#isSaleDocFeeId").attr("colspan", "3");
	} else {
		$("#isSaleDocFeeId_1").show();
		$("#isSaleDocFeeId_2").show();
		$("#isSaleDocFeeId_3").show();
		$("#isSaleDocFeeId").attr("colspan", "1");
	}
}
function showSaleDocDate() {
	var isSaleOnline = $("input:radio[name=isSaleOnline]:checked").val();
	if (isSaleOnline == '0') {
		$("#saleDocDateId_1").hide();
		$("#saleDocDateId_2").hide();
		$("#docSaleStartTime").val("");
		$("#docSaleEndTime").val("");
		$("#saleDocDateId").attr("colspan", "3");
	} else {
		$("#saleDocDateId_1").show();
		$("#saleDocDateId_2").show();
		$("#saleDocDateId").attr("colspan", "1");
	}
}
// 根据邀请函类型显隐包组信息
function changeInvitationType() {
	var invitationType = $("input:radio[name=invitationType]:checked").val();
	var id = $("#projid").val();
	$("#packDiv").empty();
	$.ajax({
		url : 'tBTenderProjectController.do?getPackbyTenderid&tenderId=' + id
				+ '&type=invitation',
		type : 'post',
		data : {},
		cache : false,
		success : function(data) {
			var d = $.parseJSON(data);
			var packObject = d.obj;// 邀请函
			var myobj = eval(packObject);
			console.log(packObject);
			for (var i = 0; i < myobj.length; i++) {
				var packid = myobj[i].id;
				var packname = myobj[i].packName;
				var packStatus = myobj[i].packNo;
				var packstageType = myobj[i].packstageType;
				var tenderNo=myobj[i].tenderNo;
				if (invitationType == '01') {
					if (packstageType == '01') {
						if (packStatus == '00') {
							$("#packDiv").append(
									"<input type='radio' disabled='disabled' name='packname' value='"
											+ packid + "'/>"+tenderNo+":" + packname);
						} else {
							$("#packDiv").append(
									"<input type='radio' name='packname' value='"
											+ packid + "'/>"+tenderNo+":" + packname);
						}
					}
				} else if (invitationType == '21') {
					if (packstageType == '00') {
						if (packStatus == '00') {
							$("#packDiv").append(
									"<input type='radio' disabled='disabled' name='packname' value='"
											+ packid + "'/>" +tenderNo+":"+ packname);
						} else {
							$("#packDiv").append(
									"<input type='radio' name='packname' value='"
											+ packid + "'/>" +tenderNo+":"+ packname);
						}
					}
				}
			}
		}
	});
}