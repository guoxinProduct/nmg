//页面初始化加载
$(document).ready(function(){
	//给时间控件加上样式
	$("input[name='createTime_begin']").attr("class","Wdate").click(function(){WdatePicker({dateFmt:'yyyy-MM-dd'});});
	$("input[name='createTime_end']").attr("class","Wdate").click(function(){WdatePicker({dateFmt:'yyyy-MM-dd'});});
});

//复制
function copyOpt(id) {
	window.location.href = "tBTenderProjectController.do?copyTenderProject&tenderid="+id;
}

//分包
function packOpt(id) {
	window.location.href = "tBProjectPackageController.do?list&tenderid="+id;
}

//工作小组
function workGroup(id) {
	window.location.href = "tBWorkGroupController.do?list&tenderid="+id;
}

//同步到公共服务平台
function toSynProjectAndPack(id) {
	$.ajax({
		url : 'SynToController.do?toSynProjectAndPack&projectId='+id,
		type : 'post',
		data: {},
		cache : false,
		success : function(jsonData){
			 var data = $.parseJSON(jsonData);
			 alert(data.msg);
		}
	});
}

//根据代理合同立项
function addByContract(title,url,id) {
	openContractSelect('确定','关闭');
}

//无代理合同立项
function addTenderProject(title,url,id) {
	window.location.href = url;
}

//编辑招标项目
function update(id) {
	window.location.href = 'tBTenderProjectController.do?goUpdate&id='+id;
}

//查看招标项目
function detail(title,url) {
	window.location.href = url;
}

/******   选择委托代理合同     ******/
//选择委托代理合同
function openContractSelect(confirmDesc, cancelDesc) {
	$.dialog({
		width:600,
		height:500,
        id: 'CONTRACT1988SELECT',
        title: "选择委托代理合同",
        max: false,
        min: false,
        resize: false,
        content: 'url:tBTenderProjectController.do?goConsignContractSelect',
        lock:true,
        button: [
            {name: confirmDesc, callback: callbackContractSelect, focus: true},
          	{name: cancelDesc, callback: function (){}}
        ]
    });
}
//回调函数存储选中的值
function callbackContractSelect() {
	var iframe = this.iframe.contentWindow;
	var contractId = iframe.getcontractListSelections('id');
	//根据选中的代理合同赋值给招标项目对象
	window.location.href = 'tBTenderProjectController.do?goAdd&contractId='+contractId;
}
/******   选择委托代理合同     ******/
