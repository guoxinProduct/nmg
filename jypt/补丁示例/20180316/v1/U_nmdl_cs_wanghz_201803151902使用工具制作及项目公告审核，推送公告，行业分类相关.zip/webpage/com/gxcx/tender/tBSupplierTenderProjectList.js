function createQuestion(id) {
	window.location.href = 'tBClarificationController.do?list&id='+id;
}
