function add(title,url,id) {
	window.location.href = url;
}

function update(id) {
	window.location.href = 'tBFailBulletinController.do?goUpdate&id='+id;
}

function detail(title,url) {
	window.location.href = url;
}

//同步到公共服务平台
function toSynWinCandidateBulletin(id) {
	$.ajax({
		url : 'SynToController.do?toSynWinCandidateBulletin&bulletinId='+id,
		type : 'post',
		data: {},
		cache : false,
		success : function(jsonData){
			 var data = $.parseJSON(jsonData);
			 alert(data.msg);
		}
	});
}