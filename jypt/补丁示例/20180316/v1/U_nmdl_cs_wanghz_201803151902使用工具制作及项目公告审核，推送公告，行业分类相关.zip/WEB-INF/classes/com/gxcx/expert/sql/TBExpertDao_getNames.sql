SELECT CONCAT(p.pack_name,':',REPLACE(GROUP_CONCAT(e.name),',','、')) 
FROM t_b_project_package p,t_b_expert_draw_and_sign es,t_b_expert e 
WHERE p.stageid=:stageId
AND p.id=es.packid AND es.expertid=e.id 