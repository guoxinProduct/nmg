 <#if dateType ?exists && dateType ?length gt 0 && dateType=='mType'>
SELECT projectId,projectCode,projectName,proStatus,openBidTime,stratTime,endTime, COUNT(1) AS pakNum FROM (
</#if>
SELECT  
count(p.id) as pakNum,
p.id AS projectId,
p.tender_no AS projectCode,
p.tender_name AS projectName,
r.open_bid_start_date AS openBidTime,
DATE_FORMAT(r.EFFECT_START_DATE,'%Y-%m-%d') AS stratTime,
DATE_FORMAT(r.EFFECT_END_DATE,'%Y-%m-%d') AS endTime,
'报名中' AS proStatus
FROM t_b_tender_project p,
  t_b_project_time_rule r,
  t_b_stage s
  WHERE  p.id = r.tenderid
    	AND s.id = r.stageid
    <#if userId ?exists && userId ?length gt 0>
			and p.create_user=  '${userId}'
		</#if>
		<#if dateType ?exists && dateType ?length gt 0 && dateType=='dType'>
    	AND DATE_FORMAT(r.EFFECT_START_DATE,'%Y-%m-%d') = DATE_FORMAT('${param['proStartDate']}','%Y-%m-%d')AND DATE_FORMAT(r.EFFECT_END_DATE,'%Y-%m-%d') =DATE_FORMAT('${param['proEndDate']}' ,'%Y-%m-%d')
    	</#if>
    	<#if dateType ?exists && dateType ?length gt 0 && dateType=='mType'>
    	AND (DATE_FORMAT(r.EFFECT_START_DATE,'%Y-%m') ='${param['proMDate']}' OR DATE_FORMAT(r.EFFECT_END_DATE,'%Y-%m') ='${param['proMDate']}')
    	</#if>
        AND p.use_status = '01'
	    and r.effective_State='01'
	    AND  s.stage_type='01'
        GROUP BY stratTime,endTime,projectId    
  <#if dateType ?exists && dateType ?length gt 0 && dateType=='mType'>
     ) zz    
 GROUP BY stratTime,endTime
 </#if>
  UNION all 
 <#if dateType ?exists && dateType ?length gt 0 && dateType=='mType'>
 SELECT projectId,projectCode,projectName,proStatus,openBidTime,stratTime,endTime, COUNT(1) AS pakNum FROM (
</#if>
SELECT 
count(p.id) as pakNum,
p.id AS projectId,
p.tender_no AS projectCode,
p.tender_name AS projectName,
r.open_bid_start_date AS openBidTime,
DATE_FORMAT(r.open_bid_start_date,'%Y-%m-%d') AS stratTime,
DATE_FORMAT(r.open_bid_start_date,'%Y-%m-%d') AS endTime,
'开标' AS proStatus
FROM t_b_tender_project p,
  t_b_project_time_rule r,
    t_b_stage s
  WHERE p.id = r.tenderid
    	AND s.id = r.stageid
<#if userId ?exists && userId ?length gt 0>
			and p.create_user=  '${userId}'
		</#if>
		<#if dateType ?exists && dateType ?length gt 0 && dateType=='dType'>
    	AND DATE_FORMAT(r.open_bid_start_date,'%Y-%m-%d') = DATE_FORMAT('${param['proStartDate']}','%Y-%m-%d')
    	AND DATE_FORMAT(r.open_bid_start_date,'%Y-%m-%d') = DATE_FORMAT('${param['proEndDate']}','%Y-%m-%d')
    	</#if>
    	<#if dateType ?exists && dateType ?length gt 0 && dateType=='mType'>
    	AND DATE_FORMAT(r.open_bid_start_date,'%Y-%m') = '${param['proMDate']}'
    	</#if>
    	 AND p.use_status = '01'
	    and r.effective_State='01'
	    AND  s.stage_type='01'
        GROUP BY openBidTime,projectId 
    <#if dateType ?exists && dateType ?length gt 0 && dateType=='mType'>
     ) zz    
 GROUP BY stratTime
 </#if>
 