select projectType,projectId,projectCode,projectName,signUpEndTime,openBidEndTime,lastDates
,createTime,proStatusCH,proStatus,signUpTime,openBidTime
from (
 SELECT 
p.QUALIFICATION_METHOD  as projectType,
p.id AS projectId,
p.tender_no AS projectCode,
p.tender_name AS projectName,
MAX( r.EFFECT_END_DATE) AS signUpEndTime,
MIN(r.open_bid_start_date) AS openBidEndTime,
IF(  r.EFFECT_START_DATE <= SYSDATE()AND r.submit_start_date > SYSDATE(),TIMESTAMPDIFF(DAY,SYSDATE(), MAX( r.EFFECT_END_DATE)),TIMESTAMPDIFF(DAY,SYSDATE(), MIN(r.open_bid_start_date)))AS lastDates,
p.CREATE_TIME AS createTime,
IF(  r.EFFECT_START_DATE <= SYSDATE()AND r.submit_start_date > SYSDATE(),'距报名结束' ,'距开标还有') AS proStatusCH,
IF( r.EFFECT_START_DATE <= SYSDATE() AND r.submit_start_date > SYSDATE(),'01' ,'02') AS proStatus,
r.EFFECT_START_DATE as signUpTime,
r.open_bid_start_date as openBidTime
FROM t_b_tender_project p
left join t_b_project_package pk on pk.TENDERID = p.id
left join t_b_stage s on pk.stageid=s.id 
left join t_b_project_time_rule r on r.packid=pk.id 
  WHERE  s.id = r.stageid  AND p.use_status = '01' AND r.effective_State='01' and p.QUALIFICATION_METHOD='01' and s.stage_type='01'
   <#if param['userId']?exists && param['userId'] ?length gt 0>  
		and p.create_user LIKE concat('%', '${param['userId']}','%') 
	</#if>
  AND (((r.EFFECT_START_DATE is null or  r.EFFECT_START_DATE <= SYSDATE())AND r.submit_start_date > SYSDATE()) OR (r.submit_start_date <= SYSDATE() AND SYSDATE() < r.open_bid_start_date))
  <#if param['search']?exists && param['search'] ?length gt 0>  
		and ( p.tender_no LIKE concat('%', '${param['search']}','%') or p.tender_name LIKE concat('%', '${param['search']}','%') ) 
	</#if>
  group by p.id
	UNION ALL 
	SELECT  
p.QUALIFICATION_METHOD  as projectType,
p.id AS projectId,
p.tender_no AS projectCode,
p.tender_name AS projectName,
'0' AS signUpEndTime,
'0' AS openBidEndTime,
0 AS lastDates,
p.CREATE_TIME AS createTime,
'未开始报名' AS proStatusCH,
'00' AS proStatus,
'' as signUpTime,
'' as openBidTime
FROM t_b_tender_project p
left join t_b_project_package pk on pk.TENDERID = p.id
left join  t_b_stage s ON pk.stageid=s.id 
  WHERE   1=1 AND p.use_status = '01' and p.QUALIFICATION_METHOD='01' and s.stage_type='01'
 <#if param['userId']?exists && param['userId'] ?length gt 0>  
		and p.create_user LIKE concat('%', '${param['userId']}','%') 
	</#if>
  <#if param['search']?exists && param['search'] ?length gt 0>  
		and ( p.tender_no LIKE concat('%', '${param['search']}','%') or p.tender_name LIKE concat('%', '${param['search']}','%') ) 
	</#if>
  AND NOT EXISTS(SELECT 1 FROM t_b_project_time_rule r  WHERE p.id = r.tenderid  AND r.effective_State='01')   
GROUP BY p.id  	 
	) zz
  GROUP BY zz.projectId 
  UNION ALL
  select  projectType,projectId,projectCode,projectName,signUpEndTime,openBidEndTime,lastDates
,createTime,proStatusCH,proStatus,signUpTime,openBidTime
  from ( 
SELECT 
p.QUALIFICATION_METHOD  as projectType,
p.id AS projectId,
p.tender_no AS projectCode,
p.tender_name AS projectName,
MAX( r.EFFECT_END_DATE) AS signUpEndTime,
MIN(r.open_bid_start_date) AS openBidEndTime,
IF(  r.EFFECT_START_DATE <= SYSDATE()AND r.submit_start_date > SYSDATE(),TIMESTAMPDIFF(DAY,SYSDATE(), MAX( r.EFFECT_END_DATE)),TIMESTAMPDIFF(DAY,SYSDATE(), MIN(r.open_bid_start_date)))AS lastDates,
p.CREATE_TIME AS createTime,
IF(  r.EFFECT_START_DATE <= SYSDATE()AND r.submit_start_date > SYSDATE(),'距报名结束' ,'距开标还有') AS proStatusCH,
IF( r.EFFECT_START_DATE <= SYSDATE() AND r.submit_start_date > SYSDATE(),'04' ,'05') AS proStatus,
r.EFFECT_START_DATE as signUpTime,
r.open_bid_start_date as openBidTime
FROM t_b_tender_project p
left join t_b_project_package pk on pk.TENDERID = p.id
left join t_b_stage s on pk.stageid=s.id 
left join t_b_project_time_rule r on r.packid=pk.id 
  WHERE  s.id = r.stageid  AND p.use_status = '01' AND r.effective_State='01' and p.QUALIFICATION_METHOD='00' and s.stage_type='01'
   <#if param['userId']?exists && param['userId'] ?length gt 0>  
		and p.create_user LIKE concat('%', '${param['userId']}','%') 
	</#if>
  AND (((r.EFFECT_START_DATE is null or  r.EFFECT_START_DATE <= SYSDATE())AND r.submit_start_date > SYSDATE()) OR (r.submit_start_date <= SYSDATE() AND SYSDATE() < r.open_bid_start_date))
  <#if param['search']?exists && param['search'] ?length gt 0>  
		and ( p.tender_no LIKE concat('%', '${param['search']}','%') or p.tender_name LIKE concat('%', '${param['search']}','%') ) 
	</#if>
	 GROUP BY p.id
	
		 UNION ALL 
SELECT 
p.QUALIFICATION_METHOD  as projectType,
p.id AS projectId,
p.tender_no AS projectCode,
p.tender_name AS projectName,
'' AS signUpEndTime,
'' AS openBidEndTime,
'0' AS lastDates,
p.CREATE_TIME AS createTime,
'资审结果' AS proStatusCH,
'03' AS proStatus,
'' as signUpTime,
'' as openBidTime
FROM t_b_tender_project p
  WHERE   p.QUALIFICATION_METHOD='00' 
   <#if param['userId']?exists && param['userId'] ?length gt 0>  
		and p.create_user LIKE concat('%', '${param['userId']}','%') 
	</#if>
   AND EXISTS(SELECT 1 FROM t_b_qualifiedSupplier q  WHERE p.id = q.TENDERID and q.phasetype='00' )   
  <#if param['search']?exists && param['search'] ?length gt 0>  
		and ( p.tender_no LIKE concat('%', '${param['search']}','%') or p.tender_name LIKE concat('%', '${param['search']}','%') ) 
	</#if>
	GROUP BY p.id  
 	UNION ALL
SELECT 
p.QUALIFICATION_METHOD  as projectType,
p.id AS projectId,
p.tender_no AS projectCode,
p.tender_name AS projectName,
MAX( r.EFFECT_END_DATE) AS signUpEndTime,
MIN(r.open_bid_start_date) AS openBidEndTime,
IF(  r.EFFECT_START_DATE <= SYSDATE()AND r.submit_start_date > SYSDATE(),TIMESTAMPDIFF(DAY,SYSDATE(), MAX( r.EFFECT_END_DATE)),TIMESTAMPDIFF(DAY,SYSDATE(), MIN(r.open_bid_start_date)))AS lastDates,
p.CREATE_TIME AS createTime,
IF(  r.EFFECT_START_DATE <= SYSDATE()AND r.submit_start_date > SYSDATE(),'距预审报名结束' ,'距预审开标还有') AS proStatusCH,
IF( r.EFFECT_START_DATE <= SYSDATE() AND r.submit_start_date > SYSDATE(),'01' ,'02') AS proStatus,
r.EFFECT_START_DATE as signUpTime,
r.open_bid_start_date as openBidTime
FROM t_b_tender_project p
left join t_b_project_package pk on pk.TENDERID = p.id
left join t_b_stage s on pk.stageid=s.id 
left join t_b_project_time_rule r on r.packid=pk.id 
  WHERE  s.id = r.stageid  AND p.use_status = '01' AND r.effective_State='01' and p.QUALIFICATION_METHOD='00' and s.stage_type='00'
   <#if param['userId']?exists && param['userId'] ?length gt 0>  
		and p.create_user LIKE concat('%', '${param['userId']}','%') 
	</#if>
  AND (((r.EFFECT_START_DATE is null or  r.EFFECT_START_DATE <= SYSDATE())AND r.submit_start_date > SYSDATE()) OR (r.submit_start_date <= SYSDATE() AND SYSDATE() < r.open_bid_start_date))
  <#if param['search']?exists && param['search'] ?length gt 0>  
		and ( p.tender_no LIKE concat('%', '${param['search']}','%') or p.tender_name LIKE concat('%', '${param['search']}','%') ) 
	</#if>
	GROUP BY p.id
		
  UNION ALL 	
	  SELECT  
p.QUALIFICATION_METHOD  as projectType,
p.id AS projectId,
p.tender_no AS projectCode,
p.tender_name AS projectName,
'0' AS signUpEndTime,
'0' AS openBidEndTime,
0 AS lastDates,
p.CREATE_TIME AS createTime,
'未开始报名' AS proStatusCH,
'00' AS proStatus,
'' as signUpTime,
'' as openBidTime
FROM t_b_tender_project p
left join t_b_project_package pk on pk.TENDERID = p.id
left join  t_b_stage s ON pk.stageid=s.id 
  WHERE   1=1 AND p.use_status = '01' and p.QUALIFICATION_METHOD='00' and s.stage_type='00'
 <#if param['userId']?exists && param['userId'] ?length gt 0>  
		and p.create_user LIKE concat('%', '${param['userId']}','%') 
	</#if>
  <#if param['search']?exists && param['search'] ?length gt 0>  
		and ( p.tender_no LIKE concat('%', '${param['search']}','%') or p.tender_name LIKE concat('%', '${param['search']}','%') ) 
	</#if>
  AND NOT EXISTS(SELECT 1 FROM t_b_project_time_rule r  WHERE p.id = r.tenderid  AND r.effective_State='01')   
GROUP BY p.id 
	) gg GROUP BY gg.projectId 
  <#if param['sortName']?exists && param['sortName'] =='signUpTime' >  
  			 ORDER BY signUpEndTime 
  			   <#if param['sort']?exists  && param['sort'] =='desc' >  
  			 	desc
  			  <#else>
  			  asc
  			  </#if>
  <#elseif param['sortName']?exists && param['sortName'] =='openBidTime'> 
			 ORDER BY openBidEndTime 
			 <#if param['sort']?exists  && param['sort'] =='desc' >  
  			 	desc
  			  <#else>
  			  asc
  			  </#if>
   <#else>
    		   ORDER BY createTime   desc
	</#if>
 
 