select c.id as id, p.tender_no as tenderid,p.TENDER_NAME as packname,c.create_departname as createDepartName,
c.attachment as attachment
from t_b_clarification c left join t_b_tender_project p on p.id=c.tenderid
where 1=1
<#if param['userId']?exists && param['userId'] ?length gt 0>  
		and p.CREATE_USER LIKE concat('%', '${param['userId']}','%') 
	</#if>
<#if param['projectCode']?exists && param['projectCode'] ?length gt 0>  
		and p.tender_no LIKE concat('%', '${param['projectCode']}','%') 
	</#if>
	order by c.create_time desc
 
 