SELECT 
op.id,
op.stageid,
op.packid,
op.evaluationPrice,
op.supplierid,
op.supplierName,
s.price_total AS priceTotal,
s.total,
s.is_recommend AS isRecommend,
s.sort,
IF(s.sort IS NULL,10000,s.sort) orders
FROM 
(SELECT 
o.id,
o.stageid,
o.packid,
o.value AS evaluationPrice,
o.supplierid,
d.departname AS supplierName
FROM
t_b_open_bid_item o,t_s_depart d,t_b_bid_price_factor f
WHERE o.supplierid=d.id 
AND f.unit IS NOT NULL
AND o.stageid=:stageid
AND o.pricefactorid=f.id ) op 
LEFT JOIN t_b_supplier_evaluation_result s
ON op.stageid=s.stageid 
AND s.supplierid=op.supplierid 
ORDER BY orders ASC