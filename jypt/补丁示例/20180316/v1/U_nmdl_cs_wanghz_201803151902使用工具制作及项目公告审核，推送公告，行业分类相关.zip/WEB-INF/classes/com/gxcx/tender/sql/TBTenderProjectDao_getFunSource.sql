SELECT 
GROUP_CONCAT(fund_type_name) 
FROM 
t_b_tender_money_source 
WHERE tenderid=:tenderid 
AND money IS NOT NULL