SELECT 
  t.linker,
  t.linker_tel AS linkerTel,
  t.id_card AS idcard
FROM
  t_b_tender_signup t,
  t_b_pack_signup s 
WHERE t.id = s.signupid 
  AND s.stageid = :stageId
  AND t.supplyerid = :supplierId