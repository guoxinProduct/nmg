SELECT B.id,B.tenderid tenderid,P.tender_no tenderno,P.tender_name tendername,B.title title,B.bulletin_type bulletinType,B.create_time createtime,B.relstatus relstatus,B.create_user createuser,
(SELECT
     GROUP_CONCAT(tp.pack_no)
   FROM t_b_pack_bulletin pc,
     t_b_project_package tp
   WHERE pc.bulletinid = B.id
       AND pc.packid = tp.id) AS packNames
 from T_B_TENDER_BULLETIN B
left JOIN T_B_TENDER_PROJECT P  ON B.tenderid = P.id

where 1 = 1 and (B.bulletin_type='11')

<#if tenderno?exists && tenderno?length gt 0>
	and P.tender_no  like concat('%', trim(:tenderno),'%')
</#if>

<#if tendername?exists && tendername?length gt 0>
	and P.tender_name  like concat('%', trim(:tendername),'%')
</#if>

<#if title?exists && title?length gt 0>
	and B.title  like concat('%', trim(:title),'%')
</#if>

<#if createtimebegin?exists && createtimebegin?length gt 0 &&  createtimeend?exists && createtimeend?length gt 0>  
		AND date_format(B.create_time,'%Y-%m-%d %H:%i') BETWEEN trim(:createtimebegin) and trim(:createtimeend)
</#if>

<#if createuser?exists && createuser?length gt 0>
	and B.create_user = :createuser
</#if>

<#if param?exists >
		<#if param['tenderId']?exists>
			and B.tenderid = '${param['tenderId']}'
		</#if>
		<#if param['batches']?exists>
			and EXISTS ( select * from  t_b_pack_bulletin pb , t_b_stage st where  st.packid = pb.PacKID  and st.stage_batches = '${param['batches']}' and pb.BULLETINID = b.id  )
		</#if>
</#if>

<#if tBBulletin.relstatus ?exists && tBBulletin.relstatus ?length gt 0>
	and B.relstatus = :tBBulletin.relstatus
</#if>

ORDER BY B.create_time DESC