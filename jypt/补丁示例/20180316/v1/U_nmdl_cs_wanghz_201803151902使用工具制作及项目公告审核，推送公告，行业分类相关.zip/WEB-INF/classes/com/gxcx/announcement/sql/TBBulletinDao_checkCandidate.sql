SELECT 
id,
stageid,
supplierid,
supplierName,
sort
FROM 
t_b_supplier_evaluation_result 
WHERE 
stageid=:stageid 
AND is_recommend='01'
ORDER BY sort ASC