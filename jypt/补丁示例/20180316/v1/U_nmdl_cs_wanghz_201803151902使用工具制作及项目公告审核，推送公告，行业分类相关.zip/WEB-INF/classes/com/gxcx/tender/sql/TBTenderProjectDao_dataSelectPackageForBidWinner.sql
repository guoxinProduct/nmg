SELECT
  pk.id as id,
  tp.id as tenderNoNumber,
  tp.buyersId as buyersId,
  tp.buyers_name as buyersName,
  tp.agent_name as agentName,
  tp.agentid as agentid,
  tp.tender_no as tenderno,
  tp.tender_name as tendername,
  pk.pack_no as projectAreaCode,
  pk.pack_name as projectAreaName
FROM t_b_tender_project tp
  INNER JOIN t_b_project_package pk
    ON tp.id = pk.tenderid
WHERE 1=1

and EXISTS(SELECT
               1
             FROM t_b_supplier_evaluation_result ser,
               t_b_stage bs
             WHERE bs.id = pk.stageid
                 AND ser.stageid = bs.id
                 AND bs.stage_type = '01')/*阶段类型---招标阶段*/
    AND NOT EXISTS(SELECT
                     1
                   FROM t_b_winning_result wr                    
                   WHERE wr.packid = pk.id)
    AND EXISTS (
    	SELECT 1 FROM T_B_TENDER_BULLETIN B WHERE B.bulletin_type='05' AND B.relstatus='01' AND B.tenderid = TP.ID 
    )
                   
<#if t.createUser ?exists && t.createUser ?length gt 0>
	and tp.create_user = :t.createUser
</#if> 

<#if t.tenderno ?exists && t.tenderno ?length gt 0>
	and tp.tender_no = :t.tenderno
</#if> 
<#if t.tendername ?exists && t.tendername ?length gt 0>
	and tp.tender_name = :t.tendername
</#if> 