
SELECT  sum(quotestum) from t_b_winning_result_detail  where tenderid=:tenderid