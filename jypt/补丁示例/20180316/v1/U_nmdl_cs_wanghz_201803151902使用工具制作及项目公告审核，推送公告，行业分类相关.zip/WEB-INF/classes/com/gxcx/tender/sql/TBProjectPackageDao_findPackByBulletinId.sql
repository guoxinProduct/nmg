SELECT 
  p.id,
  p.tenderid,
  p.tender_no AS tenderNo,
  p.pack_no AS packNo,
  p.pack_name AS packName,
  p.contract_budget AS contractBudget,
  p.is_pack AS isPack,
  p.create_time AS createTime, 
  p.create_user AS createUser, 
  p.stageid, 
  p.project_status AS projectStatus, 
  p.purcategory_ids, 
  p.purcategory_names, 
  p.ORDERLEVEL AS orderlevel, 
  p.is_application, 
  p.is_subitem, 
  p.dtype, 
  p.choose_setting, 
  p.static_setting, 
  p.source_PackId AS sourcePackId,
  p.max_limit_price AS maxLimitPrice
FROM
  t_b_project_package p,
  t_b_pack_bulletin b 
WHERE b.bulletinid = :bulletinId
  AND p.id = b.packid 