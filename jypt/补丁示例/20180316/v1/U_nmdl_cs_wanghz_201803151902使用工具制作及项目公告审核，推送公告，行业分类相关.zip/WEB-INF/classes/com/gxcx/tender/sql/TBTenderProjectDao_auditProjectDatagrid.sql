SELECT t.id,
t.tender_no as tenderno,
t.tender_name as tendername,
t.tender_method as tendermethod,
t.tender_type as tendertype,
t.qualification_method as qualificationMethod,
t.budget_total_money as budgetTotalMoney,
t.buyers_name as buyersName,
t.BUYERSID AS buyersId,
t.agent_name as agentName,
(SELECT COUNT(pp.id) FROM t_b_project_package pp WHERE pp.tenderid = t.id AND pp.is_pack = 1) as packCount,
t.create_time as createTime,
t.use_status as useStatus

FROM t_b_tender_project t WHERE t.project_type='00' 

<#if t.tenderno ?exists && t.tenderno ?length gt 0>
	and t.tender_no like concat('%', trim(:t.tenderno),'%')
</#if>

<#if t.tendername ?exists && t.tendername ?length gt 0>
	and t.tender_name like concat('%', trim(:t.tendername),'%')
</#if>

<#if t.buyersName ?exists && t.buyersName ?length gt 0>
	and t.buyers_name like concat('%', trim(:t.buyersName),'%')
</#if>
<#if t.agentName ?exists && t.agentName ?length gt 0>
	and t.agent_name like concat('%', trim(:t.agentName),'%')
</#if>

<#if begintime ?exists && begintime ?length gt 0 >  
	and date_format(t.create_time,'%Y-%m-%d %H:%i') >= trim(:begintime) 
</#if>

<#if endtime ?exists && endtime ?length gt 0>  
	and date_format(t.create_time,'%Y-%m-%d %H:%i') <= trim(:endtime)
</#if>

<#if t.useStatus ?exists && t.useStatus ?length gt 0>
	and t.use_status = :t.useStatus
</#if>

ORDER BY t.create_time DESC